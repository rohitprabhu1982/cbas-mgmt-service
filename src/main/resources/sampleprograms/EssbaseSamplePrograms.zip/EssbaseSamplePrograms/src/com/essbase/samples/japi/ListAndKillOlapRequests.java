/*
    File: ListAndKillOlapRequests.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
import com.essbase.api.domain.*;

/**
    ListAndKillOlapRequests Example does the following: Signs on to essbase domain,
    Connects to a olap server, Lists the requests, Kills requests, Signs off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class ListAndKillOlapRequests {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // List for specified user/app/cube.
            String appName = "Demo", cubeName = "Basic";
            listAndKillOlapRequests(olapSvr, s_userName, appName, cubeName);

            // List for specified user/app (all cubes).
            listAndKillOlapRequests(olapSvr, s_userName, appName, null);

            // List for specified user (all apps/cubes for user).
            listAndKillOlapRequests(olapSvr, s_userName, null, null);

            // List all requests (all users).
            listAndKillOlapRequests(olapSvr, null, null, null);
            System.out.println("\nListAndKillOlapRequests Completed.");
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Close olap server connection and sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void listAndKillOlapRequests(IEssOlapServer olapServer, String userName,
            String appName, String cubeName) throws EssException {
        System.out.println("\n\nListing olap requests...\n"+
            "-----------------------");
        IEssIterator requests = olapServer.getRequests(userName, appName,
            cubeName);

        for (int i = 0; i < requests.getCount(); i++) {
            IEssOlapRequest request = (IEssOlapRequest)requests.getAt(i);
            System.out.println("User name: " + request.getUserName());
            System.out.println("Application name: " + request.getOlapApplicationName());
            System.out.println("Cube name: " + request.getCubeName());
            System.out.println("Request code: " + request.getRequestCode());
            System.out.println("Request source: " + request.getRequestSource());
            System.out.println("Request state: " + request.getRequestState());
            System.out.println("Request string: " + request.getRequestString());
            System.out.println("Request time: " + request.getRequestTime());
            System.out.println();

            boolean killReqOnFirstEntry = true;
            if (killReqOnFirstEntry == true && i == 0) {
                System.out.println("Killing the request at the first entry...");
                request.kill();
            }
        }
    }
    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + ListAndKillOlapRequests.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
