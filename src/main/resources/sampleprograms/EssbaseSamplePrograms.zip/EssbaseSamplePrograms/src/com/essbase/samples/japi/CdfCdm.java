/*
    File: CdfCdm.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.domain.*;
import com.essbase.api.datasource.*;
import com.essbase.api.domain.IEssDomain;

/**
    CdfCdm example shows the usage of CDF and CDM.

    In order for this sample to work in your environment, make sure to
    change the static variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 18 Jul 06
 */
public class CdfCdm {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    /* Possible values for s_provider: 
        "Embedded"
        "http://localhost:13080/aps/JAPI"
      */
    private static String s_provider = "Embedded"; // Default
    private static String s_analyticSvrName = "localhost";

    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olap = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            olap = dom.getOlapServer(s_analyticSvrName);
            olap.connect();
            
            System.out.println("Creating CDF...");
            String appName = "Sample",
                   funcName = "@MYAVGW",
                   javaSpec = "com.hyperion.essbase.calculator.Statistics.avg(double [],double [])",
                   funcSpec = "@MYAVGW(@LIST(expList), @LIST(weightExpList))",
                   funcComment = "Computes the weighted average of non-missing values in a data set (expList)";

            olap.createCDF(funcName, javaSpec,
            		IEssOlapServer.ESS_UDF_FUNCTION_RUNTIME, funcSpec, funcComment);

            System.out.println("\nCreating CDM...");
            String macroName = "@_JCOUNT",
                   definition = "@_JCOUNT(@@S)",
                   signature = "(Group)",
                   macroSpec = "@JCOUNT(expList)",
                   macroComment = "Computes the count of non-missing elements in a data set (expList)";
            
            olap.createCDM(macroName, definition, signature, macroSpec,
            		macroComment);
			System.out.println("\nListing CDF/CDM...");
			String[][] list = olap.getCDM_CDF();
            for (int i = 0; i < list.length; i++) {
                System.out.println("\nName: " + list[i][0]);
                System.out.println("Spec: " + list[i][1]);
                System.out.println("Comment: " + list[i][2]);
                System.out.println("Type: " + list[i][3]);
                System.out.println("Scope: " + list[i][4]);
            }

            System.out.println("\nDeleting CDF...");
            olap.deleteCDF(funcName);

            System.out.println("\nDeleting CDM...");
            olap.deleteCDM(macroName);
            olap.disconnect();
            ess.signOff();
			System.out.println("CdfCdm Sample successfully completed.");
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            if (olap != null) {
                try {
                    if (olap.isConnected())
                        olap.disconnect();
                } catch (EssException x) {}
            }

            if (ess != null) {
                try {
                    if (ess.isSignedOn())
                        ess.signOff();
                } catch (EssException x) {}
            }
        }
        /* Set status to failure only if exception occurs and do abnormal termination
         *            otherwise, it will by default terminate normally */ 
         if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_analyticSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CdfCdm.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
