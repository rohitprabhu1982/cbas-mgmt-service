/*
    File: CreateOlapApp.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
import com.essbase.api.domain.*;

/**
    CreateOlapApp example creates olap applications.
    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 18 Jul 06
 */
public class CreateOlapApp {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default  

    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // Create olap applications.
            createOlapApplications(olapSvr);
        } catch (EssException x) {
            System.out.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Close olap server connection and sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void createOlapApplications(IEssOlapServer olapSvr) throws EssException {
        try {
            // Here is one way to create an application.
            IEssOlapApplication app_1 = olapSvr.createApplication("Sample_1",
                "An application", 0, true, false, true, true, true, true, 60,
                IEssCube.EEssCubeAccess.CALCULATE_CUBE_DATA);

            // Here is another way to create an application.
            IEssOlapApplication app_2 = olapSvr.createApplication("Sample_2");
            app_2.updatePropertyValues("An application", 0, true, false, true,
                true, true, true, 60, IEssCube.EEssCubeAccess.CALCULATE_CUBE_DATA);

            // Here is another way to create an application.
            IEssOlapApplication app_3 = olapSvr.createApplication("Sample_3");
            app_3.setAllowCommands(true);
            app_3.setAllowConnects(true);
            // ... add other set statements here...
            app_3.updatePropertyValues();
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CreateOlapApp.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
