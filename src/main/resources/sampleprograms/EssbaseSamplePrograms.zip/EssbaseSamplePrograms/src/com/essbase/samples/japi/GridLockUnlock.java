/*
    File: GridLockUnlock.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.datasource.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    GridLockUnlock Example does the following: Signs on to essbase domain,
    Opens a cube view, Performs Lock, Retrieve, Unlock and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* to suit your environment. If you change s_appName
    and s_cubeName, make sure to edit the method performCubeViewOperation()
    accordingly.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class GridLockUnlock {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_appName = "demo";
    private static String s_cubeName = "basic";
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            cv = dom.openCubeView("Grid Lock Unlock Example", s_olapSvrName, s_appName,
                s_cubeName);

            // Perform cube view operations.
            performCubeViewOperation(ess, cv, "lock");
            performCubeViewOperation(ess, cv, "retrieve");
            performCubeViewOperation(ess, cv, "unlock");
		} catch (EssException x){
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
		} finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performCubeViewOperation(IEssbase ess, IEssCubeView cv,
            String opStr) throws EssException {
        IEssOperation op = null;
        if (opStr.equals("retrieve")) {
            op = cv.createIEssOpRetrieve();
            cv.performOperation(op);
            IEssGridView grid = cv.getGridView();
            int cntRows = grid.getCountRows(), cntCols = grid.getCountColumns();
            System.out.print("Query Results for the Operation: " + opStr + "\n" +
                "-----------------------------------------------------\n");
            for (int i = 0; i < cntRows; i++) {
                for (int j = 0; j < cntCols; j++)
                    System.out.print(grid.getValue(i, j) + "\t");
                System.out.println();
            }
            System.out.println();
        } else if (opStr.equals("lock")) {
            op = cv.createIEssOpLock();
            cv.performOperation(op);
            System.out.println("Locking successful...\n");
        } else if (opStr.equals("unlock")) {
            op = cv.createIEssOpUnlock();
            cv.performOperation(op);
            System.out.println("Unlocking successful...");
        } else
            throw new EssException("Invalid option.");
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + GridLockUnlock.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
