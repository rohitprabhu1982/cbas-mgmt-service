/*
    File: KillOwnRequest.java 1.1, 2006-12-01
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.dataquery.IEssCubeView;
import com.essbase.api.dataquery.IEssOpMdxQuery;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapFileObject;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.IEssbase;


/**
 * KillOwnRequest
 * Kills a running request issued to an Essbase app server from the same user session.
 * @author Satish Ramanavarapu
 *Dec 1, 2006
 */
public class KillOwnRequest extends Thread {

    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
    
//    private static String s_appName = "xofm1";
//    private static String s_cubeName = "basic";

    private static String s_appName = "asosamp";
    private static String s_cubeName = "sample";

    private static IEssbase ess = null;
    private static IEssDomain dom = null;
    private static IEssOlapServer olapSvr = null;
    private static IEssOlapApplication app = null;
    private static IEssCube cube = null;
    private static IEssCubeView cv = null;
    private static boolean isServerAvailable = false;
    
    private static int SERVER_START_WAIT = 2000;
    private static int REQUEST_SPAWN_WAIT = 3000;
    private static int AFTER_KILL_WAIT_TO_LOGOUT = 5000;
	
	/**
	 * @param args
	 */
    public static void main(String[] args) {
        int statusCode = 0;
        acceptArgs(args);
        KillOwnRequest thread = new KillOwnRequest();
        
        try {
            thread.start();

        	// wait for the olapSvr instance to be connected and available.
            while (!isServerAvailable) {
	            try {
	            	Thread.sleep(SERVER_START_WAIT);
	            }
	            catch (InterruptedException ie) {
	            	ie.printStackTrace();
	            }
            }

            // wait of the request to get spawned and in running state
            try {
            	Thread.sleep(REQUEST_SPAWN_WAIT);
            }
            catch (InterruptedException ie) {
            	ie.printStackTrace();
            }
            log("Triggering KILL_REQUEST.....");
            olapSvr.killOwnRequest();
            log("KILL_REQUEST completed.");
        } catch (Exception x) {
            System.err.println("Error: " + x.getMessage());
            x.printStackTrace();
            statusCode = FAILURE_CODE;
        } finally {
        	try {
        		log("FINALLY... Waiting for thread to join.");
        		thread.join();
        		// Wait for sometime for the request to get terminated on the server 
        		// before a clearActive and logout.
                try {
                	Thread.sleep(AFTER_KILL_WAIT_TO_LOGOUT);
                }
                catch (InterruptedException ie) {
                	ie.printStackTrace();
                }
        	}
        	catch (InterruptedException ie) {ie.printStackTrace();}
        	comeOutClean();
            //System.exit(0);
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    public void run() {
    	// enable which ever request is to be killed
    	loadData();
//    	mdxQuery();
    	
    }
    
    public void mdxQuery() {
        SERVER_START_WAIT = 1000;
        REQUEST_SPAWN_WAIT = 2000;
        AFTER_KILL_WAIT_TO_LOGOUT = 1000;
		try{
			// Create JAPI instance.
			ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

			// Sign On to the Provider
	        dom = ess.signOn(s_userName, s_password, false, null, s_provider);
            
	        // Open connection with olap server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
	        
			cv = dom.openCubeView("Mdx Query Example", s_olapSvrName, s_appName, s_cubeName);
			boolean bDataLess = false;
			boolean bNeedCellAttributes = false;
			boolean bHideData = true;

			// These queries take time when cube is loaded with data.
			String mdxquery = "WITH MEMBER Measures.Calc1 AS 'AVG(Descendants([Products].currentmember),[Transactions])' " +
								"Select {[Measures].[Calc1]} ON COLUMNS, {crossjoin([Age].Members,[Promotions].Members)} ON ROWS," +
								"{[Products].Members} on Pages from [ASOsamp.sample]";

			// this takes more time to execute
//			mdxquery = "WITH MEMBER Measures.Calc1 AS 'AVG(Descendants([Products].currentmember),[Transactions])' " +
//						"Select {[Measures].[Calc1]} ON COLUMNS, {crossjoin([Age].Members,[Promotions].Members)} ON ROWS,"+
//						"{crossjoin([Products].Members,[Geography].members)} on Pages from [ASOsamp.sample]";

			IEssOpMdxQuery op = cv.createIEssOpMdxQuery();

	        op.setQuery(bDataLess, bHideData, mdxquery, bNeedCellAttributes,
						IEssOpMdxQuery.EEssMemberIdentifierType.NAME);
	        
	        isServerAvailable = true;
	        log("Initiating MDX request ... ");
	        cv.performOperation(op);
	        log("MDX request execution complete.");

		}
		catch (Exception x){
			log("\n\nError from terminated request:\n " + x.getMessage() + "\n\n");
            // x.printStackTrace();
		} finally{
			// Close cube view.
			try {
				if (cv != null)
					cv.close();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}
		}
    }
    
    public void loadData() {
        SERVER_START_WAIT = 1000;
        REQUEST_SPAWN_WAIT = 5000;
        AFTER_KILL_WAIT_TO_LOGOUT = 8000;

    	try {
            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            dom = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            app = olapSvr.getApplication(s_appName);
            cube = app.getCube(s_cubeName);
            log("Loading data to cube " + cube.getName() + "...");

            isServerAvailable = true;

            // Loading from data/rules file in the server.
            String [][] errors = cube.loadData(IEssOlapFileObject.TYPE_RULES, "dataload", IEssOlapFileObject.TYPE_TEXT, "dataload", false);

            if (errors != null)
            	log("Size of errors: " + errors.length);
            log("Dataload complete");
    	}
    	catch (Exception e) {
    		log("\n\nError from terminated request: \n" + e.getMessage() +"\n\n");
    		// e.printStackTrace();
    	}
    }
	  
    public static void comeOutClean() {
        try {
            if (olapSvr != null && olapSvr.isConnected() == true)
                olapSvr.disconnect();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }

        try {
            if (ess != null && ess.isSignedOn() == true)
                ess.signOff();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }
    }

    public static void log (String str){
    	log(str, true);
    }
    
    public static void log(String str, boolean tab) {
    	if (tab) System.out.println("*::*\t" + str);
    	else System.out.println("*::*" + str);
    }
    
    static void acceptArgs(String[] args) {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + KillOwnRequest.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }

}
