/*
    File: DataSource.java	1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssCalcList;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.datasource.IEssReferenceCubeInfo;
import com.essbase.api.datasource.IEssCube.EEssCubeletType;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.metadata.IEssDimension;
import com.essbase.api.session.IEssbase;

/**
    DataSource Example does the following: Signs on to essbase domain,
    Performs various datasource operations and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 18 Jul 06
 */
public class DataSource {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system1";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default

    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with OLAP server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // List all OLAP applications and cubes in the OLAP server.
            listOlapApplicationsAndCubes(olapSvr);

            IEssCube cube = olapSvr.getApplication("Sample").getCube("Basic");

            executeReport(cube);
            getDimensions(cube);
            checkOutSomeFunctionality(cube);
            boolean getPerfStats = false;
            if (getPerfStats == true)
                getPerformanceStatistics(cube);
            getAssociatedAttributes(cube);
            getLogSize(olapSvr);

            System.out.println("Calc functions: " + cube.getCalcFunctions());
 
            //System.out.println("\nReference Cube APIs :");
            //manageReferenceCubes(olapSvr);
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Close olap server connection and sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void listOlapApplicationsAndCubes(IEssOlapServer olapSvr)
            throws EssException {
        IEssIterator olapApps = olapSvr.getApplications();
        System.out.println("\n\nListing OLAP applications and cubes...\n"+
            "--------------------------------------");
        for (int i = 0; i < olapApps.getCount(); i++) {
            IEssOlapApplication app = (IEssOlapApplication)olapApps.getAt(i);
            System.out.println(app.getName());
            IEssIterator cubes = app.getCubes();
            for (int j = 0; j < cubes.getCount(); j++) {
                IEssCube cube = (IEssCube)cubes.getAt(j);
                System.out.println("    " + cube.getName());
            }
        }
    }

    static void executeReport(IEssCube cube) throws EssException {
        try {
            String repSpec = "{TabDelim} <Column (Scenario, Year) "+
                "<Row (Market, Product) <Ichild Market <Ichild Product !";
            System.out.println("\n\nReport Output for: "+repSpec+"\n----------------"+
                "------------------------------------------------------------");
            String output = cube.report(repSpec, true,false);
            System.out.println(output);
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void getDimensions(IEssCube cube) throws EssException {
        try {
            System.out.println("\n\nListing Dimensions \n----------------");
            IEssIterator dims = cube.getDimensions();
            for (int i = 0; i < dims.getCount(); i++) {
                IEssDimension dim = (IEssDimension)dims.getAt(i);
                System.out.print(((i > 0) ? "," : "") + dim.getName());
            }
            System.out.println();
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void checkOutSomeFunctionality(IEssCube cube) throws EssException {
        try {
            IEssDimension dim = cube.getDimension("Qtr1");
            System.out.println("DimName: " + dim.getName() + ", DimNo: " +
                dim.getDimensionNumber());
            dim = cube.getDimension("Sales");
            System.out.println("DimName: " + dim.getName() + ", DimNo: " +
                dim.getDimensionNumber());

            String calcScript = cube.getDefaultCalcScript();
            System.out.println("\nDefault calc script: " + calcScript);

            cube.getApplication().setCalcList(s_userName, cube, true, new String[]{});

            IEssCalcList list = cube.getApplication().getCalcList(s_userName, cube);
            System.out.println("Allow all calcs setting for User "+s_userName+ " is "+list.getAllCalcs());
            String[] cal_list = list.getCalcList();
            for (int i =0; (cal_list != null) && i < cal_list.length; i++) {
            	System.out.println(cal_list[i]);
            }

            list = cube.getApplication().getCalcListEx(s_userName, cube);
            System.out.println("Allow all calcs setting for User "+s_userName+ " is "+list.getAllCalcs());
            cal_list = list.getCalcList();
            for (int i =0; (cal_list != null) && i < cal_list.length; i++) {
            	System.out.println(cal_list[i]);
            }

            String[] aliasTblNames = cube.getAliasTableNames();
            System.out.print("Alias Table Names: ");
            for (int i = 0; i < aliasTblNames.length; i++)
                System.out.println((i > 0 ? ",":"") + aliasTblNames[i]);
            System.out.println();

            System.out.println("Query members: \"<ALLINSAMEDIM Year\"\n" +
                cube.queryMembers("<ALLINSAMEDIM Year"));
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void getPerformanceStatistics(IEssCube cube) throws EssException {
        try {
            cube.resetPerformanceStatisticsTables(4, 7);
            System.out.println("\nPerformance Statistics\n--------------------\n" +
                cube.getPerformanceStatistics());
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void getLogSize(IEssOlapServer olapSvr) throws EssException {
        try {
            System.out.println("\nOLAP Agent log file size: " +
                olapSvr.getLogSize(true, ""));
            System.out.println("OLAP App (Sample) log file size: " +
                olapSvr.getLogSize(false, "Sample"));
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void getAssociatedAttributes(IEssCube cube) throws EssException {
        try {
            System.out.println("\nGetting associated attributes for 100-10...");
            String[][] info = cube.getAssociatedAttributes("100-10", "");
            int cntRows = info.length, cntCols = 4;
            for (int i = 0; i < cntRows; i++) {
                System.out.print("Attr mbr: " + info[i][0]);
                System.out.print(", Attr dim: " + info[i][1]);
                System.out.print(", Type: " + info[i][2]);
                System.out.println(", Value: " + info[i][3]);
            }
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }
    
    static void manageReferenceCubes(IEssOlapServer olapSvr)
			throws EssException {
		try {
			IEssOlapApplication olapApp = olapSvr.getApplication("Demo");
			IEssCube cube = olapApp.getCube("BasicCp");
			String locAlias = "locAlias1";
			cube.clearActive();
			cube.createLocationAlias(locAlias, "localhost", "Demo", "BasicCp",
					"system", "password");

			// Note :
			// 1. The total cubelet size limitation defaults to 8k cells for all
			// possible cubelets inside the target Cube
			// 2. Cubelet creation not possible on the database having attribute
			// dimensions

			cube.createReferenceCube(locAlias, EEssCubeletType.ACTIVE,
					(long) 2000);
			System.out.println("\nReference Cube created successfully...");

			cube.unloadReferenceCube(locAlias);
			System.out.println("\nReference Cube is unloaded from memory...");

			cube.loadReferenceCube(locAlias);
			System.out.println("\nReference Cube is loaded in memory...");

			IEssReferenceCubeInfo refCubeInfo[] = cube.listReferenceCubes();

			System.out.println("\nListing Reference Cubes...");

			if (refCubeInfo != null)
				for (int i = 0; i < refCubeInfo.length; i++) {
					System.out.println("Reference Cube LocationAlias name : "
							+ refCubeInfo[i].getLocationAlias());
					System.out.println("Reference Cube type               : "
							+ refCubeInfo[i].getType().stringValue());
					System.out.println("Validity of Cube                  : "
							+ refCubeInfo[i].isInvalid());
					System.out.println("Load Status of Cube               : "
							+ refCubeInfo[i].isLoaded());
				}

			cube.removeReferenceCube(locAlias);
			System.out.println("\nReference Cube removed Sucessfully");
			cube.deleteLocationAlias(locAlias);
		} catch (EssException essE) {
			System.out.println("Error: " + essE.getMessage());
		}

	}
    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + DataSource.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
