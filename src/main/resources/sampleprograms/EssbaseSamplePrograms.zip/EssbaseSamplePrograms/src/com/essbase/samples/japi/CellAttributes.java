/*
    File: CellAttributes.java, 1.1, 2006-7-17
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    CellAttributes Example does the following: Signs on to essbase,
    Opens a cube view, Performs Retrieve & Zoomin Operations,
    and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the static s_* variables.

    @author Srini Ranga
    @version 1.1, 17 Jul 06
 */
public class CellAttributes {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_olapSvrName = "localhost";
    
    private static String s_appName = "demo";
    private static String s_cubeName = "basic";

    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom = ess.signOn(s_userName, s_password, false, null, s_provider);
            // Connect to the Analytic Server and open a CubeView.
            cv = dom.openCubeView("Cell Attributes",
                s_olapSvrName, s_appName, s_cubeName);

            // Perform retrieve and zoomIn and get cell attributes.
            performCubeViewOperation(ess, cv, "retrieve");
            performCubeViewOperation(ess, cv, "zoomIn");
		} catch (EssException x){
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
		} finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        /* Set status to failure only if exception occurs and do abnormal termination
         * otherwise, it will by default terminate normally */ 
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performCubeViewOperation(IEssbase ess, IEssCubeView cv,
            String opStr) throws EssException {
        // Create a grid view with the input for the operation.
        IEssGridView grid = cv.getGridView();

        // Create the operation specification.
        IEssOperation op = null;
        if (opStr.equals("retrieve")) {
            op = cv.createIEssOpRetrieve();
        } else if (opStr.equals("zoomIn")) {
            grid.setSize(2, 5);
            grid.setValue(0, 1, "Market");
            grid.setValue(0, 2, "Product");
            grid.setValue(0, 3, "Accounts"); ;
            grid.setValue(0, 4, "Actual");
            grid.setValue(1, 0, "Year");
            op = cv.createIEssOpZoomIn();
            ((IEssOpZoomIn)op).addRange(1, 0, 1, 1);
        } else
            throw new EssException("Operation not supported.");

        // Perform the operation.
        cv.performOperation(op);

        // Get the result and print the output.
        int cntRows = grid.getCountRows(), cntCols = grid.getCountColumns();
        System.out.print("Query Results for the Operation: " + opStr + "\n" +
            "-----------------------------------------\n");
        for (int row = 0; row < cntRows; row++) {
            for (int column = 0; column < cntCols; column++)
                System.out.print(grid.getValue(row, column) + "\t");
            System.out.println();
        }
        
        System.out.println("\n\nMore details of the results\n" +
            "---------------------------\n");
        for (int row = 0; row < cntRows; row++) {
            for (int column = 0; column < cntCols; column++)  {
                System.out.print("Cell (" + row + "," + column + "): ");
                IEssCell cell = grid.getCell(row, column);
                IEssCell.EEssCellType cellType = cell.getCellType();
                System.out.print("Type:" + cellType.stringValue());
                if (cellType == IEssCell.EEssCellType.DATA) {
                    IEssDataCell dataCell = (IEssDataCell)cell;
                    System.out.print(", Value:" + dataCell.getValue());
                    System.out.print(", AccessMode:" + dataCell.getAccessMode());
                    System.out.print(", DataCellType:" + dataCell.getDataCellType());
                    System.out.print(", ObjectsLinked:" + dataCell.isObjectsLinked());
                    System.out.print(", CellNoteLinked:" + dataCell.isCellNoteLinked());
                    System.out.print(", DrillThrough:" + dataCell.isDrillThrough());
                    System.out.print(", isPartitionLinked:" + dataCell.isPartitionLinked());
                    System.out.print(", isUrlLinked:" + dataCell.isUrlLinked());
                    System.out.print(", isWinAppLinked:" + dataCell.isWinAppLinked());
                } else if (cellType == IEssCell.EEssCellType.MEMBER) {
                    IEssMemberCell mbrCell = (IEssMemberCell)cell;
                    System.out.print(", Name:" + mbrCell.getMemberName());
                    System.out.print(", DimTop:" + mbrCell.isDimensionTop());
                    System.out.print(", Zoominable:" + mbrCell.isZoominable());
                    System.out.print(", NeverShare:" + mbrCell.isNeverShare());
                    System.out.print(", LabelOnly:" + mbrCell.isLabelOnly());
                    System.out.print(", StoreData:" + mbrCell.isStoreData());
                    System.out.print(", ExpShare:" + mbrCell.isExpShare());
                    System.out.print(", ImpShare:" + mbrCell.isImpShare());
                    System.out.print(", DynCalc:" + mbrCell.isDynCalc());
                    System.out.print(", DimNum:" + mbrCell.getDimensionNumber());
                } else if (cellType == IEssCell.EEssCellType.TEXT) {
                    System.out.print(cell.getValue());
                }
                System.out.println("\n");
            }
        }
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CellAttributes.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
