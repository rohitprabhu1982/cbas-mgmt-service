package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapFileObject;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.IEssCustomMessageHandler;
import com.essbase.api.session.IEssbase;

/**
 * Sample program demonstrating the usage of the IEssCustomMessageHandler
 * 
 * @author Satish Ramanavarapu
 *
 */
public class CustomMessageHandler {

    private static String s_userName = "system";
    private static String s_password = "password";
    
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0; // will set this to FAILURE only if err/exception occurs.
        IEssbase ess = null;
        try {
            acceptArgs(args);
            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);
            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            IEssOlapServer olapSvr = dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            
            String appName = "Sample", cubeName = "Basic";
            // As an alternative path you can retrieve the IEssCubeView instance and 
            // invoke setMessageHandler on that as well
//            IEssCubeView cv = dom.openCubeView("Test", s_olapSvrName, appName, cubeName);
            
            MyMessageHandler custMesgHandler = new MyMessageHandler();
            olapSvr.setMessageHandler(custMesgHandler);
            
            IEssCube cube = olapSvr.getApplication(appName).getCube(cubeName);
            cube.setActive();
            try {
            	loadData(cube);
            }
            catch (Exception e) {
            	System.err.println(e.getMessage());
            }
            
            // As an alternative path you can use the IEssCubeView instance to 
            // retrieve the Message Handler.
//            custMesgHandler = (MyMessageHandler)cv.getMessageHandler();

            //retrieve custom message handler state
            custMesgHandler = (MyMessageHandler)olapSvr.getMessageHandler();
            if (custMesgHandler != null)
            	custMesgHandler.printMessages();
            
            // reset custom message handler state
            if (custMesgHandler != null)
            	custMesgHandler.clearState();
            
            if (custMesgHandler != null)
            	olapSvr.setMessageHandler(custMesgHandler);
            
            // continue using other JAPI
//            cv.close();
            
		} catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Sign off.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally 
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);        
    }
    
    public static void loadData(IEssCube cube) throws EssException {
        System.out.println("Loading data to message handler in " + cube.getName() + "...");

        cube.beginDataload(true, false, false, null, IEssOlapFileObject.TYPE_RULES);
        cube.sendString("Product\tMarket\tYear\tScenario\tSales\tCOGS\n");
        cube.sendString("\"100-20\"\tTexas\tJan\tActual\t648\t123\n");
        cube.sendString("\"100-10\"\t\"New York\"\tJan\tActual\t648\t272\n");

        String [][] errs = cube.endDataload();
        for (int i=0; errs != null && i < errs.length; i++) {
        	System.out.println(errs[i][0]+ " " +errs[i][1] + " " + errs[i][2]);
        }
        System.out.println("Data Loading for message handler Complete.");
    }
    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];   
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CustomMessageHandler.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(FAILURE_CODE); // Simply end
        }
    }

}

class MyMessageHandler implements IEssCustomMessageHandler {
	public static int MSG_LVL_ERROR = 4;
	int count=0;
	int [] err_nums = new int[10];
	int [] err_lvls = new int[10];
	String[] err_strs = new String[10];

	/**
	 * This is the call back method that is invoked by JAPI lower level for
	 * processing the message.
	 * 
	 * @param messageNumber
	 *            : the message number returned by Essbase server.
	 * @param messageLevel
	 *            : the message level, it can hold one of following values. <br>
	 *            NET_MSG_NONE = 0 : not a valid message level <br>
	 *            NET_MSG_DEBUG = 1 : debug message (DEBUG only) <br>
	 *            NET_MSG_INFO = 2 : information message <br>
	 *            NET_MSG_WARNING = 3 : warning message <br>
	 *            NET_MSG_ERROR = 4 : error message - abort operation <br>
	 *            NET_MSG_SILENT = 5 : error message - don't display <br>
	 *            NET_MSG_INTERNAL = 6 : internal error (DEBUG ONLY) <br>
	 *            NET_MSG_SERIOUS = 7 : serious error - abort operation <br>
	 *            NET_MSG_FATAL = 8 : fatal error - abort server
	 * @param messageString
	 *            : the message string returned by Essbase server.
	 * @return the messageNumber : an integer data type value, which will
	 *         indicate the messageNumber that is to be used by JAPI for
	 *         processing the message returned by Essbase
	 * @throws Exception
	 */
	public int processMessage(int messageNumber, int messageLevel, String messageString) {
		err_nums[count] = messageNumber;
		err_lvls[count] = messageLevel;
		err_strs[count++] = messageString;
		System.out.println("Server message " + (count-1) + ":- Err Num: "+messageNumber + "; Mess Lvl: "+messageLevel + "; Mess Str: " +messageString);
		
		// client programs can choose to have a custom error id returned for Essbase messages which atleast 
		// qualify as an error.
		if (messageLevel >= MSG_LVL_ERROR) {
			
			// to have a custom error id 50000 returned for a Essbase error condition with id 1003014 
			// 1003014 is the Essbase error id for Unknown Member; 
			// change one of the product names(say 100-20 to 10020) in the load-data sample above to see the impact
			if (messageNumber == 1003014) {
				messageNumber = 50000;
			}
		}
		
		return messageNumber;
	}
	
	public void printMessages() {
		for (int i =0; i < count; i++)
		System.out.println("Client Message " + i+":- Num: "+err_nums[i] + "; Mess Lvl: " +err_lvls[i] 
		                    + "; Mess Str: " +err_strs[i]);
	}
	
	public void clearState() {
		count=0;
		err_nums = new int[10];
		err_lvls = new int[10];
		err_strs = new String[10];
	}
}
