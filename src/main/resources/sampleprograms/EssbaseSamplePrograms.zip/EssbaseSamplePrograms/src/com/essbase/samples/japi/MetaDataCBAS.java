/*
    File: MetaData.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;

/**
    MetaData Example does the following: Signs on to essbase domain,
    Performs various metadata operations and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    Also make sure your root domain name is essbase and that you have already
    created olap server with the same name as your localhost using the gui
    console.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class MetaDataCBAS {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "custadmin";
    private static String s_password = "custadmin";

    private static String s_olapSvrName = "ussltcovm668.solutions.glbsnet.com";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "http://ussltcovm668.solutions.glbsnet.com:13080/aps/JAPI"; // Default
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            IEssCube cube = olapSvr.getApplication("CBAS").getCube("CBAS");

            // Perform member selection query.
            performMemberSelection(cube);

            // Open the outline and do operations.
           // queryOutline(cube);

			// Call the clearActive on current Cube (Demo/Basic) before using
			// different cube (sample/basic) in same session.
            cube.clearActive();
            cube = olapSvr.getApplication("Sample").getCube("Basic");
            //queryOutline_sample_basic(cube);
		} catch (EssException x) {
            System.err.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performMemberSelection(IEssCube cube) throws EssException {
        try {
            IEssMemberSelection mbrSel = cube.openMemberSelection
                ("Sample member selection");
            mbrSel.executeQuery("Years", IEssMemberSelection.QUERY_TYPE_CHILDREN,
                IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, "Years", "", "");
            IEssIterator mbrs = mbrSel.getMembers();
            System.out.println
                ("Performing member selection (Select children of Year):");
            for (int i = 0; i < mbrs.getCount(); i++) {
                IEssMember mbr = (IEssMember)mbrs.getAt(i);
                System.out.println("Name: " + mbr.getName() +
                    ", Desc: " + mbr.getDescription() +
                    ", Level Num: " + mbr.getLevelNumber() +
                    ", Gen Num: " + mbr.getGenerationNumber() +
                    ", Child count: " + mbr.getChildCount() +
                    ", Dim Name: " + mbr.getDimensionName() +
                    ", Dim Category: " + mbr.getDimensionCategory().stringValue());
            }
            System.out.println();

            // Do another query, just to get count of children in "Qtr1"
            System.out.println
                ("Performing member selection (Get count of children of Qtr1):");
            mbrSel.executeQuery("Qtr1", IEssMemberSelection.QUERY_TYPE_CHILDREN,
                IEssMemberSelection.QUERY_OPTION_COUNTONLY, "Year", "", "");
            System.out.println("Count of Qtr1 children: " +
                mbrSel.getCountMembers() + "\n");

            // Do another query.
            System.out.println("Performing member selection: (@ichild(Product), @ichild(Market))");
            String fldSelection = "<OutputType Binary  <SelectMbrInfo ( MemberName, MemberLevel,Consolidation, MemberFormula ) ",
                   mbrSelection = "@ichild(Product), @ichild(Market)";
            mbrSel.executeQuery(fldSelection, mbrSelection);
            mbrs = mbrSel.getMembers();
            for (int i = 0; i < mbrs.getCount(); i++) {
                IEssMember mbr = (IEssMember)mbrs.getAt(i);
                System.out.println("Name: " + mbr.getName() 
                    + "\n - HIERARCHY TYPE (String): " + mbr.getHierarchyType().stringValue()
                    + "\n - Dimension Solve Order: " + mbr.getDimensionSolveOrder()                
                    + "\n - Solve Order: " + mbr.getSolveOrder());
            }
            System.out.println();

            mbrSel.close();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }
    }

    static void queryOutline(IEssCube cube) throws EssException {
        IEssCubeOutline outline = null;
        try {
            System.out.println("Performing Outline Query (find member Accounts)");
            outline = cube.openOutline();
            IEssMember mbr = outline.findMember("Accounts");
            System.out.println("Name: " + mbr.getName() +
                ", Desc: " + mbr.getDescription() +
                ", Level Num: " + mbr.getLevelNumber() +
                ", Gen Num: " + mbr.getGenerationNumber() +
                ", Child count: " + mbr.getChildCount() +
                ", Dim Name: " + mbr.getDimensionName() +
                ", Dim Category: " + mbr.getDimensionCategory().stringValue() +
                ", Alias: " + mbr.getAlias("Default"));
            outline.close();
            outline = null;
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        } finally {
            if (outline != null) {
                try {
                    outline.close();
                } catch (EssException x) {
                    System.err.println("Error: " + x.getMessage());
                }
            }
        }
    }

    static void queryOutline_sample_basic(IEssCube cube) throws EssException {
        IEssCubeOutline outline = null;
        try {
            System.out.println("\nOpening sample/basic outline...");
            outline = cube.openOutline(true, false, false);
            System.out.println("Shared members for 200-20...");
            IEssIterator sharedMbrs = outline.getSharedMembers("200-20");
            for (int i = 0, cnt = sharedMbrs.getCount(); i < cnt; i++) {
                IEssMember mbr = (IEssMember)sharedMbrs.getAt(i);
                System.out.println("Shared member name: " + mbr.getName());
            }

            System.out.println("\nGetting associated attributes (for Product)...");
            IEssMember mbr = outline.findMember("Product");
            IEssIterator atts = mbr.getAssociatedAttributes();
            for (int i = 0, cnt = atts.getCount(); i < cnt; i++)
                System.out.println("Attribute: " + atts.getAt(i));

            System.out.println("\nGetting Dimension (Market) UDAs...");
            IEssDimension dim = outline.findDimension("Market");
            String[] udas = dim.getUDAs();
            for (int i = 0; i < udas.length; i++)
                System.out.println("UDA: " + udas[i]);

            outline.close();
            outline = null;
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        } finally {
            if (outline != null) {
                try {
                    outline.close();
                } catch (EssException x) {
                    System.err.println("Error: " + x.getMessage());
                }
            }
        }
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + MetaDataCBAS.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
