package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.IEssbase;

/**
 * Utility class for performing setup/teardown on an Essbase connection and
 * executing a custom operation.
 * 
 * @author jasonwjones
 *
 */
public class CubeOpWrapper {

	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "custadmin";
	private static String s_password = "custadmin";
	private static String s_olapSvrName = "ussltcovm668.solutions.glbsnet.com";
	/*
	 * Possible values for s_provider: "Embedded" or
	 * "http://localhost:13080/aps/JAPI"
	 */
	private static String s_provider = "http://ussltcovm668.solutions.glbsnet.com:13080/aps/JAPI"; // Default

	public interface CubeOpDelegate<E> {
		public E run(IEssCube cube) throws EssException;
	}

	public static <E> E execute(CubeOpDelegate<E> delegate) throws EssException {
		// System.setProperty("ESS_ES_HOME", "test");
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;

		// Sign On to the Provider
		IEssDomain dom = ess.signOn(s_userName, s_password, false, null, s_provider);

		// Open connection with olap server and get the cube.
		olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
		olapSvr.connect();
		IEssCube cube = olapSvr.getApplication("CBAS").getCube("CBAS");
		return delegate.run(cube);

	}

}
