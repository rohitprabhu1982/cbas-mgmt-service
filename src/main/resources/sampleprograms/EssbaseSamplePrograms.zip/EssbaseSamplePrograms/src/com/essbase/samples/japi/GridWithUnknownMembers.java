/*
    File: GridWithUnknownMembers.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.datasource.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    This sample shows how to detect unknown members in data query.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class GridWithUnknownMembers {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_appName = "demo";
    private static String s_cubeName = "basic";
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            cv = dom.openCubeView("Data Query Example", s_olapSvrName, s_appName,
                s_cubeName);

            // Enable option to display unknown members.
            cv.setDisplayUnknownMembers(true);
            cv.updatePropertyValues();

            // Create a grid with one unknown member.
            IEssGridView grid = cv.getGridView();
            grid.setSize(3, 5);
            grid.setValue(0, 2, "Product");
            grid.setValue(0, 3, "Market");
            grid.setValue(1, 2, "Jan"); ;
            grid.setValue(1, 3, "Feb");
            grid.setValue(1, 4, "MarNotExisting");
            grid.setValue(2, 0, "Actual");
            grid.setValue(2, 1, "Sales");

            cv.performOperation(cv.createIEssOpRetrieve());

            // Get the result and print the output.
            int cntRows = grid.getCountRows(), cntCols = grid.getCountColumns();
            System.out.print("Data query result\n-----------------\n");
            for (int i = 0; i < cntRows; i++) {
                for (int j = 0; j < cntCols; j++)
                    System.out.print(grid.getValue(i, j) + "\t");
                System.out.println();
            }
            System.out.println("\n");

            // Print unknown member names in the last operation.
            String[] unknownMbrs = grid.getUnknownMemberNames();
            System.out.println("Unknown members:\n---------------");
            if (unknownMbrs != null)
                for (int i = 0; i < unknownMbrs.length; i++)
                    System.out.println(unknownMbrs[i]);
        } catch (EssException x){
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + GridWithUnknownMembers.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
