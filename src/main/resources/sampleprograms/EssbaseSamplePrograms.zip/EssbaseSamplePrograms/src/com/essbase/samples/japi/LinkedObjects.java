/*
    File: LinkedObjects.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;
import java.io.File;

/**
    LinkedObjects does the following: Signs on to essbase domain,
    Opens a cube view, Performs Retrieve, Performs LRO operations, and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class LinkedObjects {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_domainName = "essbase";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_appName = "demo";
    private static String s_cubeName = "basic";
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            cv = dom.openCubeView("Linked Objects", s_olapSvrName, s_appName,
                s_cubeName);

            // Perform retrieve and do lro operations.
            performCubeViewOperation(ess, cv);
            System.out.println("LinkedObjects Completed.");
		} catch (EssException x){
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
		} finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performCubeViewOperation(IEssbase ess, IEssCubeView cv)
            throws EssException {
        // Create a grid view with the input for the operation.
        IEssGridView grid = cv.getGridView();
        grid.setSize(2, 5);
        grid.setValue(0, 1, "Market");
        grid.setValue(0, 2, "Product");
        grid.setValue(0, 3, "Accounts"); ;
        grid.setValue(0, 4, "Scenario");
        grid.setValue(1, 0, "Year");

        // Create the operation specification.
        IEssOpRetrieve op = cv.createIEssOpRetrieve();

        // Perform the operation.
        cv.performOperation(op);

        IEssDataCell dataCell = (EssDataCell)grid.getCell(1, 1);
        System.out.println("Checking on data cell at (1, 1)...\n");
        String[] mbrComb = dataCell.getMemberCombination();
        System.out.print("Member combination: ");
        for (int i = 0; i < mbrComb.length; i++)
            System.out.print((i != 0 ? ", " : "") + mbrComb[i]);
        System.out.println("\n");

        System.out.println("Creating linked objects...\n");
        dataCell.createLinkedObject(
            IEssLinkedObject.EEssLinkedObjectType.CELL_NOTE,
            "This is cell note.", "");
        dataCell.createLinkedObject(IEssLinkedObject.EEssLinkedObjectType.URL,
            "This is url.", "www.hyperion.com");
        String tmpFile = createTempFile();
        if (tmpFile != null) { // Show case how to associate a File Type of LRO if it was created successfully.
            dataCell.createLinkedObject(IEssLinkedObject.EEssLinkedObjectType.FILE,
                                        "This is file", tmpFile);
        }

        System.out.println("Listing linked objects...");
        IEssIterator linkedObjs = dataCell.getLinkedObjects();
        int countObjs = linkedObjs.getCount();
        for (int i = 0; i < countObjs; i++) {
            IEssLinkedObject linkedObj = (IEssLinkedObject)linkedObjs.getAt(i);
            System.out.println("Id: " + linkedObj.getId());
            System.out.println("Type: " + linkedObj.getType());
            System.out.println("Creator: " + linkedObj.getCreatedBy());
            System.out.println("Last Update: " + linkedObj.getLastUpdateTime());
            if (linkedObj.getType() ==
                    IEssLinkedObject.EEssLinkedObjectType.CELL_NOTE) {
                System.out.println("Note: " + linkedObj.getDescription());
            } else {
                System.out.println("Object Name: " + linkedObj.getObjectName());
                System.out.println("Description: " + linkedObj.getDescription());
            }
        }

        if (countObjs > 0) {
            System.out.println("\nDeleting first linked object...");
            dataCell.deleteLinkedObject((IEssLinkedObject)linkedObjs.getAt(0));

            System.out.println("\nListing linked objects again...");
            linkedObjs = dataCell.getLinkedObjects();
            countObjs = linkedObjs.getCount();
            for (int i = 0; i < countObjs; i++) {
                IEssLinkedObject linkedObj = (IEssLinkedObject)linkedObjs.getAt(i);
                    System.out.println("Id: " + linkedObj.getId());
                System.out.println("Type: " + linkedObj.getType());
                System.out.println("Creator: " + linkedObj.getCreatedBy());
                System.out.println("Last Update: " + linkedObj.getLastUpdateTime());
                if (linkedObj.getType() ==
                        IEssLinkedObject.EEssLinkedObjectType.CELL_NOTE) {
                    System.out.println("Note: " + linkedObj.getDescription());
                } else {
                    System.out.println("Object Name: " + linkedObj.getObjectName());
                    System.out.println("Description: " + linkedObj.getDescription());

                    if (linkedObj.getType() ==
                            IEssLinkedObject.EEssLinkedObjectType.FILE) {
                        // Modify the following line to suit your setup.
                    	String tmpDir = System.getProperty("java.io.tmpdir");
                    	if (!tmpDir.endsWith(File.separator))
                    		tmpDir = tmpDir + File.separator;

                        String clientFileName= tmpDir + linkedObj.getObjectName();
                        System.out.println("Getting file object to " + clientFileName + "...");
                        linkedObj.getObject(clientFileName);
                    }
                }
            }
        }

        System.out.println("\nDeleting all linked objects...");
        dataCell.deleteLinkedObjects();
    }

    // To show case how a FILE type LRO can be assoc'd with a DataCell,
    // we have this helper method to create a dummy file. 
    static String createTempFile() {
        try {
            // Creates a tmp file under the User Temp Dir
            File tmpF = File.createTempFile("lroDemo", ".tmp");
            System.out.println("Tmp File located at: " + tmpF.getAbsolutePath());
            return tmpF.getAbsolutePath();
        }
        catch (Exception e) {
            System.err.println("Unable to create a dummy file to showcase File Type of LRO. ERR:" + e.getMessage());
            	return null;
        }
    }
        
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + LinkedObjects.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
