package com.essbase.samples.japi;

import java.io.File;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.EssCustObjDefinition;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssCustomObject;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.datasource.IEssCustomObject.CustomObjectCopyOption;
import com.essbase.api.datasource.IEssCustomObject.CustomObjectType;
import com.essbase.api.session.IEssbase;
import com.essbase.samples.japi.Connect;

/**
 * Sample Java program to demonstrate usage of Essbase Custom Objects Java APIs, 
 * supported primarily for Oracle Sales Analyser (OSA) tool.
 * 
 * @author Balaji Sundaresan
 * @since 11.1.2.0.01
 */
public class CustomObjects {

    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "COgroup";
    private static String s_password = "password";
    
    private static String s_olapSvrName = "10.148.216.119:1423";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_appName = "Sample";
    private static String s_dbName = "Basic";
    private static final String TMP_DIR = System.getProperty("java.io.tmpdir");
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0; // will set this to FAILURE only if err/exception occurs.
        IEssbase japiSession = null;
        try {
            acceptArgs(args);
            // Create JAPI instance.
            japiSession = IEssbase.Home.create(IEssbase.JAPI_VERSION);
            
            // Sign On to the Provider
            IEssOlapServer olapSvr 
                = japiSession.signOn(s_userName, s_password, false, null, s_provider, s_olapSvrName);
            System.out.println("Connected to Analyic server '" +olapSvr.getName()+ "'.");
            
            // List Schemas
            String[] schemas = listSchemas(olapSvr);
            
            //schemas = new String[]{"essexer", "group"};
            IEssCube cube = olapSvr.getApplication(s_appName).getCube(s_dbName);
            
            // List Custom Objects by Schema...
            for (int i = 0; i < schemas.length; i++) {
                listCustomObjects(cube, schemas[i], null, null);	
			}
            
            // List objects by Types... 
            listCustomObjects(cube, null, CustomObjectType.CUSTOBJ_CUSTOMSETS, null);
            listCustomObjects(cube, null, CustomObjectType.CUSTOBJ_CUSTOMMEASURES, null);
            listCustomObjects(cube, null, CustomObjectType.CUSTOBJ_CUSTOMAGGREGATES, null);
            listCustomObjects(cube, null, CustomObjectType.CUSTOBJ_LAYOUTS, null);
            listCustomObjects(cube, null, CustomObjectType.CUSTOBJ_ALL, null);

            // List objects by Dimension... 
            listCustomObjects(cube, null, null, "Product");
            
            // List objects by Type and Dimension
            listCustomObjects(cube, null, CustomObjectType.CUSTOBJ_CUSTOMSETS, "Product");
            
            // List objects by Schema, Type and Dimension
            listCustomObjects(cube, schemas[0], CustomObjectType.CUSTOBJ_CUSTOMSETS, "Product");
            
            // List all custom objects across all schemas...
            IEssCustomObject[] allCustObjs = listCustomObjects(cube, null, null, null);
            
            // Get Custom Objects' definition
            getCustomObjectDefinitions(allCustObjs);
            
            // Validate Custom Objects...
            validateCustomObjects(allCustObjs);
            
            // Delete all the existing Custom Objects
            deleteCustomObjects(allCustObjs);
            
            // Create some custom objects...
            createCustomObjects(cube, schemas[0]);
            
            // Update custom objects...
            updateCustomObjects(cube, schemas[0]);

            copyCustomObjects(cube, schemas[0], (schemas.length > 1)?schemas[1]:null);
            
            renameCustomObjects(cube, schemas[0]);
            
            // List Custom Objects Before export...
            allCustObjs = listCustomObjects(cube, null, null, null);
            
            // Export all custom objects under each schemas 
            for (int i = 0; i < schemas.length; i++) {
				exportCustomObjects(cube, schemas[i]);
			}
            
            // delete all again so that import can be tried...
            deleteCustomObjects(allCustObjs);
            
            // Import custom objects...
            for (int i = 0; i < schemas.length; i++) {
	            importCustomObjs(cube, schemas[i]);
			}
            
            // List Custom Objects after import...
            listCustomObjects(cube, null, null, null);
            
		} catch (EssException x) {
	        System.err.println("Error: " + x.getMessage());
	        statusCode = FAILURE_CODE;
	    } finally {
	        // Sign off.
	        try {
	            if (japiSession != null && japiSession.isSignedOn() == true)
	            	japiSession.signOff();
	        } catch (EssException x) {
	            System.err.println("Error: " + x.getMessage());
	        }
	    }
	    // Set status to failure only if exception occurs and do abnormal termination
	    // otherwise, it will by default terminate normally
	    if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);     	
    }
    
	public static String[] listSchemas(IEssOlapServer esbSvr) throws EssException {
		String operDesc = "Listing Schemas";
		printMethodHeader(operDesc);
		String[] schemas = esbSvr.listSchemas();
		for (int i = 0; i < schemas.length; i++) {
			System.out.println("Schema " + i + ": " + schemas[i]);	
		}
		printMethodFooter(operDesc);
		return schemas;
	}
	
	public static IEssCustomObject[] listCustomObjects(IEssCube cube, String schema, CustomObjectType type, String dim) throws EssException {
		String operDesc = "Listing Custom Objects ";
		operDesc += (schema!=null) ? " [schema="+schema+"]" : "";
		operDesc += (type!=null) ? " [type="+type+"]" : "";
		operDesc += (dim!=null) ? " [dimension="+dim+"]" : "";
		printMethodHeader(operDesc);
		
		IEssCustomObject[] coList = cube.getCustomObjects(schema, type, dim);
		for (int i = 0; i < coList.length; i++) {
			System.out.println(i+": " + coList[i].getType() 
								+ ", " + coList[i].getSchemaName() 
								+ ", "  + coList[i].getName());
		}
		
		printMethodFooter(operDesc);
		return coList;
	}
	
	/* NOTE: The "coList" may include CustomObject ids that this user may not have access to. 
	 * In such a case, the IEssCustomObject.getDefinition() API will throw Exception
	 * indicating that user doesn't have access that to object definition. 
	 */
	public static void getCustomObjectDefinitions(IEssCustomObject[] coList) throws EssException {
    	String op = "Get Metatdata Definitions of Custom Objects";
		printMethodHeader(op);
        for (int i = 0; i < coList.length; i++) {
        	String coID = ""+i+": " + coList[i].getType() 
					+ ", " + coList[i].getSchemaName() 
					+ ", "  + coList[i].getName();
        	try {
	        	EssCustObjDefinition coDef = coList[i].getDefinition();
				System.out.println(coID
									+ ", "  + coList[i].isEditable()
									+ " = {" 
									+ "desc="+coDef.description
									+ "; expr="+coDef.expression
									+ "; dimensionality="+coDef.dimensionality
									+ "}");
        	} catch (EssException e) {
				System.out.println (coID + ": " + e.getMessage());
			}
		}
		printMethodFooter(op);
	}
	
	public static void deleteCustomObjects(IEssCustomObject[] coList) throws EssException {
    	String op = "Deleting Custom Objects";
		printMethodHeader(op);
        for (int i = 0; i < coList.length; i++) {
			try {
				coList[i].delete(); 				
				System.out.println(i+": " + coList[i].getType() 
						+ ", " + coList[i].getSchemaName() 
						+ ", "  + coList[i].getName() + " -> DELETED SUCCESSFULLY");
			} catch (Exception e) {
				System.out.println(i+": " + coList[i].getType() 
						+ ", " + coList[i].getSchemaName() 
						+ ", "  + coList[i].getName() + " -> DELETION ERROR: " + e.getMessage()); 
			}
		}
		printMethodFooter(op);
	}
	
	public static void createCustomObjects(IEssCube cube, String schema) throws EssException {
		String op = "Creating all types of custom objects";
		printMethodHeader(op);
		IEssCustomObject coSet1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_CUSTOMSETS, "co_set_1");
		EssCustObjDefinition coSet1Def = new EssCustObjDefinition();
		coSet1Def.description = "Sample.Basic Set1";
		coSet1Def.expression = "{[100], [200]}";
		coSet1Def.dimensionality = "Product";
		coSet1.setDefinition(coSet1Def);
		
		IEssCustomObject coMeasure1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_CUSTOMMEASURES, "co_measure_1");
		EssCustObjDefinition coMeasure1Def = new EssCustObjDefinition();
		coMeasure1Def.description = "Sample.Basic Measure1";
		coMeasure1Def.expression = "Sales";
		coMeasure1Def.dimensionality = "Measures";
		coMeasure1.setDefinition(coMeasure1Def);
		
		IEssCustomObject coAggr1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_CUSTOMAGGREGATES, "co_aggr_1");
		EssCustObjDefinition coAggr1Def = new EssCustObjDefinition();
		coAggr1Def.description = "Sample.Basic Aggregate1";
		coAggr1Def.expression = "[Sales]+[Profit]";
		coAggr1Def.dimensionality = "Measures";
		coAggr1.setDefinition(coAggr1Def);
		
		IEssCustomObject coLayout1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_LAYOUTS, "co_layout_1");
		EssCustObjDefinition coLayout1Def = new EssCustObjDefinition();
		coLayout1Def.description = "Sample.Basic Layout1";
		coLayout1Def.expression = "select {[100], [200]} on columns from sample.basic";
		coLayout1Def.dimensionality = "Product";
		coLayout1.setDefinition(coLayout1Def);
		coLayout1.setEditable(false);
		
		coSet1.create();
		coMeasure1.create();
		coAggr1.create();
		coLayout1.create();
		printMethodFooter(op);
	}
	
	public static void updateCustomObjects(IEssCube cube, String schema) throws EssException {
		String op = "Updating few custom objects";
		printMethodHeader(op);
		IEssCustomObject coSet1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_CUSTOMSETS, "co_set_1");
		EssCustObjDefinition coSet1Def = new EssCustObjDefinition();
		coSet1Def.description = "Sample.Basic Set1 (Updated)";
		coSet1Def.expression = "{[100], [200], [300]}";
		coSet1Def.dimensionality = "Product";
		coSet1.setDefinition(coSet1Def);
		coSet1.setEditable(false);
		
		IEssCustomObject coLayout1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_LAYOUTS, "co_layout_1");
		EssCustObjDefinition coLayout1Def = new EssCustObjDefinition();
		coLayout1Def.description = "Sample.Basic Layout1 (Updated)";
		coLayout1Def.expression = "select {[Jan], [Feb]} on columns from sample.basic";
		coLayout1Def.dimensionality = "Time";
		coLayout1.setDefinition(coLayout1Def);
		coLayout1.setEditable(true);
		
		coSet1.update();
		coLayout1.update();
		printMethodFooter(op);
	}

	public static void copyCustomObjects(IEssCube cube, String schema1, String schema2) throws EssException {
		String op = "Copy few custom objects";
		printMethodHeader(op);
		
		IEssCustomObject cSetToCopy = cube.getCustomObjectInstance(schema1, CustomObjectType.CUSTOBJ_CUSTOMSETS, "co_set_1");
		IEssCustomObject cMeasureToCopy = cube.getCustomObjectInstance(schema1, CustomObjectType.CUSTOBJ_CUSTOMMEASURES, "co_measure_1");
		
		// Copy to other schema with same name...
		if (schema2 != null) {
		cSetToCopy.copyTo(schema2, cSetToCopy.getName(), CustomObjectCopyOption.COPYNEWER_CONFLICT);
		cMeasureToCopy.copyTo(schema2, cMeasureToCopy.getName(), CustomObjectCopyOption.ERROROUT_CONFLICT);
		}
		
		// Copy within same schema with different name...
		cSetToCopy.copyTo(schema1, "co_set_1_replica", CustomObjectCopyOption.COPYNEWER_CONFLICT);
		//cSetToCopy.copyTo(schema2, "co_set_1", CustomObjectCopyOption.ACCEPTEXISTING_CONFLICT);
		 
		printMethodFooter(op);
	}
	
	public static void renameCustomObjects(IEssCube cube, String schema) throws EssException {
		String op = "Renaming few custom objects";
		printMethodHeader(op);
		IEssCustomObject coMeasure1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_CUSTOMSETS, "co_set_1");
		IEssCustomObject coAggr1 = cube.getCustomObjectInstance(schema, CustomObjectType.CUSTOBJ_CUSTOMAGGREGATES, "co_aggr_1");
		coMeasure1.rename("co_set_1_renamed");
		coMeasure1.rename("co_aggr_1_renamed");
		printMethodFooter(op);
	}
	public static void validateCustomObjects(IEssCustomObject[] custObjs) {
		String op = "Validating custom objects";
		printMethodHeader(op);
		for (int i = 0; i < custObjs.length; i++) {
			String prefixStrToPrint = i+":" + custObjs[i].getSchemaName()+"/"+custObjs[i].getName();
			try {
				custObjs[i].validate();
				System.out.println(prefixStrToPrint + "-> Valid Object");
			}
			catch (EssException e) {
				System.out.println(prefixStrToPrint + "-> Invalid Object [Error Info: "+e.getMessage()+"]");
			}
		}
		printMethodFooter(op);
	}

	public static void importCustomObjs(IEssCube cube, String schema) throws EssException {
		printMethodHeader("Importing schema " + schema + " to Cube");
		cube.importCustomObjects(TMP_DIR + File.separator + schema + ".xml");
		printMethodFooter("Importing schema " + schema + " to Cube");
	}

	public static void exportCustomObjects(IEssCube cube, String schema) throws EssException {
		printMethodHeader("Exporting schema " + schema + " from Cube");
		// Export to %TEMP%\<schema>.xml
		cube.exportCustomObjects(schema, TMP_DIR + File.separator + schema + ".xml");
		printMethodFooter("Exporting schema " + schema + " from Cube");
	}

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];   
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
            if (args.length == 6 && args[4] != null && args[5] != null) { // app & db
            	s_appName = args[4];
            	s_dbName = args[5];            	
            }
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + Connect.class.getName() + " <user> <password> <analytic server> <provider> [<application> <database>]");
            System.exit(FAILURE_CODE); // Simply end
        }
    }
    
    private static void printMethodHeader(String str) {
    	System.out.println("--- [BEGIN] "+str+" --- ");   	
    }
    private static void printMethodFooter(String str) {
		System.out.println("--- [END]   "+str+" --- \n");   	
    }    
}