/*
    File: SecurityFilter.java 1.1, 2007-04-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.datasource.IEssOlapApplication.EEssOlapApplicationAccess;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.EssGlobalStrings;
import com.essbase.api.session.IEssbase;
import com.essbase.api.datasource.IEssOlapUser;

/**
 * Sample for testing security filter API.
 * @author sramanav
 *
 */
public class SecurityFilter {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_appName = "Sample";
    private static String s_cubeName = "Basic";
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0; // will set this to FAILURE only if err/exception occurs.
        IEssbase ess = null;
        try {
            acceptArgs(args);
            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);
            // Sign On to the Provider
            IEssDomain dom = ess.signOn(s_userName, s_password, false, null, s_provider);
            IEssOlapServer olapSvr = dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // creating users for unit test
            IEssOlapUser user1 = olapSvr.createOlapUser("User1", "password");
            IEssOlapUser user2 = olapSvr.createOlapUser("User2", "password");

//            IEssOlapUser user1 = olapSvr.getOlapUser("User1");
//            IEssOlapUser user2 = olapSvr.getOlapUser("User2");
//            user1.setAccess(0x0137); // 137 for Access Databases
            
            IEssOlapApplication app = olapSvr.getApplication(s_appName);
            IEssCube cube = app.getCube(s_cubeName);
            System.out.println("Access type for user is: "+ app.getUserOrGroupAccess(user1.getName()));
            app.setUserOrGroupAccess(user1.getName(), EEssOlapApplicationAccess.LOAD_APPLICATION);
//            app.setUserOrGroupAccess(user1.getName(), EEssOlapApplicationAccess.DESIGN_APPLICATION);
            System.out.println("Access type for user is: "+ app.getUserOrGroupAccess(user1.getName()));
            
            verifyFilterAPI(cube);

            // deleting users created for unit test
            user1.deleteUser();
            user2.deleteUser();
            
		} catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Sign off.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally 
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);        
    }
    public static void verifyFilterAPI(IEssCube cube) throws EssException {
//    	IEssCube.IEssSecurityFilter filter = cube.getSecurityFilter("TestFilter1");
//    	IEssCube.IEssSecurityFilter copyFilter = cube.getSecurityFilter("TestFilter1CopyRenamed");
    	cube.setUserOrGroupAccess("User1", IEssCube.EEssCubeAccess.FILTER_ACCESS);
    	
    	String [] rowStrings = {"@IDESCENDANTS(Scenario)", "@IALLANCESTORS (Scenario)"};
    	IEssCube.IEssSecurityFilter filter = cube.createSecurityFilter("TestFilter1");

    	System.out.println("\nList after Creating ...");
    	getFilterList(cube);
   	
    	IEssCube.IEssSecurityFilter setFilter = cube.setSecurityFilter(filter.getName(), true, IEssCube.EEssCubeAccess.READ_WRITE_CUBE_DATA);
    	for (int i =0; i < rowStrings.length; i++) {
    		setFilter.setFilterRow(rowStrings[i], (short)EssGlobalStrings.ESS_ACCESS_WRITE);
    	}
    	setFilter.setFilterRow("", (short)0);

		System.out.println("\nList after Setting ...");
    	getFilterList(cube);
		
    	setFilter.copyFilter(filter.getName() + "Copy");
    	System.out.println("\nList after Copying ...");
    	getFilterList(cube);
    	
    	IEssCube.IEssSecurityFilter copyFilter = cube.getSecurityFilter(setFilter.getName() + "Copy"); 
    	
    	copyFilter.rename(copyFilter.getName() + "Renamed");
    	System.out.println("\nList after Renaming ...");
    	getFilterList(cube);

    	String [] users = {"user1", "user2"};
    	System.out.println("\nSetting users for " + copyFilter.getName());
    	cube.setSecurityFilterList(copyFilter, users);
    	
    	users = copyFilter.getSecurityFilterList();
    	System.out.println("\nList of users for " + copyFilter.getName() + " is:");
    	for (int i = 0; i < users.length; i++) {
    		System.out.println(users[i]);
    	}
    	
    	System.out.println("\nDeleting access to users for " + copyFilter.getName());
    	users = new String[0];
    	cube.setSecurityFilterList(copyFilter, users);

    	users = copyFilter.getSecurityFilterList();
    	System.out.println("\nList of users for " + copyFilter.getName() + " after deleting access is:");
    	for (int i = 0; i < users.length; i++) {
    		System.out.println(users[i]);
    	}
    	
    	IEssCube.IEssSecurityFilter filter1 = cube.getSecurityFilter("TestFilter1");
    	System.out.println("\nDetails of getSecurityFilter for " + filter1.getName());
    	for (int i = 0; i < rowStrings.length; i++) {
    		IEssCube.IEssSecurityFilter.IEssFilterRow filtRow = filter1.getFilterRow();
    		System.out.print("\tString:" + filtRow.getRowString());
    		System.out.println("\tAccess:" + filtRow.getAccess());  	
    	}
		filter1.getFilterRow();
    	
    	System.out.println("\nVerifying Filters ...");
    	try {
    		filter1.verifyFilter(rowStrings);
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    	
		System.out.println("Verified Filters.");
    	
		// Comment out the below part for verifying the above executed API through AAS console,
		// or else this sample cleans up the above test data.
    	filter1.delete();
    	copyFilter.delete();
    	System.out.println("\nList of filters after Deleting ...");
    	getFilterList(cube);
    	cube.setUserOrGroupAccess("User1", IEssCube.EEssCubeAccess.NONE);
    }

// Original API design    
//    public static void verifyFilterAPI(IEssCube cube) throws EssException {
////    	IEssCube.IEssSecurityFilter filter = cube.getSecurityFilter("TestFilter1");
////    	IEssCube.IEssSecurityFilter copyFilter = cube.getSecurityFilter("TestFilter1CopyRenamed");
//    	cube.setUserOrGroupAccess("User1", IEssCube.EEssCubeAccess.FILTER_ACCESS);
//    	
//    	String [] rowStrings = {"@IDESCENDANTS(Scenario)", "@IALLANCESTORS (Scenario)"};
//    	IEssCube.IEssSecurityFilter filter = cube.createSecurityFilter("TestFilter1");
//    	for (int i =0; i < rowStrings.length; i++) {
//    		filter.setFilterRow(rowStrings[i], IEssCube.EEssCubeAccess.READ_CUBE_DATA);
//    	}
//    	filter.setFilterRow("", IEssCube.EEssCubeAccess.READ_CUBE_DATA);
//    	
//    	System.out.println("\nList after Creating ...");
//    	getFilterList(cube);
//   	
//    	cube.setSecurityFilter(filter.getName(), true, IEssCube.EEssCubeAccess.READ_WRITE_CUBE_DATA);
//    	for (int i =0; i < rowStrings.length; i++) {
//    		filter.setFilterRow(rowStrings[i], IEssCube.EEssCubeAccess.READ_WRITE_CUBE_DATA);
//    	}
//		filter.setFilterRow("", IEssCube.EEssCubeAccess.READ_CUBE_DATA);
//
//		System.out.println("\nList after Setting ...");
//    	getFilterList(cube);
//		
//    	IEssCube.IEssSecurityFilter copyFilter = filter.copy(filter.getName() + "Copy");
//    	System.out.println("\nList after Copying ...");
//    	getFilterList(cube);
//    	
//    	copyFilter.rename(copyFilter.getName() + "Renamed");
//    	System.out.println("\nList after Renaming ...");
//    	getFilterList(cube);
//
//    	String [] users = {"user1", "user2"};
//    	System.out.println("\n Setting users for " + copyFilter.getName());
//    	cube.setSecurityFilterList(copyFilter, users);
//    	
//    	users = new String[0];
//    	cube.setSecurityFilterList(copyFilter, users);
//    	
//    	users = copyFilter.getSecurityFilterList();
//    	System.out.println("\nList of users for " + copyFilter.getName() + " is:");
//    	for (int i = 0; i < users.length; i++) {
//    		System.out.println(users[i]);
//    	}
//    	
//    	IEssCube.IEssSecurityFilter filter1 = cube.getSecurityFilter("TestFilter1");
//    	System.out.println("\nDetails of getSecurityFilter for " + filter1.getName());
//    	for (int i = 0; i < rowStrings.length; i++) {
//    		Object[] filtRow = filter1.getFilterRow();
//    		System.out.print("\tString:" + filtRow[0]);
//    		System.out.println("\tAccess:" + ((IEssCube.EEssCubeAccess)filtRow[1]).intValue());
//    	}
//		filter1.getFilterRow();
//    	
//    	System.out.println("\nVerifying Filters ...");
//    	try {
//    		filter1.verifyFilter();
//    		
//    		for (int i =0; i < rowStrings.length; i++) {
//    			filter.verifyFilterRow(rowStrings[i]);
//    		}
//    		filter.verifyFilterRow(null);
//    	}
//    	catch (Exception e) {
//    		e.printStackTrace();
//    	}
//    	
//		System.out.println("Verified Filters.");
//    	
//    	filter1.delete();
//    	copyFilter.delete();
//    	System.out.println("\nList of filters after Deleting ...");
//    	getFilterList(cube);
//    	cube.setUserOrGroupAccess("User1", IEssCube.EEssCubeAccess.NONE);
//    }


    public static void createFilter(IEssCube cube, String name) throws EssException {
    	IEssCube.IEssSecurityFilter filter1 = cube.createSecurityFilter(name);
    	filter1.setFilterRow("@IDESCENDANTS(Scenario)", (short)EssGlobalStrings.ESS_ACCESS_READ);
    	cube.setUserOrGroupAccess("User1", IEssCube.EEssCubeAccess.FILTER_ACCESS);
    }
    
    public static void getFilterList(IEssCube cube) throws EssException {
    	IEssIterator iterator = cube.getSecurityFiltersWithNameOnly();
    	for (int i=0; i < iterator.getCount(); i++) {
    		IEssCube.IEssSecurityFilter filter = (IEssCube.IEssSecurityFilter)iterator.getAt(i);
    		IEssCube.IEssSecurityFilter.IEssFilterRow row = filter.getFilterRow();
    		System.out.println("Filter Name: "+ filter.getName() + ", Access: "+ filter.getAccess()
    				+ ", Row: "+ filter.getFilterRow());    	}
    }

    public static void deleteFilters(IEssCube cube) throws EssException {
    	IEssIterator iterator = cube.getSecurityFiltersWithNameOnly();
    	for (int i=0; i < iterator.getCount(); i++) {
    		IEssCube.IEssSecurityFilter filter = (IEssCube.IEssSecurityFilter)iterator.getAt(i);
    		System.out.println("Deleting filter: "+ filter.getName());
    		filter.delete();
    	}
    }
    

    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];   
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + SecurityFilter.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(FAILURE_CODE); // Simply end
        }
    }

}
