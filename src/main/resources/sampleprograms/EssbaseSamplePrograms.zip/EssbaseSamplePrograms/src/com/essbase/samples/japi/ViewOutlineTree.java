/*
    File: ViewOutlineTree.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;

/**
    ViewOutlineTree Example does the following: Signs on to essbase domain,
    Performs listing all members in outline and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class ViewOutlineTree {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default 
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try { 
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            IEssCube cube = olapSvr.getApplication("Sample").getCube("Basic");

            listOutlineMembers(cube);
            System.out.println("\nOutline Viewing sample complete.");
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void listOutlineMembers(IEssCube cube) throws EssException {
        IEssCubeOutline otl = null;
        try {
            otl = cube.openOutline();
            System.out.println("Outline information\n-------------------");
            System.out.println("Count of enabled DTS members: " + otl.getCountEnabledDTSMembers());

            System.out.println("\nListing all ouline members in cube " +
                cube.getApplication().getName() + "/" + cube.getName());
            System.out.println("-----------------------------------------------");
            IEssIterator dims = otl.getDimensions();
            for (int i = 0, cntTabs = 0; i < dims.getCount(); i++) {
                IEssDimension dim = (IEssDimension)dims.getAt(i);
                listOutlineMembers_helper(dim.getDimensionRootMember(), cntTabs);
            }
            otl.close();
            otl = null;
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        } finally {
            if (otl != null) {
                try {
                    otl.close();
                } catch (EssException x) {
                    System.err.println("Error: " + x.getMessage());
                }
            }
        }
    }

    static void listOutlineMembers_helper(IEssMember mbr, int cntTabs)
            throws EssException {
        for (int i = 0; i < cntTabs; i++)
            System.out.print("\t");
        System.out.println(mbr.getName());

        boolean fetchAllProps = false;
        IEssIterator mbrs = mbr.getChildMembers(fetchAllProps);
        ++cntTabs;
        for (int i = 0; i < mbrs.getCount(); i++)
            listOutlineMembers_helper((IEssMember)mbrs.getAt(i), cntTabs);
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + ViewOutlineTree.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}