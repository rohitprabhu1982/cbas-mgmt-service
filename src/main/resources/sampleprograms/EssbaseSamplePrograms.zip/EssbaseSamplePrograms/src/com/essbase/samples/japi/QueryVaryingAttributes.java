package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.metadata.IEssCubeOutline;
import com.essbase.api.metadata.IEssDimension;
import com.essbase.api.metadata.IEssIndepMbrNamesSet;
import com.essbase.api.metadata.IEssIndepMbrsSet;
import com.essbase.api.metadata.IEssMember;
import com.essbase.api.metadata.IEssMemberSelection;
import com.essbase.api.metadata.IEssMemberWithIndepMbrsSet;
import com.essbase.api.metadata.IEssVaryingAttributeQuery;
import com.essbase.api.session.IEssbase;

/**
 * QueryVaryingAttributes Example does the following: Signs on to essbase
 * domain, Opens a cube. Does a member selection and queries for varying
 * attributes and Signs Off. In order for this sample to work in your
 * environment, make sure to change the s_* to suit your environment.
 * 
 * @author Amit Doshi
 * @version 1.0 31 Jan 08
 */

public class QueryVaryingAttributes {
	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "system";
	private static String s_password = "password";
	private static String s_olapSvrName = "localhost";
	/*
	 * Possible values for s_provider: "Embedded" or
	 * "http://localhost:13080/aps/JAPI"
	 */
	private static String s_provider = "Embedded"; // Default
	private static final int FAILURE_CODE = 1;
	 
	/* Modify the application and cube name to suit your setup
	 * (please note by default Essbase doesn't ship any Database by
	 * name "Sample/BasicVA". The below cube name is only for
	 * demonstration purposes). 
	 */
	private static String s_appName = "Sample";    
	private static String s_cubeName = "BasicVA";
	
	public static void main(String[] args) {
		int statusCode = 0;
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;
		try {
			acceptArgs(args);

			// Create JAPI instance.
			ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

			// Sign On to the Provider
			IEssDomain dom = ess.signOn(s_userName, s_password, false, null,
					s_provider);

			// Open connection with olap server and get the cube.
			olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
			olapSvr.connect();
			IEssCube cube = null;
			boolean doesCubeExistNLoadable = false;
			// IMPORTANT: To see the Varying Attributes Related API functionality
			// run this with a Outline that has varying Attributes.
			try {
				cube = olapSvr.getApplication(s_appName).getCube(s_cubeName);
				doesCubeExistNLoadable = cube.isLoadable();
			} catch (EssException x) {
				System.err
						.println(s_appName
								+ "/"
								+ s_cubeName
								+ " doesnt exist to demo Varying Attributes APIs. \nINTENAL ERROR WAS:"
								+ x.getMessage());
			}

			if (doesCubeExistNLoadable) {
				// Open cube outline only to demo identifying outline type...
				IEssCubeOutline otl = cube.openOutline();
				System.out.println("Is Outline Varying Attribute enabled (via IEssCubeOutline): " + otl.isVaryingAttributeEnabled() + "\n");
				otl.close();
				
				// Open member selection
				IEssMemberSelection mbrSel = cube
						.openMemberSelection("Sample member selection");
				
				System.out.println("Is Outline Varying Attribute enabled (via IEssMemberSelection): " + mbrSel.isVaryingAttributeEnabled() + "\n");
				
				if (mbrSel.isVaryingAttributeEnabled()) {
					// If its a Varying Attr type of outline,
					// Query to find the varying attribute dimensions
					boolean doesOtlHaveVaryingAttrs = findVaryingAttributeDimensions(cube, mbrSel);
					if (doesOtlHaveVaryingAttrs) {
						System.out.println("The outline was found to have Varying attributes.");
					}
					else {
						System.out.println("The outline has no Varying attributes.");
					}
					
					// Query Varying Attribute Members
					queryVaryingAttributes(mbrSel);
				}
			}
		} catch (EssException x) {
			System.err.println("Error: " + x.getMessage());
			statusCode = FAILURE_CODE;
		} finally {
			try {
				if (olapSvr != null && olapSvr.isConnected() == true)
					olapSvr.disconnect();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}

			try {
				if (ess != null && ess.isSignedOn() == true)
					ess.signOff();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}
		}
		// Set status to failure only if exception occurs and do abnormal
		// termination
		// otherwise, it will by default terminate normally
		if (statusCode == FAILURE_CODE)
			System.exit(FAILURE_CODE);
	}

	static boolean findVaryingAttributeDimensions(IEssCube cube, IEssMemberSelection mbrSel)
			throws EssException {
		boolean hasVAs = false;
		System.out.println("---- findVaryingAttributeDimensions [BEGIN] ---");
		
		// STEP 1: Get the list of dimensions...
		mbrSel.executeQuery(
				null, // No member specified to query on the entire outline 
				IEssMemberSelection.QUERY_TYPE_CHILDREN, // Get Dimensions of the outline
				IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, // Get the count of members only
				null, null, null);
		
		// STEP2: If any dimensions... scan to identify ATTRIBUTE dimensions 
		if (mbrSel.getCountMembers() > 0) {
			IEssIterator dims = mbrSel.getMembers();
			for (int i=0; i < dims.getCount() ; i++) {
				// if an attr dimension
				IEssMember dim = ((IEssMember)dims.getAt(i));
				if (dim.getDimensionCategory() == IEssDimension.EEssDimensionCategory.ATTRIBUTE){
					
					// STEP3: This is Attribute dimension; so, to find if its a VARYING ATTR DIMENSION, 
					// get the # of indep dimensions. If > 0, then, its Varying.
					mbrSel.executeQuery(
							dim.getName(), 
							IEssMemberSelection.QUERY_TYPE_INDEPDIMS, // Get Independent Dimensions assoc'd
							IEssMemberSelection.QUERY_OPTION_COUNTONLY, // Get the count of members only
							"", "", "");
					int numOfAssocdIndepMbrs = mbrSel.getCountMembers();
					if (numOfAssocdIndepMbrs > 0) {
						hasVAs = true;
						System.out.println(dim.getName() + " is a VARYING ATTRIBUTE");
					}
					else {
						System.out.println(dim.getName() + " is a REGULAR ATTRIBUTE");
					}
				};
			}
		}
		System.out.println("---- findVaryingAttributeDimensions [END] ---\n");
		return hasVAs;
	}

	static void queryVaryingAttributes(IEssMemberSelection mbrSel)
			throws EssException {
		System.out.println("---- queryVaryingAttributes [BEGIN] ---");
		
		// Create a VA query
		IEssVaryingAttributeQuery vaQuery = mbrSel
				.createVaryingAttributeQuery();
		
		// Set input/output member types
		vaQuery.set(IEssVaryingAttributeQuery.MBR_TYPE_BASE_MEMBER,
				IEssVaryingAttributeQuery.MBR_TYPE_ATTRIBUTE_MEMBER);
		// Set input member
		vaQuery.setInputMember("100-10");
		
		// Set the attribute Dimension on which varying query must be based on. 
		vaQuery.setAttributeDimension("Ounces");
		
		// create perspective
		IEssIndepMbrNamesSet persp = (IEssIndepMbrNamesSet) IEssIndepMbrsSet.EEssIndepMbrsSetFactory
				.create(IEssVaryingAttributeQuery.INDEP_MEMBERSET_TYPE_MEMBER_NAME);
	
		// Set perspective tuple with independent dim members associated with the 
		//specified Attribute Dimension ['Ounce' in this case].
		String[] startTuple = { "New York","Jan" };
		String[] endTuple = { "New York", "Dec" };
		
		// create range
		IEssIndepMbrNamesSet.Range range = new IEssIndepMbrNamesSet.Range(
				startTuple, endTuple);
		persp.addRange(range);
		vaQuery.setIndepMbrsPerspective(persp);
		
		// set attribute
		vaQuery.setAttributeValue(IEssVaryingAttributeQuery.OP_ALL, "Ounces");

		IEssMemberWithIndepMbrsSet[] mbrs = mbrSel.queryVaryingAttributes(
				vaQuery,
				IEssVaryingAttributeQuery.INDEP_MEMBERSET_TYPE_MEMBER_NAME);
		if (mbrs != null) {
			for (int i = 0; i < mbrs.length; i++) {
				IEssMemberWithIndepMbrsSet mbr = (IEssMemberWithIndepMbrsSet) mbrs[i];
				displayMemberProperties(mbr);
				if (mbr.getIndepMbrsSet() != null) {
					IEssIndepMbrNamesSet indepMbrNames = (IEssIndepMbrNamesSet) mbr
							.getIndepMbrsSet();
					IEssIndepMbrNamesSet.Range[] ranges = indepMbrNames
							.getRanges();
					if (ranges != null && ranges.length > 0) {
						System.out.println("Independent Member Ranges : ");
						for (int j = 0; j < ranges.length; j++) {
							System.out.println("Range " + j + 1);
							System.out.println("Start Tuple : ");
							if (ranges[j].getStartTuple() != null)
								for (int k = 0; k < ranges[j].getStartTuple().length; k++)
									System.out.print(" "
											+ ranges[j].getStartTuple()[k]);
							System.out.println();
							System.out.println("End Tuple : ");
							if (ranges[j].getEndTuple() != null)
								for (int k = 0; k < ranges[j].getEndTuple().length; k++)
									System.out.print(" "
											+ ranges[j].getEndTuple()[k]);
							System.out.println();
						}
					}
				}
			}
		}
		System.out.println("---- queryVaryingAttributes [END] ---");
	}

	static void displayMemberProperties(IEssMember mbr) throws EssException {
		System.out.println("\nDisplaying member properties...\n");
		System.out.println("Name: " + mbr.getName());
		System.out.println("Description: " + mbr.getDescription());
		System.out.println("Dimension Root Member: "
				+ mbr.isDimensionRootMember());
		System.out.println("Level Number: " + mbr.getLevelNumber());
		System.out.println("Generation Number: " + mbr.getGenerationNumber());
		System.out.println("Unary consolidation type: "
				+ mbr.getConsolidationType());
		System.out.println("Dimension Name: " + mbr.getDimensionName());

		System.out.println("Two pass calculation member: "
				+ mbr.isTwoPassCalculationMember());
		System.out.println("Expense member: " + mbr.isExpenseMember());
		System.out.println("Currency conversion type: "
				+ mbr.getCurrencyConversionType());
		System.out.println("Currency category or name: "
				+ mbr.getCurrencyCategoryOrName());
		System.out
				.println("Time balance option: " + mbr.getTimeBalanceOption());
		System.out.println("Time balance skip option: "
				+ mbr.getTimeBalanceSkipOption());
		System.out.println("Share option: " + mbr.getShareOption());
		System.out.println("Dimension category: " + mbr.getDimensionCategory());
		System.out.println("Dimension storage category: "
				+ mbr.getDimensionStorageCategory());
		System.out.println("Child count: " + mbr.getChildCount());
		System.out.println("Attributes associated: "
				+ mbr.isAttributesAssociated());

		// IEssIterator atts = mbr.getAssociatedAttributes();

		System.out.println("Attribute value: " + mbr.getAttributeValue());
		System.out.println("Member number: " + mbr.getMemberNumber());
		System.out.println("Dimension number: " + mbr.getDimensionNumber());
	}

	static void acceptArgs(String[] args) throws EssException {
		if (args.length >= 4) {
			s_userName = args[0];
			s_password = args[1];
			s_olapSvrName = args[2];
			s_provider = args[3]; // PROVIDER
		} else if (args.length != 0) {
			System.err.println("ERROR: Incorrect Usage of this sample.");
			System.err.println("Usage: java " + QueryVaryingAttributes.class.getName()
					+ " <user> <password> <analytic server> <provider>");
			System.exit(1); // Simply end
		}
	}
}
