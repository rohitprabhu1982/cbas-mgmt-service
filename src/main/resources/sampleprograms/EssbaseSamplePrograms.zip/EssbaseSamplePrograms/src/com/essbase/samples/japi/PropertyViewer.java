/*
    File: PropertyViewer.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
import com.essbase.api.domain.*;

/**
    PropertyViewer example gets an app/cube object, enumerates its properties
    and prints the values.

    In order for this sample to work in your environment, make sure to
    change the s_userName, s_password, s_domainName, s_prefEesSvrName,
    and s_olapSvrName to suit your environment.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class PropertyViewer {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create API instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with OLAP server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // View the properties.
            IEssOlapApplication app = olapSvr.getApplication("Demo");
            System.out.println("\n\nListing Properties for application 'Demo'\n"
                               + "-----------------------------------------");
            viewProperties(app);

            IEssCube cube = app.getCube("Basic");
            System.out.println("\n\nListing Properties for cube 'Demo/Basic'\n"
                               + "-----------------------------------------");
            viewProperties(cube);
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Close OLAP server connection and sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void viewProperties(IEssProperties propObj) throws EssException {
        try {
            for (int propId = 0; propId < propObj.getCountProperties();
                    propId++) {
                System.out.println("Name: " + propObj.getPropertyName(propId));
                IEssProperties.EEssPropertyMode mode =
                    propObj.getPropertyMode(propId);
                System.out.println("Mode: " + mode.stringValue());
                if (mode == IEssProperties.EEssPropertyMode.NO_ACCESS) {
                    ; // You cannot read or write this property.
                } else if (mode == IEssProperties.EEssPropertyMode.WRITE_ONLY) {
                    ;   // You cannot read this property, but can write.
                        // For eg, password for user object is write only.
                } else if (mode == IEssProperties.EEssPropertyMode.READ_ONLY||
                        mode == IEssProperties.EEssPropertyMode.READ_WRITE) {
                    IEssValueAny.EEssDataType dataType =
                        propObj.getPropertyDataType(propId);
                    IEssValueAny val = propObj.getPropertyValueAny(propId);
                    if (dataType == IEssValueAny.EEssDataType.BOOLEAN)
                        System.out.println("Value: " + val.getBoolean());
                    else if (dataType == IEssValueAny.EEssDataType.DOUBLE)
                        System.out.println("Value: " + val.getDouble());
                    else if (dataType == IEssValueAny.EEssDataType.STRING)
                        System.out.println("Value: " + val.getString());
                    else if (dataType == IEssValueAny.EEssDataType.ESS_ENUM)
                        System.out.println("Value: " + val.getEssEnum().
                            stringValue());
                    else if (dataType == IEssValueAny.EEssDataType.INT)
                        System.out.println("Value: " + val.getInt());

                    // NOTE-1: if the mode is READ_WRITE, you can also set the
                    // property value using propObj.setPropertyValueAny(propId, val);
                    // To make the changes persistent invoke propObj.updatePropertyValues(),
                    // after setting all the properties.

                    // NOTE-2: if you want to reload the values to JAPI cache
                    // from the persistent store invoke propObj.refreshPropertyValues();
                }
                System.out.println();
            }
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        }
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + PropertyViewer.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}