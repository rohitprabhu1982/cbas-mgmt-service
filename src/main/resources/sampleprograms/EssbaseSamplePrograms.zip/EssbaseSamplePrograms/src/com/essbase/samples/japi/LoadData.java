/*
    File: LoadData.java	1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import java.io.File;
import java.util.Hashtable;

import com.essbase.api.datasource.IEssCube;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    LoadData Example - loads data to a cube.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class LoadData {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            IEssCube cube = olapSvr.getApplication("Demo").getCube("Basic");
            loadData(cube);
            exportData(cube);
            asyncDataLoad(cube);
            BSOParallelLoad(cube);
            cube.clearActive();
            IEssCube asocube = olapSvr.getApplication("Asosamp").getCube("Sample");
            ASOPartialDataLoad(asocube);
            asocube.clearAllData();
            ASOParallelLoad();
            asyncDataLoadForASO(asocube);

//            incrementalSQLDataloadForASO(asocube);
            incrementalStreamingDataloadForASO(asocube);
            incrementalNonStreamingDataloadForASO(asocube);
            loadDataASO(asocube);
            System.out.println("Data Loading Complete.");
        } catch (EssException x){
            System.out.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Close olap server connection and sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    private static void exportData(IEssCube cube) throws EssException {
        System.out.println("Exporting data BSO");

        // As the path is relative, file will be exported to "ARBORPATH/app/Demo/Basic" on Essbase server.
        cube.exportData("Demo/Basic/exportedData.txt",IEssCube.EEssDataLevel.ALL, true);
        
        
        // As the path is absolute, file will be exported to "C:/temp/exportedData.txt" on Essbase server.
       //cube.exportData("C:/temp/exportedData.txt",IEssCube.EEssDataLevel.ALL, true);
        
        System.out.println("Exporting data Complete.");
        
    }

    private static void ASOParallelLoad() throws EssException {
    	System.out.println("Starting ASO parallel data load ...");
    	IEssbase essbase = IEssbase.Home.create(IEssbase.JAPI_VERSION);
    	essbase.addInstanceForParallelDataload("dataload", IEssOlapFileObject.TYPE_TEXT, "dataload", 
    			false, 0, 0, null, null, 1, 1, 0);
    	// Add below for SQL datasource
//    	essbase.addInstanceForParallelDataload("loadFile", 0, null, 
//    			false, 0, 0, "TBC", "password", 1, 1, 0);

    	// Add below for FTP datasource
//    	essbase.addInstanceForParallelDataload("dataload", IEssOlapFileObject.TYPE_TEXT, 
//    			"ftp://host/test/dataload.txt", false, 0, 0, "usr", "passwd", 1, 1, 0);

    	essbase.setCommonBufferTermOptions(1, 1, 0);
    	
    	String[][] err = essbase.startParallelDataload(s_olapSvrName, s_userName, s_password, false, s_provider, 
    			"ASOSamp", "Sample", 50);
    	String [][] status = essbase.getStatusForDataload();
    	for (int i=0; i < status.length; i++) {
    		System.out.println("Status for Buffer " + status[i][0] + " is " + status[i][1] + " " + status[i][2]);
    	}
    	for (int i=0; err != null && i < err.length; i++) {
    		System.out.println(err[i][0]+ " " +err[i][1] + " " + err[i][2] + " " + err[i][3]);
    	}

    	essbase.clearInstancesForDataload();
    	System.out.println("Completed ASO parallel data load .");
    }
    
    private static void loadData(IEssCube cube) throws EssException {
        System.out.println("Loading data to BSO cube " + cube.getName() + "...");

        // Loading from data/rules file in the server.
        cube.loadData(IEssOlapFileObject.TYPE_RULES, null,
            IEssOlapFileObject.TYPE_TEXT, "Data", false);

        /* NOTE: API commented below demostrates FTP Data Load.
         * For ftp data sources, dataFileName to contain the name of the ftp source
		 * and userName and password to be nonempty
         */ 
        //cube.loadData(IEssOlapFileObject.TYPE_RULES, null, IEssOlapFileObject.TYPE_TEXT, 
        //        "ftp://remotehost/Shgenref", false, "mylogin", "mypassword");

        // Loading data using update specification string from client.
        cube.loadData(true, false, "Product Market Actual Sales Jan 4469\n" +
            "Product Market Actual Sales Feb 42494");
        System.out.println("Data Loading for BSO Complete.");
    }
    
    static void incrementalSQLDataloadForASO(IEssCube cube) throws EssException{
        System.out.println("\nLoading SQl to ASO cube " + cube.getName() + "...");

        int bufferId1 = 400;
        int bufferId2 = 401;

        cube.clearAllData();
        
        cube.loadBufferInit(bufferId1, 0, 0, 2);
        // SQL source
        String[][] err = cube.beginDataload("loadFile", IEssOlapFileObject.TYPE_RULES, 
        							"TBC", "password", false, bufferId1);
        
        // FTP source
        String[][] err1 = cube.beginDataload("dataload", IEssOlapFileObject.TYPE_RULES, "ftp://host/test/dataload.txt", 
        		IEssOlapFileObject.TYPE_TEXT, "usr", "passwd", false, bufferId2);

        long[] idArr = new long[2];
        idArr[0] = bufferId1;
        idArr[1] = bufferId2;
        
        cube.loadBufferTerm(idArr, 1, 1, 0);
    	
        for (int i=0; err != null && i < err.length; i++) {
    		System.out.println(err[i][0]+ " " +err[i][1] + " " + err[i][2]);
    	}
        for (int i=0; err1 != null && i < err1.length; i++) {
    		System.out.println(err1[i][0]+ " " +err1[i][1] + " " + err1[i][2]);
    	}
        System.out.println("SQL Data Loading to ASO Complete.");
        
    }

    static void incrementalNonStreamingDataloadForASO(IEssCube cube) throws EssException{
        System.out.println("\nLoading data file to ASO cube " + cube.getName() + "...");

        int bufferId1 = 200;
//        int bufferId2 = 300;
        cube.clearAllData();
        
        cube.loadBufferInit(bufferId1, 0, 0, 2);
//        cube.loadBufferInit(bufferId2, 0, 0, 2);
        
//        Use the following maxl stmts on maxl shell to create additional buffer ids
//        alter database ASOSamp.Sample initialize load_buffer with buffer_id 123 resource_usage 0.5;
//        alter database ASOSamp.Sample initialize load_buffer with buffer_id 456 resource_usage 0.5;

        EssLOADBUFFER[] buffers = cube.listExistingLoadBuffers();
        for (int i = 0; i < buffers.length; i++) {
        	System.out.print("Exising buffers: " + buffers[i].getBufferId());
        	System.out.print("; Aggr method: " + buffers[i].getDuplicateAggregationMethod());
        	System.out.print("; option flag: " + buffers[i].getOptionFlags());
        	System.out.println("; size: " + buffers[i].getSize());
        }
//        Use the following maxl stmts on maxl shell to destroy the additional buffers
//        alter database ASOSamp.Sample destroy load_buffer with buffer_id 123;
//        alter database ASOSamp.Sample  destroy load_buffer with buffer_id 456;

        String[][] err = cube.beginDataload("dataload", IEssOlapFileObject.TYPE_RULES, "dataload", 
        									IEssOlapFileObject.TYPE_TEXT, false, bufferId1);
//        cube.beginDataload(true, false, false, "dataload", IEssOlapFileObject.TYPE_RULES, IEssOlapFileObject.TYPE_TEXT, "dataload2", bufferId2);
        
        long[] idArr = new long[1];
        idArr[0] = bufferId1;
//        idArr[1] = bufferId2;
        
        cube.loadBufferTerm(idArr, 1, 1, 0);
    	
        for (int i=0; err != null && i < err.length; i++) {
    		System.out.println(err[i][0]+ " " +err[i][1] + " " + err[i][2]);
    	}
        System.out.println("Data file Loading to ASO Complete.");
        
        // merge database API. To be used when there are slices to be merged. 
        // Uncomment to execute the API.
//        cube.mergeDatabaseData(1);
    }

    static void incrementalStreamingDataloadForASO(IEssCube cube) throws EssException{
        System.out.println("\nLoading data to ASO cube " + cube.getName() + "...");

        int bufferId = 100;
        cube.clearAllData();
        
        cube.loadBufferInit(bufferId, 0, 0, 2);
        
//        Use the following maxl stmts on maxl shell to create additional buffer ids
//        alter database ASOSamp.Sample initialize load_buffer with buffer_id 123 resource_usage 0.5;
//        alter database ASOSamp.Sample initialize load_buffer with buffer_id 456 resource_usage 0.5;

        EssLOADBUFFER[] buffers = cube.listExistingLoadBuffers();
        for (int i = 0; i < buffers.length; i++) {
        	System.out.print("Exising buffers: " + buffers[i].getBufferId());
        	System.out.print("; Aggr method: " + buffers[i].getDuplicateAggregationMethod());
        	System.out.print("; option flag: " + buffers[i].getOptionFlags());
        	System.out.println("; size: " + buffers[i].getSize());
        }
//        Use the following maxl stmts on maxl shell to destroy the additional buffers
//        alter database ASOSamp.Sample destroy load_buffer with buffer_id 123;
//        alter database ASOSamp.Sample  destroy load_buffer with buffer_id 456;

        cube.beginDataload(true, false, false, "dataload", IEssOlapFileObject.TYPE_RULES, bufferId);
        
        cube.sendString("Years\tMonths\tTransaction Type\tPayment\tType\tPromotions\tIncome\tAge\tProducts\tStores\tGeography\tOriginal Price\tPrice Paid\tReturns\tUnits\tTransactions\n");
        cube.sendString("Prev Year\tJan\tNo Sale\tATM\tNo Promotion\t 50,000-69,999 \t55 to 64 Years\tBoomboxes\t020723\t10981\t172.50\t172.50\t#Missing\t1\t3\n");

        String[][] err = cube.endDataload();
        
        long[] idArr = new long[1];
        idArr[0] = bufferId;
        
        cube.loadBufferTerm(idArr, 1, 1, 0);
    	
        for (int i=0; err != null && i < err.length; i++) {
    		System.out.println(err[i][0]+ " " +err[i][1] + " " + err[i][2]);
    	}
        System.out.println("Data Loading ASO Complete.");
        
        // merge database API. To be used when there are slices to be merged. 
        // Uncomment to execute the API.
//        cube.mergeDatabaseData(1);
    }

    public static void ASOPartialDataLoad(IEssCube asocube) throws EssException {
		// Load the data in the cube.
    	System.out.println("Loading Data in ASO Cube...");
		asocube.loadData(IEssOlapFileObject.TYPE_RULES, "dataload",
				IEssOlapFileObject.TYPE_TEXT, "dataload", false);
		String regionSpec = "{Jan, Feb, Mar}";
		// Clear Partial Data.
		System.out.println("Clearing Partial Data from ASO Cube...");
		asocube.clearPartialData(regionSpec, false);
	}
    
    public static void asyncDataLoad(IEssCube cube) throws EssException {
    	System.out.println("Performing Async Data Load in BSO cube... ");
    	cube.asyncLoadData(IEssOlapFileObject.TYPE_RULES, null,
    			IEssOlapFileObject.TYPE_TEXT, "Data", false, null, null);
    	System.out.println("Async data load succeeded...");

    	// get Async process state.
    	EssBuildDimDataLoadState state = cube.getAsyncProcessState();

    	// check state until process is complete.
    	while (state.getProcessState() != IEssCube.ESS_BLDDL_STATE_DONE) {
    		// wait for some time.
    		try {
    			Thread.sleep(1000);
    		} catch (InterruptedException x) {
    		}

    		// check again
    		state = cube.getAsyncProcessState();
    	}

    	// close async process.
    	cube.closeAsyncProcess();
    }

    public static void asyncDataLoadForASO(IEssCube cube) throws EssException {
    	System.out.println("\nperforming Async DataLoad on ASO cube "
    			+ cube.getName() + "...");

    	int bufferId = 900;

    	cube.clearAllData();

    	cube.loadBufferInit(bufferId, 0, 0, 2);

    	cube.asyncLoadData(IEssOlapFileObject.TYPE_RULES, "dataload",
    			IEssOlapFileObject.TYPE_TEXT, "dataload", false, null,
    			null, bufferId);

    	// get Async process state.
    	EssBuildDimDataLoadState state = cube.getAsyncProcessState();

    	// check state until process is complete.
    	while (state.getProcessState() != IEssCube.ESS_BLDDL_STATE_DONE) {
    		// wait for some time.
    		try {
    			Thread.sleep(1000);
    		} catch (InterruptedException x) {
    		}

    		// check again
    		state = cube.getAsyncProcessState();
    	}

    	// get the process log
    	StringBuffer errLog = cube.getAsyncProcessLog("asyncbuilddim.err1",
    			false, true);

    	// close async process.
    	cube.closeAsyncProcess();

    	long[] idArr = new long[1];
    	idArr[0] = bufferId;

    	cube.loadBufferTerm(idArr, 1, 1, 0);

    	System.out.println("Async Data Loading to ASO Complete.");
    }
    
    static void loadDataASO(IEssCube cube) throws EssException{
        System.out.println("\nLoading data from client side data file to ASO cube " + cube.getName() + "...");

        int bufferId1 = 500;
//        int bufferId2 = 300;
        cube.clearAllData();
        
        cube.loadBufferInit(bufferId1, 0, 0, 2);
//        cube.loadBufferInit(bufferId2, 0, 0, 2);
        
//        Use the following maxl stmts on maxl shell to create additional buffer ids
//        alter database ASOSamp.Sample initialize load_buffer with buffer_id 123 resource_usage 0.5;
//        alter database ASOSamp.Sample initialize load_buffer with buffer_id 456 resource_usage 0.5;

        EssLOADBUFFER[] buffers = cube.listExistingLoadBuffers();
        for (int i = 0; i < buffers.length; i++) {
        	System.out.print("Exising buffers: " + buffers[i].getBufferId());
        	System.out.print("; Aggr method: " + buffers[i].getDuplicateAggregationMethod());
        	System.out.print("; option flag: " + buffers[i].getOptionFlags());
        	System.out.println("; size: " + buffers[i].getSize());
        }
//        Use the following maxl stmts on maxl shell to destroy the additional buffers
//        alter database ASOSamp.Sample destroy load_buffer with buffer_id 123;
//        alter database ASOSamp.Sample  destroy load_buffer with buffer_id 456;
        
        //copy dataload.txt file from server to temp directory in client.
        String tmpDir = System.getProperty("java.io.tmpdir");
        if (!tmpDir.endsWith(File.separator))
        	tmpDir = tmpDir + File.separator;
        String clientFileName = tmpDir + "dataload.txt";
        cube.copyOlapFileObjectFromServer(IEssOlapFileObject.TYPE_TEXT, "dataload", clientFileName, false);
        
        // use the dataload.txt copied from server to load data from client side data file.
        String[][] err = cube.beginDataload("dataload", IEssOlapFileObject.TYPE_RULES, clientFileName, 
        									IEssOlapFileObject.TYPE_TEXT, false, bufferId1);

        
        long[] idArr = new long[1];
        idArr[0] = bufferId1;
        
        cube.loadBufferTerm(idArr, 1, 1, 0);
    	
        for (int i=0; err != null && i < err.length; i++) {
    		System.out.println(err[i][0]+ " " +err[i][1] + " " + err[i][2]);
    	}
        System.out.println("Client side Data file Loading to ASO Complete.");
        
   }
    
    private static void BSOParallelLoad(IEssCube cube) throws EssException {
    	IEssCubeDataloadInstance instance = cube.createDataloadInstance();
    	// Use wild card to specify multiple data files
    	instance.setDataFile("Data*");
    	instance.setAbortOnError(false);
    	instance.setDataFileType(IEssOlapFileObject.TYPE_TEXT);
    	short numPipes = 2;
    	instance.setNumPipes(numPipes);
    	String[][] loadErrors = cube.loadDataParallel(instance);
    	// If data file specified are on client machine, below API will return specific data file failure errors. 
//    	Hashtable<String, String> threadErrors = cube.getDataLoadThreadErrors();
    	
    }
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + LoadData.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
