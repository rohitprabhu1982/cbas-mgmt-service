/*
    File: CreateConnPoolAndCluster.java 1.0, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    This example creates cluster.
    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Balaji S
    @version 1.0, 18 Jul 06
 */
public class CreateCluster {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default      

    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign on to the domain.
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // List already existing clusters.
            listClusters(dom);

            // Delete if objects already exist.
            System.out.println("Deleting cluster (demoBasicCluster) if exists...");
            try {
                dom.deleteCluster("demoBasicCluster");
            } catch (EssException x) { System.out.println(x.getMessage()); }

            // Create a new cluster definition.
            System.out.println("Creating cluster (demoBasicCluster)...");
            IEssCluster cluster = dom.createCluster("demoBasicCluster");
            cluster.setDescription("Cluster of Demo/Basic cubes");
            cluster.setServiceComponentNames(
                s_olapSvrName+"/Demo/Basic; "+s_olapSvrName+"/DemoCp/Basic");
            cluster.updatePropertyValues();
            // Note: After creation of a Cluster, it will be in UNAVAILABLE state.
            // In order to do enabling (or disabling) of the cluster components 
            // like below statements are possible only after restarting your 
            // APS Server (or Embedded JAPI JVM instance)
//            cluster.enableComponent(s_olapSvrName+"/Demo/Basic");
//            cluster.enableComponent(s_olapSvrName+"/DemoCp/Basic");

            System.out.println("Completed.");
        } catch (EssException x) {
            System.out.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void listClusters(IEssDomain dom) throws EssException {
        try {
            IEssIterator objs = dom.getClusters();            
            System.out.println("Listing Clusters...\n-----------------");
            for (int i = 0; i < objs.getCount(); i++) {
                IEssExtendedObject obj = (IEssExtendedObject)objs.getAt(i);
                System.out.println("Name: " + obj.getName());
            }
            System.out.println();
        } catch (EssException x) {
            System.out.println("Cannot list Clusters. " + x.getMessage());
        }
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CreateCluster.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
