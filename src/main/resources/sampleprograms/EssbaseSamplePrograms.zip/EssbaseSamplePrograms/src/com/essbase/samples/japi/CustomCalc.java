/*
    File: CustomCalc.java
    Copyright (c) 1991, 2008 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import java.util.ArrayList;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.EssPerformAllocationError;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.datasource.IEssPerformCustomCalc;
import com.essbase.api.session.IEssbase;

/**
 * Essbase Java API sample program for demonstrating how to 
 * perform Custom Calculation on a Essbase Aggregate Storage(ASO) Cube.
 * 
 * <p>Key APIs used :
 * 	- IEssCube.getPerformCustomCalcInstance()
 *  - IEssPerformCustomCalc.* APIs such as for instance the IEssPerformCustomCalc.performCustomCalc(...)
 * </p>
 * 
 * @author Balaji S
 * @since 11.1.2
 */
public class CustomCalc {

	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "system";

	private static String s_password = "password";

	private static String s_olapSvrName = "localhost";

	/*
	 * Possible values for s_provider: "Embedded" or
	 * "http://localhost:13080/aps/JAPI"
	 */
	private static String s_provider = "Embedded"; // Default

	private static final int FAILURE_CODE = 1;

	public static void main(String[] args) {
		int statusCode = 0;
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;
		try {
			acceptArgs(args);

			// Create JAPI instance.
			ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

			// Login to essbase and get the Essbase Server object.
			olapSvr = ess.signOn(s_userName, s_password, false, null,
										s_provider, s_olapSvrName);

			System.out.println("Essbase Server Version : " + olapSvr.getOlapServerVersion());
			IEssCube cube = olapSvr.getApplication("ASOSamp").getCube("Sample");
			performCustomCalculation(cube);

		} 
		catch (EssException x) {
			System.out.println("Error: " + x.getMessage());
			statusCode = FAILURE_CODE;
		} 
		finally {
			
			// Close OLAP server connection and sign off from the domain.
			try {
				if (olapSvr != null && olapSvr.isConnected() == true)
					olapSvr.disconnect();
			} catch (EssException x) {
				System.out.println("Error: " + x.getMessage());
			}

			try {
				if (ess != null && ess.isSignedOn() == true)
					ess.signOff(); // Logout
			} catch (EssException x) {
				System.out.println("Error: " + x.getMessage());
			}
		}
		// Set status to failure only if exception occurs and do abnormal
		// termination
		// otherwise, it will by default terminate normally
		if (statusCode == FAILURE_CODE)
			System.exit(FAILURE_CODE);
	}

	public static void performCustomCalculation(IEssCube cube) throws EssException {
		// Get the IEssPerformCustomCalc instance
		IEssPerformCustomCalc custCalc = cube.getPerformCustomCalcInstance();
		
		// Set all the parameters using the individual set methods.
		custCalc.setPOV("{([curr year],jan,sale,Cash,[No Promotion],[20 to 25 Years],[50,000-69,999],[Digital Cameras],[004118],[80101])}");
		custCalc.setTarget("([Curr Year],Jan)");
		custCalc.setDebitMember("[Sale]");
		custCalc.setCreditMember("[No Sale]");
		custCalc.setOffset("([Curr Year], Jan, Returns)");
		custCalc.setSourceRegion("crossjoin({Units,transactions},{([prev year],dec)})");
		custCalc.setGroupID(0);
		custCalc.setRuleID(0);

		//Case1: Error
		System.out.println("-- Case1: 'Error only' scenario ---------");
		customCalcUseCase1(custCalc);
		custCalc.setOffset("([Curr Year], Jan)"); // modify offset to produce error.
		runCustCalc(custCalc);
		System.out.println("-- Case1: End of 'Error only' scenario --\n");
		
		custCalc.setOffset("([Curr Year], Jan, Returns)"); // reset back to valid offset to test rest of scenarios. 
		//Case2: Error & Warning 
		System.out.println("-- Case2: 'Error & Warning' scenario ---------");
		customCalcUseCase2(custCalc);
		runCustCalc(custCalc);
		System.out.println("-- Case2: End of 'Error & Warning' scenario --\n");
		
		//Case3: Warning only
		System.out.println("-- Case3: 'Warning only' scenario ---------");
		customCalcUseCase3(custCalc);
		runCustCalc(custCalc);
		System.out.println("-- Case3: End of 'Warning only' scenario --\n");
		
		//Case4: Success 
		System.out.println("-- Case4: 'Success(No error/warning messages)' scenario ---------");
		customCalcUseCase4(custCalc);
		runCustCalc(custCalc);
		System.out.println("-- Case4: End of 'Success(No error/warning messages)' scenario --\n");
	}
	
	private static void runCustCalc(IEssPerformCustomCalc custCalc) {
		
		// This is the error and/or warning messages list. This list needs to be created by the
		// client using this IEss.performCustomCalc(...) API to pass the list object so that API 
		// can append the list of messages (if any) to this object.
		// If you don't send the error list object (i.e., if this appendErrorsAndWarningsIfAny is null)
		// then, the API will not append any error messages found as part of the execution.
		ArrayList errAndWarnMsgsList = new ArrayList();
		
		boolean verifyMode = true;
		boolean isSuccessful = false;
		try {
			isSuccessful = custCalc.performCustomCalc(verifyMode, errAndWarnMsgsList);
			if (!isSuccessful && !errAndWarnMsgsList.isEmpty()) {
				System.out.println("WARNING(S) - There were some warnings found with this calculation.");
				System.out.println("List of error/warning messages: ");
				for (int i = 0; i < errAndWarnMsgsList.size(); i++) {
					System.out.println(perfAllocErrorToString(
										(EssPerformAllocationError)errAndWarnMsgsList.get(i)) );
				}
			}
			else {
				System.out.println("Calculation successful" + (verifyMode ? "(in Verify Mode)." : ".") );
			}
		}
		catch (EssException e) {
			if(e.getNativeCode() == 1300052) // This is expected error for 'customCalcUseCase1'. Handling it for acceptance test purpose.
				System.out.println("Expected error occured in Custom Calculation. Error: " + e.getMessage());
			else
				System.err.println("ERROR occured in Custom Calculation. Error: " + e.getMessage());
				
			if (!errAndWarnMsgsList.isEmpty()) {
				System.out.println("List of error/warning messages: ");
				for (int i = 0; i < errAndWarnMsgsList.size(); i++) {
					System.out.println(perfAllocErrorToString((EssPerformAllocationError)errAndWarnMsgsList.get(i)) );
				}
			}
		}
	}

	private static void customCalcUseCase1(IEssPerformCustomCalc custCalc) {
		//error case - Case 1
		custCalc.setScript("([80101],Returns) := ([prev year],dec,transactions) + ([prev year],dec,units); \n ([80101],Returns) := ([prev year],dec,transactions) + ([prev year],dec,units);");
	}

	private static void customCalcUseCase2(IEssPerformCustomCalc custCalc) {
		//warning & error - Case 2
		custCalc.setScript("([80101],Returns) := ([prev year],dec,transactions) + ([prev year],dec,units); \n (units):=([80101],Returns);\n([80101],Returns) := ([prev year],dec,transactions) + ([prev year],dec,units);");
	}

	private static void customCalcUseCase3(IEssPerformCustomCalc custCalc) {
		//warning only - Case 3
		custCalc.setScript("([80101],Returns) := ([prev year],dec,transactions) + ([prev year],dec,units); \n (units):=([80101],Returns);");
	}
	
	private static void customCalcUseCase4(IEssPerformCustomCalc custCalc) {
		// Correct case - Case 4
		custCalc.setScript("([80101],Returns) := ([prev year],dec,transactions) + ([prev year],dec,units);");
	}
	
	private static String perfAllocErrorToString(EssPerformAllocationError aError) {
		return "(Message #"+aError.getMessageNumber()+")Error at Line "
				+ aError.getLineNumber() + " with argument " + aError.getArgument() + ", token=" + aError.getToken();
	}
	
	static void acceptArgs(String[] args) throws EssException {
		if (args.length >= 4) {
			s_userName = args[0];
			s_password = args[1];
			s_olapSvrName = args[2];
			s_provider = args[3]; // PROVIDER
		} else if (args.length != 0) {
			System.err.println("ERROR: Incorrect Usage of this sample.");
			System.err.println("Usage: java "
					+ CustomCalc.class.getName()
					+ " <user> <password> <analytic server> <provider>");
			System.exit(1); // Simply end
		}
	}
}
