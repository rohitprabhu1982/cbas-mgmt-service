/*
    File: Allocation.java
    Copyright (c) 1991, 2008 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import java.util.ArrayList;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.EssCube;
import com.essbase.api.datasource.EssGL_END_ALLOC;
import com.essbase.api.datasource.EssPerformAllocationError;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.datasource.IEssPerformAllocation;
import com.essbase.api.session.IEssbase;

/**
 * Essbase Java API sample program for demonstrating how to 
 * perform Allocation on a Essbase Aggregate Storage(ASO) Cube.
 * 
 * <p>Key APIs used :
 * 	- IEssCube.getPerformAllocationInstance()
 *  - IEssPerformAllocation.* APIs such as for instance,  
 *  	the IEssPerformAllocation.performAllocation(...) API.
 * </p>
 * <p><b>NOTE</b>&nbsp; This sample by default doesn't use any of the sample 
 *       		cube that Essbase is bundled with. So, before you 
 *				try it, modify the sample to suit your setup and
 *				also modify the Allocation arguments.   
 * </p>
 * 
 * @author Balaji S
 * @since 11.1.2
 */
public class Allocation {

	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "system";
	private static String s_password = "password";
	private static String s_olapSvrName = "localhost";
	private static String s_appName = "GL2010";
	private static String s_cubeName = "db";
	
	/*
	 * Possible values for s_provider: "Embedded" or
	 * "http://localhost:13080/aps/JAPI"
	 */
	private static String s_provider = "Embedded"; // Default

	private static final int FAILURE_CODE = 1;

	public static void main(String[] args) {
		int statusCode = 0;
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;
		try {
			acceptArgs(args);

			// Create JAPI instance.
			ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

			// Login to Essbase... 
			olapSvr = ess.signOn(s_userName, s_password, false, null,
									s_provider, s_olapSvrName);

			System.out.println("Essabse Server Version : " + olapSvr.getOlapServerVersion());
			
            // IMPORTANT: To try the Allocations API functionality, 
            // modify this sample with to suit your setup and your ASO Cube.
			IEssCube cube = null;

			/* Below check is performed to make sure the cube specified
			 * exists in your Essbase server before trying the allocations 
			 * operation as this sample doesnt use the any of standard Essbase 
			 * sample cubes. */ 
            boolean doesCubeExistNLoadable = false;
            try {
            	cube = olapSvr.getApplication(s_appName).getCube(s_cubeName);
            	doesCubeExistNLoadable = cube.isLoadable();
            }
            catch (EssException x) {
            	System.err.println(s_appName+"/"+s_cubeName+" doesnt exist to perform Allocation. " 
            			+ "\nINTENAL ERROR:" + x.getMessage());
            }
            
            // Cube exists and load-able, now, run the allocation on it.
            if (doesCubeExistNLoadable) {
//            	performAllocation(cube);
            	testGLAllocation(cube);
            }
		} 
		catch (EssException x) {
			System.out.println("Error: " + x.getMessage());
			statusCode = FAILURE_CODE;
		} 
		finally {
			// Close OLAP server connection and sign off from the domain.
			try {
				if (olapSvr != null && olapSvr.isConnected() == true)
					olapSvr.disconnect();
			} 
			catch (EssException x) {
				System.out.println("Error: " + x.getMessage());
			}

			try {
				if (ess != null && ess.isSignedOn() == true)
					ess.signOff();
			}
			catch (EssException x) {
				System.out.println("Error: " + x.getMessage());
			}
		}
		// Set status to failure only if exception occurs and do abnormal
		// termination; otherwise, it will by default terminate normally
		if (statusCode == FAILURE_CODE)
			System.exit(FAILURE_CODE);
	}

	public static void performAllocation(IEssCube cube) throws EssException {
		// Get the IEssPerformAllocation instance
		IEssPerformAllocation performAlloc = cube.getPerformAllocationInstance();

		// Set all the parameters using the individual set methods.
		performAlloc.setPOV("{[Acc19802]}");
		performAlloc.setAmount("([ANLT], [OUTT], [PUBT], [FRED], [Feb-08], [Allocations], [Beginning Balance], [ORG63], [CC10000])");
		performAlloc.setTarget("([ANLT], [OUTT], [PUBT], [FRED], [Feb-08], [Allocations])");
		performAlloc.setDebitMember("[Beginning Balance Debit]");
		performAlloc.setCreditMember("[Beginning Balance Credit]");
		performAlloc.setRange("CrossJoin(Descendants([ORGT], [Organisation].Levels(0)), Descendants([CCT], [Cost Centre].Levels(0)))");
		performAlloc.setBasis("([ANLT], [OUTT], [PUBT], [FRED], [Feb-05/06], [Beginning Balance], [Actual])");
		performAlloc.setOffset("([ANLT], [OUTT], [PUBT], [FRED], [Feb-08], [Allocations], [ORG63], [CC10000])");
		performAlloc.setAmountContext("");
		performAlloc.setAmountTimeSpan("");
		performAlloc.setTargetTimeSpan("");
		performAlloc.setTargetTimeSpanOption(0 /*IEssPerformAllocation.ESS_ASO_ALLOCATION_TIMESPAN_DIVIDEAMT*/);
		performAlloc.setExcludedRange("");
		performAlloc.setBasisTimeSpan("");
		performAlloc.setBasisTimeSpanOption(0/* IEssPerformAllocation.ESS_ASO_ALLOCATION_TIMESPAN_COMBINE_BASIS*/);
		performAlloc.setAllocationMethod(IEssPerformAllocation.ESS_ASO_ALLOCATION_METHOD_SHARE);
		performAlloc.setSpreadSkipOption(0);
		performAlloc.setZeroAmountOption(IEssPerformAllocation.ESS_ASO_ALLOCATION_ZEROAMT_NEXTAMT);
		performAlloc.setZeroBasisOption(IEssPerformAllocation.ESS_ASO_ALLOCATION_ZEROBASIS_NEXTAMT);
		performAlloc.setNegativeBasisOption(IEssPerformAllocation.ESS_ASO_ALLOCATION_NEGBASIS_NEXTAMT);
		performAlloc.setRoundMethod(IEssPerformAllocation.ESS_ASO_ALLOCATION_ROUND_NONE);
		performAlloc.setRoundDigits("");
		performAlloc.setRoundToLocation("");
		performAlloc.setGroupID(0);
		
		runAllocation(performAlloc);
	}

	private static void runAllocation(IEssPerformAllocation performAlloc) {
		
		// This is the error and/or warning messages list. This list needs to be created by the
		// client using this IEss.performCustomCalc(...) API to pass the list object so that API 
		// can append the list of messages (if any) to this object.
		// If you don't send the error list object (i.e., if this appendErrorsAndWarningsIfAny is null)
		// then, the API will not append any error messages found as part of the execution.
		ArrayList errAndWarnMsgsList = new ArrayList();
		
		boolean verifyMode = true;
		boolean isSuccessful = false;
		try {
			isSuccessful = performAlloc.performAllocation(verifyMode, errAndWarnMsgsList);
			if (!isSuccessful && !errAndWarnMsgsList.isEmpty()) {
				System.out.println("WARNING(S) - There were some warnings found with this calculation.");
				System.out.println("List of error/warning messages: ");
				for (int i = 0; i < errAndWarnMsgsList.size(); i++) {
					System.out.println(perfAllocErrorToString(
										(EssPerformAllocationError)errAndWarnMsgsList.get(i)) );
				}
			}
			else {
				System.out.println("Allocation successful" + (verifyMode ? "(in Verify Mode)." : ".") );
			}
		}
		catch (EssException e) {
			System.err.println("ERROR occured in Allocation. Error: " + e.getMessage());
			if (!errAndWarnMsgsList.isEmpty()) {
				System.out.println("List of error/warning messages: ");
				for (int i = 0; i < errAndWarnMsgsList.size(); i++) {
					System.out.println(perfAllocErrorToString((EssPerformAllocationError)errAndWarnMsgsList.get(i)) );
				}
			}
		}
	}

	private static String perfAllocErrorToString(EssPerformAllocationError aError) {
		return "Error at Line "
				+ aError.getLineNumber() + " with argument " + aError.getArgument() + ", token '" + aError.getToken() + "'";
	}

	private static void beginAllocation(EssCube cube) throws EssException{
		cube.beginGLAllocation("Alloc by User 1", 100, 123456, "fusion;fusion");
	}

	private static void endAllocation(EssCube cube) throws EssException{
		EssGL_END_ALLOC endAllocInfo = new EssGL_END_ALLOC(123456, 456, 1001, (short)0, "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <definitions> <CURRENCY_TYPE> <CURRENCY_NAME>Corporate</CURRENCY_NAME> </CURRENCY_TYPE> <RULESET_INFO> <RULESET_NAME> Ruleset Name </RULESET_NAME> <RULESET_DESC> Ruleset Description </RULESET_DESC> </RULESET_INFO> <RULES_INFO> <RULE_ID> 1 </RULE_ID> <RULE_NAME> Alloc Rule 1 </RULE_NAME> <RULE_DESC>Description for alloc rule 1 </RULE_DESC> <RULE_ID> 2 </RULE_ID> <RULE_NAME> Alloc Rule 2 </RULE_NAME> <RULE_DESC>Description for alloc rule 12 </RULE_DESC> </RULES_INFO> </definitions>");
		cube.endGLAllocationEx(endAllocInfo);
	}

	private static void testGLAllocation(IEssCube cube) throws EssException{
		// Begin the allocation process
		beginAllocation((EssCube)cube);
		// Get the IEssPerformAllocation instance
		IEssPerformAllocation performAlloc = cube.getPerformAllocationInstance();

		// Set all the parameters using the individual set methods.
		performAlloc.setPOV("Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin(Crossjoin({[All Account Values].[11010]},{[Total]}),{[All Division Values].[1111]}),{USD}),DESCENDANTS([2007], [AccountingPeriod].Levels(0))),{[Base]}),DESCENDANTS([All Cost_Center Values].[110], [Cost_Center].Levels(0))),DESCENDANTS([All Company Values], [Company].Levels(0))),{[Vision Foods - USA Ledger]}),{[All Program Values].[1111]}), {[All Location Values].[1111]}), {[All Intercompany Values].[1111]})");
		performAlloc.setAmount("10000");
		performAlloc.setTarget("([Allocated])");
		performAlloc.setDebitMember("[Period Activity Dr]");
		performAlloc.setCreditMember("[Period Activity Cr]");
		performAlloc.setRange("DESCENDANTS([All Product Values], [Product].Levels(0))");
		performAlloc.setBasis("([Beginning Balance Cr], [All Account Values].[11010], [Actual])");
		performAlloc.setOffset("");
		performAlloc.setAmountContext("");
		performAlloc.setAmountTimeSpan("");
		performAlloc.setTargetTimeSpan("");
		performAlloc.setTargetTimeSpanOption(0 /*IEssPerformAllocation.ESS_ASO_ALLOCATION_TIMESPAN_DIVIDEAMT*/);
		performAlloc.setExcludedRange("");
		performAlloc.setBasisTimeSpan("");
		performAlloc.setBasisTimeSpanOption(0/* IEssPerformAllocation.ESS_ASO_ALLOCATION_TIMESPAN_COMBINE_BASIS*/);
		performAlloc.setAllocationMethod(IEssPerformAllocation.ESS_ASO_ALLOCATION_METHOD_SHARE);
		performAlloc.setSpreadSkipOption(0);
		performAlloc.setZeroAmountOption(IEssPerformAllocation.ESS_ASO_ALLOCATION_ZEROAMT_NEXTAMT);
		performAlloc.setZeroBasisOption(IEssPerformAllocation.ESS_ASO_ALLOCATION_ZEROBASIS_NEXTAMT);
		performAlloc.setNegativeBasisOption(IEssPerformAllocation.ESS_ASO_ALLOCATION_NEGBASIS_NEXTAMT);
		performAlloc.setRoundMethod(IEssPerformAllocation.ESS_ASO_ALLOCATION_ROUND_NONE);
		performAlloc.setRoundDigits("");
		performAlloc.setRoundToLocation("");
		performAlloc.setGroupID(123456);
		performAlloc.setRuleID(1);

		runAllocation(performAlloc);

		// End the allocation process.
		endAllocation((EssCube)cube);
	}

	static void acceptArgs(String[] args) throws EssException {
		if (args.length >= 4) {
			s_userName = args[0];
			s_password = args[1];
			s_olapSvrName = args[2];
			s_provider = args[3]; // PROVIDER
		} else if (args.length != 0) {
			System.err.println("ERROR: Incorrect Usage of this sample.");
			System.err.println("Usage: java "
					+ Allocation.class.getName()
					+ " <user> <password> <analytic server> <provider>");
			System.exit(1); // Simply end
		}
	}
}
