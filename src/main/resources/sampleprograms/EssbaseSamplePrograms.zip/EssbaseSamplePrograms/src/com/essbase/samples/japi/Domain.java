/*
    File: Domain.java	1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.domain.*;

/**
    Domain Example does the following: Signs on to essbase domain, creates
    domain objects such as olap servers and enumerates what is created.
    One object in each category is deleted for this example.

    In order for this sample to work in your environment, make sure to
    change the s_* to suit your environment.

    @author Srini Ranga
    @version 1.1, 18 Jul 06
 */
public class Domain {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default

    private static String[] s_olapServersToCreate = {"olapSvr-1", "olapSvr-2"};
    private static String[] s_olapServersToDelete = {"olapSvr-2"};

    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Create, List, Delete olap servers in the root domain.            
            createOlapServers(dom, s_olapServersToCreate);
            listOlapServers(dom);
            deleteOlapServers(dom, s_olapServersToDelete);
            
        } catch (EssException x){
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Sign Off from the Provider & Analytic Services.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void createOlapServers(IEssDomain dom, String[] objNames)  throws EssException {
        System.out.println("Creating Olap Servers...\n-----------------");
        for (int i = 0; i < objNames.length; i++) {
            try {
                dom.createOlapServer(objNames[i]);
                System.out.println("Created Olap Server " 
                                    + objNames[i]);
            } catch (EssException x) {
                System.out.println("Cannot create " + objNames[i]
                                                               + ". " + x.getMessage());
            }
        }
        System.out.println();
    }

    static void listOlapServers(IEssDomain dom) throws EssException {
        try {
            IEssIterator objs = dom.getOlapServers();
            System.out.println("Listing Olap Servers...\n-----------------");
            for (int i = 0; i < objs.getCount(); i++) {
                IEssExtendedObject obj = (IEssExtendedObject)objs.getAt(i);
                System.out.println("Name: " + obj.getName());
            }
            System.out.println();
        } catch (EssException x) {
            System.out.println("Cannot list Olap Servers. " + x.getMessage());
        }
    }

    static void deleteOlapServers(IEssDomain dom, String[] objNames)  throws EssException {
        System.out.println("Deleting Olap Servers...\n-----------------");
        for (int i = 0; i < objNames.length; i++) {
            try {
                dom.deleteOlapServer(objNames[i]);
                System.out.println("Deleted Olap Server " + objNames[i]);
            } catch (EssException x) {
                System.out.println("Cannot delete " + objNames[i] +
                    ". " + x.getMessage());
            }
        }
        System.out.println();
    }

    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + Domain.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
