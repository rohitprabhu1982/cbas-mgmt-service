package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.EssCube;
import com.essbase.api.datasource.EssOlapApplication;

/**
 * Overriding implementation of EssCube/IEssCube that allows us to intercept
 * certain calls to an IEssCube.
 * 
 * @author jasonwjones
 *
 */
public class EssCube2 extends EssCube {

	private boolean useAlternateName = false;

	private String fakeName;

	public EssCube2(String arg0, int arg1, EssOlapApplication arg2) throws EssException {
		super(arg0, arg1, arg2);
	}

	@Override
	public void calcFileWithRunTimeSubVarFile(boolean arg0, String arg1, String arg2) throws EssException {
		super.calcFileWithRunTimeSubVarFile(arg0, arg1, arg2);
	}

	@Override
	public String getName() throws EssException {
		System.out.println("Asking for name");
		if (useAlternateName) {
			return fakeName;
		} else {
			return super.getName();
		}
	}

	public void setAlternateName(String fakeName) {
		this.useAlternateName = true;
		this.fakeName = fakeName;
	}

	@Override
	public void setActive() throws EssException {
		System.out.println("Setting active");
		super.setActive();
		setAlternateName("");
	}

}
