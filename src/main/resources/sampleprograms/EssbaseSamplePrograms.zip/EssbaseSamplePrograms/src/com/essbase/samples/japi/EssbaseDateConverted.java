package com.essbase.samples.japi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EssbaseDateConverted {

	public static void main(String[] args) throws ParseException {
		Double value = 2.0191223E7;
		//long myLong = System.currentTimeMillis() + ((long) (value * 1000000000));
		long myLong = (long)(value * 10000000)/10000000;
		System.out.println(myLong);
		String dateValue = Long.toString(myLong);
		Date date1=new SimpleDateFormat("yyyyMMdd").parse(dateValue);
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(date1);
		System.out.println(date); 
		
		System.out.println(date1);
		

	}

}
