/*
    File: EditOutline.java   1.0, 2006-5-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
*/
package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapFileObject;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.metadata.EssGenOrLevel;
import com.essbase.api.metadata.IEssCubeOutline;
import com.essbase.api.metadata.IEssDimension;
import com.essbase.api.metadata.IEssMember;
import com.essbase.api.metadata.IEssMemberSelection;
import com.essbase.api.metadata.IEssSmartList;
import com.essbase.api.metadata.IEssDimension.EEssAttributeDataType;
import com.essbase.api.metadata.IEssMember.EEssHierarchyType;
import com.essbase.api.session.IEssbase;

/**
    EditOutline Example does the following: 
    Signs on to Analytic Service, connects to a App/DB and perform 
    almost all Edit operations on the Cube's Outline.

    In order for this sample to work in your environment, make sure to
    change the s_* to suit your environment.
    
    @author Satish Ramanavarpu
    @version 1.0, 18 May 06
*/
public class EditOutline extends Thread {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private boolean doSleep = false;
    
    private static final int FAILURE_CODE = 1;
    
    public EditOutline(boolean sleep) {
    	this.doSleep = sleep;
    }
    
    public static void main1(String [] args) {
    	try {
    		concurrencyTest();
    	}
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        IEssOlapApplication app = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // use this cube for generating the currency outline.
//          String appName = "Sample", cubeName = "Interntl";
          
            String appName = "Sample", cubeName = "Basic";
            app = olapSvr.getApplication(appName);

            IEssCube cube = app.getCube(cubeName);
            
            //Use can use this TestCase with a Currency oultine like Sample/Interntl
            //testGenerateCurrencyOutline(cube);
            testUserAttributes(cube);
            testGeneration(cube);
            testLevel(cube);
            testCreateChildMember(cube);
            testSetOutlineAttrAPI(cube);
            testAliasTableAPI(cube);
            testCreateDimension(cube, false);
            testDeleteDimension(cube);
//            testDataload(cube);
            testUpdateData(cube);
            testDTSMemberAPI(cube);
            testSetMemberAPI(cube);
            testMemberAPI(cube);
            testSetNonUniqueAPI(cube);
            testNonUniqueAPI(cube);
            testMemberSelection(cube);
            testOutlineQuery(cube);
            //testCreateOutline(olapSvr);
           // testSmartListAPI(olapSvr);
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            x.printStackTrace();
            statusCode = FAILURE_CODE;
        } finally {
        	comeOutClean(ess, olapSvr);
            //System.exit(0);
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void testCreateOutline(IEssOlapServer olapSvr) throws EssException {
    	String appName = "Sample";
    	String cubeName = "BasicB";
    	IEssOlapApplication app = olapSvr.getApplication(appName);
    	IEssCube cube = null;
        try {
            app.deleteCube(cubeName);
            System.out.println("Cube is deleted...");
        } catch (Throwable x) {
            try {
                cube = app.getCube(cubeName);
                cube.unlockOlapFileObject(IEssOlapFileObject.TYPE_OUTLINE, cubeName);
                cube.delete();
                System.out.println("Cube is deleted...");
            } catch (Throwable x2) {}
        }    	
    	IEssCube newCube = app.createCube(cubeName, IEssCube.EEssCubeType.NORMAL);
    	IEssCubeOutline newOutline = newCube.openOutline(false, true, true);
        
    	newOutline.createDimension("Year");
        newOutline.save();
        newOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
        try {
            IEssDimension yrDim = newCube.getDimension("Year");
            System.out.println("Dim name is:" + yrDim.getName());
        }
        catch (Exception e){
        	e.printStackTrace();
        }
        log("Unlocking "+newCube.getName());
    	newCube.unlockOlapFileObject(1, newCube.getName());
    	newOutline.close();
    	log("testCreateOutline() --");
    	
    }
    
    static void testOutlineQuery(IEssCube cube) throws EssException {
    	log("testOutlineQuery() --", false);
   	
        IEssMemberSelection memSel = cube.openMemberSelection("member selection");
        // to get all dimensions
        memSel.executeQuery(null, IEssMemberSelection.QUERY_TYPE_CHILDREN, 
        		IEssMemberSelection.QUERY_OPTION_FORCEIGNORECASE, null, null , null);
        
        boolean isNonUnique = memSel.isNonUniqueMemberNameEnabled();
        log("Outline is :"+isNonUnique);

        IEssIterator dims = memSel.getMembers();

        for (int j=0; dims != null &&  j < dims.getCount(); j++) {
        	IEssMember dim = (IEssMember)dims.getAt(j);
        	log("## Dim: --" + dim.getName(), false);
        	// again execute query to get all member of each dimension.
        	memSel.executeQuery(null, IEssMemberSelection.QUERY_TYPE_WILDSEARCH, 
        			IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, 
        			dim.getName(), "*" , null);
        	IEssIterator mbrs = memSel.getMembers();
	        for (int i = 0; mbrs != null && i < mbrs.getCount(); i++) {
	            IEssMember mbr = (IEssMember)mbrs.getAt(i);
	            log("Name: " + mbr.getName());
	            log("Level: " + mbr.getLevelNumber());
	            log("Generation: " + mbr.getGenerationNumber());
	            log("Alias: " + mbr.getAlias("Default"));
	            log("Consolidation: " + mbr.getConsolidationType());
	            log("Formula: " + mbr.getFormula());
	            log("Dimension name: " + mbr.getDimensionName());
	            log("Child count: " + mbr.getChildCount());
	
	            log("Parent name: " + mbr.getParentMemberName());
	            log("Member number: " + mbr.getMemberNumber());
	            log("Dimension number: " + mbr.getDimensionNumber());
	            log("");
	        }
        }
        memSel.close();
        log("END testOutlineQuery() --", false);
    }

    static void testMemberSelection(IEssCube cube) throws EssException {
    	log("testMemberSelection() --", false);

        IEssMemberSelection memSel = cube.openMemberSelection("member selection");
        String fldSelection = "<OutputType Binary  <SelectMbrInfo (MemberName, MemberAliasName) ";
        String mbrSelection = "@Relative(\"" + "Caffeinated_False" + "\",\"" + "Lev0,Caffeinated" + "\")";
        System.out.println("Performing member selection: "+ mbrSelection);
        memSel.executeQuery(fldSelection, mbrSelection);

        IEssIterator mbrs = memSel.getMembers();
        for (int i = 0; i < mbrs.getCount(); i++) {
            IEssMember mbr = (IEssMember)mbrs.getAt(i);
            System.out.println("Name: " + mbr.getName());
            System.out.println("Level: " + mbr.getLevelNumber());
            System.out.println("Generation: " + mbr.getGenerationNumber());
            System.out.println("Alias: " + mbr.getAlias("Default"));
            System.out.println("Consolidation: " + mbr.getConsolidationType());
            System.out.println("Formula: " + mbr.getFormula());
            System.out.println("Dimension name: " + mbr.getDimensionName());
            System.out.println("Child count: " + mbr.getChildCount());

            System.out.println("Parent name: " + mbr.getParentMemberName());
            System.out.println("Member number: " + mbr.getMemberNumber());
            System.out.println("Dimension number: " + mbr.getDimensionNumber());
        }

        memSel.close();
        log("END testMemberSelection() --", false);
    }

    static void testSetNonUniqueAPI(IEssCube cube) throws EssException {
        log("testSetNonUniqueAPI() --", false);
        IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
        if (!cubeOutline.isNonUniqueMemberNameEnabled()) {
            log("The outline does not support non unique member names.");
            return;
        }
        IEssMember marginMemb = cubeOutline.findMember("Margin");
        marginMemb.setMemberId("UniqueMargin1");
        
        cubeOutline.save();
        cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
        cubeOutline.close();
        log("END testSetNonUniqueAPI() --", false);
    }
  
      static void testNonUniqueAPI(IEssCube cube) throws EssException {
        log("testNonUniqueAPI() --", false);
        IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
        if (!cubeOutline.isNonUniqueMemberNameEnabled()) {
            log("The outline does not support non unique member names.");
            return;
        }
        IEssMember marginMemb = cubeOutline.findMemberOnId("UniqueMargin1");
        log("Member ID for Margin :" + marginMemb.getMemberId());
        log("Member with id UniqueMargin1 is: "+ marginMemb.getName());
        marginMemb.deleteMemberId();

        IEssMember prodMemb = cubeOutline.findMember("Product");
    	IEssIterator prodChilds = prodMemb.getChildMembers(true);
    	for (int i = 0; i < prodChilds.getCount(); i++) {
    		IEssMember member = (IEssMember)prodChilds.getAt(i);
    		log("Unique name of Member "+i+" of Product: "+ member.getUniqueName());
    	}
		
        cubeOutline.save();
        cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
        cubeOutline.close();
        log("END testNonUniqueAPI() --", false);
    }    
    
    static void testSetMemberAPI(IEssCube cube) throws EssException{
    	log("testSetMemberAPI() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline();
    	try {
    		String aliasTableName = "MyAliasTbl";
    		String newAliasTableName = "MyNewAliasTbl";
    		
    		cubeOutline.createAliasTable(aliasTableName);
    		IEssMember janMemb = cubeOutline.findMember("Jan");
    		IEssMember marMemb = cubeOutline.findMember("Mar");
    		log("Moving Jan to post Mar");
    		cubeOutline.moveMember(janMemb, null, marMemb);
    		log("Renaming Jan");
    		janMemb.rename("January Prelim");

    		IEssMember yearMemb = cubeOutline.findMember("Year");
    		log("Setting alias for Year in MyAliasTbl to Time Dimension");
    		yearMemb.setAlias(aliasTableName, "Time Dimension");
    		yearMemb.sortChildren(false);
    		cubeOutline.renameAliasTable(aliasTableName, newAliasTableName);
    		
    		IEssMember prodMemb = cubeOutline.findMember("Product");
    		IEssMember newDiet = prodMemb.createChildMember("NewDiet");
    		newDiet.setHierarchyType(EEssHierarchyType.NOT_HIERARCHY_MEMBER);
    		
//    		IEssMember prod100Member = cubeOutline.findMember("[100].[100-20]");
//    		log("Setting originalMemberName for [100].[100-20] to [Diet].[100-20]");
    		// should be set only once; cannot be unset once re-structured
//    		prod100Member.setOriginalMemberName("[Diet].[100-20]");
    		
    		IEssMember variance = cubeOutline.findMember("Variance");
    		log("Setting formula for Variance");
    		variance.setFormula("@VAR(Budget, Actual);");

    		IEssMember apr = cubeOutline.findMember("Apr");
    		log("Setting formula for Apr");
    		apr.setFormula("@VAR(Budget, Actual);");

    		IEssDimension yearDim = cubeOutline.findDimension("Year");
    		// for this to be effective, first make the outline non-unique thro EAS console
    		log("Setting DimensionNameUniqness for Year to false");
    		yearDim.setDimensionNameUniqueness(false);
    		yearDim.setDescription("Description for Year");
    		yearDim.updatePropertyValues();

    		IEssDimension introDim = cubeOutline.findDimension("Intro Date");
    		IEssDimension countryDim = cubeOutline.createAttributeDimension("Country", EEssAttributeDataType.TEXT, introDim);
   		
    		IEssDimension prodDim = cubeOutline.findDimension("Product");
    		cubeOutline.associateAttributeDimension(prodDim, countryDim);
    		
    		IEssMember prod100Memb = cubeOutline.findMember("100");
    		IEssMember countryMemb = cubeOutline.findMember("Country");
    		IEssMember indiaMemb = countryMemb.createChildAttributeMember("India", EEssAttributeDataType.TEXT, null);
    		cubeOutline.associateAttributeMember(prod100Memb, indiaMemb);

    		cubeOutline.verify(true);
    		cubeOutline.save();
    		cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
    	}
    	catch (EssException e) {
    		System.out.println(e.getMessage());
    		throw e;
    	}
    	finally {
    		cubeOutline.close();
    	}
    	log("END testSetMemberAPI() --", false);
    }

    static void testMemberAPI(IEssCube cube) throws EssException{
    	log("testMemberAPI() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline();
    	try {
    		
    		String aliasTableName = "MyNewAliasTbl";
    		
    		IEssMember qtrMemb = cubeOutline.findMember("Qtr1");
    		IEssIterator qtrChildren = qtrMemb.getChildMembers();
    		log("Members of Qtr1 (after moving Jan to post Mar)");
    		for (int i = 0; i < qtrChildren.getCount(); i++) {
    			IEssMember member = (IEssMember)qtrChildren.getAt(i);
				log("Member "+i+" of Qtr1: "+ member.getName());
			}
    		
    		IEssMember yearMemb = cubeOutline.findMember("Year");
    		IEssIterator yearChilds = yearMemb.getChildMembers();
    		log("Sorted children of Year: ");
    		for (int i = 0; i < yearChilds.getCount(); i++) {
    			IEssMember member = (IEssMember)yearChilds.getAt(i);
				log("Member "+i+" of Year: "+ member.getName());
    		}
    		log("Member alias for Year:"+ yearMemb.getAlias(aliasTableName));
    		log("Member with Time Dimension as alias is: "
    				+ cubeOutline.findAlias("Time Dimension", aliasTableName).getName());
    		
    		IEssMember newDiet = cubeOutline.findMember("NewDiet");
    		log("Current Hierarchy type for NewDiet:"+newDiet.getHierarchyType());
    		
//    		Will work if original member name was uncommented and set in the above API call
//    		IEssMember dietMember = cubeOutline.findMember("[Diet].[100-20]");
//    		log("Original Member name for [Diet].[100-20]:" + dietMember.getOriginalMemberName());
    		
    		yearMemb.deleteAlias(aliasTableName);
    		cubeOutline.deleteAliasTable(aliasTableName);

    		IEssIterator attrMems = cubeOutline.findAttributeMembers("Bottle", "");
    		for (int i = 0; i < attrMems.getCount(); i++) {
    			IEssMember member = (IEssMember)attrMems.getAt(i);
				log("Members with attribute Bottle "+i+ ": "+ member.getDimensionName());
			}
    		
    		IEssMember variance = cubeOutline.findMember("Variance");
    		log("MemberLastFormula for Variance: "+variance.getLastFormula());
    		log("Is Member Variance unique: "+variance.isNameUnique());

    		IEssDimension yearDim = cubeOutline.findDimension("Year");
    		log("Year Dimension Name uniqueness is:"+yearDim.getDimensionNameUniqueness());
    		log("Description for year is: " + yearDim.getDescription());

    		IEssMember member = cubeOutline.findMember("Measures");
    		member.sortChildren(false);
    		
    		IEssMember aprMemb = cubeOutline.findMember("Apr");
    		log("Formula for Apr: "+aprMemb.getFormula());
    		aprMemb.deleteFormula();
    		
    		IEssMember prodMemb = cubeOutline.findMember("Product");
    		IEssIterator assomembers = prodMemb.getAssociatedAttributes();
    		for (int i = 0; i < assomembers.getCount(); i++) {
    			IEssMember assomember = (IEssMember)assomembers.getAt(i);
				log("Associated Members for Member Product "+i+ ": "+ assomember.getName());
			}   		
    	    		
    		//reset
    		IEssMember prod100Memb = cubeOutline.findMember("100");
    		IEssMember indiaMemb = cubeOutline.findMember("India");
    		cubeOutline.disassociateAttributeMember(prod100Memb, indiaMemb);
    		indiaMemb.delete();
    		
    		IEssDimension prodDim = cubeOutline.findDimension("Product");
    		IEssDimension countryDim = cubeOutline.findDimension("Country");
    		cubeOutline.disassociateAttributeDimension(prodDim, countryDim);
    		log("Does Product dim has hybrid children: "+cubeOutline.dimensionHasHybridChildren());
    		countryDim.delete("Country");

    		IEssMember janMemb = cubeOutline.findMember("January Prelim");
    		janMemb.rename("Jan");
    		IEssMember qtr1Memb = cubeOutline.findMember("Qtr1");
    		cubeOutline.moveMember(janMemb, qtr1Memb, null);
    		yearDim.setDimensionNameUniqueness(true);
    		newDiet.delete();
    		
    		cubeOutline.verify();
    		cubeOutline.save();
    		cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
    	}
    	catch (EssException e) {
    		System.out.println(e.getMessage());
    		throw e;
    	}
    	finally {
    		cubeOutline.close();
    	}
    	log("END testMemberAPI() --", false);
    }

//    static void testTemplate(IEssCube cube) throws EssException {
//    	log("testTemplate() --");
//    	IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
//    	log("Current DefaultAttrCalcDimName :" + cubeOutline.getDefaultAttrCalcDimName());
//    	cubeOutline.setDefaultAttrCalcDimName("My Attribute Names");
//    	log("DefaultAttrCalcDimName after change:" + cubeOutline.getDefaultAttrCalcDimName());
//    	cubeOutline.save();
//    	cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
//    	cubeOutline.close();
//    	log("END testTemplate() --");
//    }
    
	  static void testGenerateCurrencyOutline(IEssCube cube) throws EssException {
		log("testGenerateCurrencyOutline() --");
		IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
		
		log("Generating Currency outline :"+cubeOutline.getName());
		IEssCubeOutline currOutline = cubeOutline.generateCurrencyOutline();
		log("Completed Currency outline");
		currOutline.save();
		currOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
		currOutline.close();
		cubeOutline.close();
		log("END testGenerateCurrencyOutline() --");
	}
	  
    static void testUserAttributes(IEssCube cube) throws EssException {
		log("testUserAttribute() --", false);
		IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
		IEssMember janMember = cubeOutline.findMember("Jan");

		String [] userAttrs = janMember.getUDAs();
		for (int i = 0; i < userAttrs.length; i++) {
			log("User Attr "+i+ ": "+ userAttrs[i]);
		}
		janMember.createUDA("Read");
//		janMember.deleteUDA("Read");
		
		cubeOutline.save();
		cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
		cubeOutline.close();
		log("END testUserAttribute() --", false);
	}

    static void testGeneration(IEssCube cube) throws EssException {
		log("testGeneration() --", false);
		
		// Generation API
		IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
		IEssDimension yearDim = cubeOutline.findDimension("Year");
		IEssIterator yearGens = yearDim.getGenerations();

		for (int i = 0; i < yearGens.getCount(); i++) {
			EssGenOrLevel child = (EssGenOrLevel)yearGens.getAt(i);
			log("Gen "+i+ ": "+ child.getName());
		}
		
		log("Current GetGenName :" + yearDim.getGenerationName(2));
		log("Current GetGenNameEx :" + yearDim.getGeneration(2));
		yearDim.clearGenerationName(2);
		yearDim.setGenerationName(2, "Quarter");
		
		cubeOutline.save();
		cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
		
		cubeOutline.close();
		log("END testGeneration() --", false);
	}
	  
	  static void testLevel(IEssCube cube) throws EssException {
			log("testLevel() --", false);
			// level API
			IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
			IEssDimension yearDim = cubeOutline.findDimension("Year");
			IEssIterator yearLevels = yearDim.getLevels();
			
			yearDim.setLevelName(0, "JAPItestLevel", true);
			yearDim.updatePropertyValues();
			
			for (int i = 0; i < yearLevels.getCount(); i++) {
				EssGenOrLevel child = (EssGenOrLevel)yearLevels.getAt(i);
				log("Level "+i+ ": "+ child.getName());
			}

			log("Current GetLevelNameEx: " + yearDim.getLevel(0));
			log("Current GetLevelName :" + yearDim.getLevelName(0));
			yearDim.clearLevelName(0);
			yearDim.updatePropertyValues();
			
			cubeOutline.save();
			cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
			cubeOutline.close();
			log("END testLevel() --", false);
		}

	  static void testCreateChildMember(IEssCube cube) throws EssException {
		log("testCreateChildMember() --", false);
		IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
		IEssMember member = cubeOutline.findMember("Market");
		IEssIterator iterator = member.getChildMembers();
		
		for (int i = 0; i < iterator.getCount(); i++) {
			IEssMember child = (IEssMember)iterator.getAt(i);
			log("Child "+i+ ": "+ child.getName());
		}
		IEssMember newChild = member.createChildMember("Asia");
		log("Created new child:"+newChild.getName());
		//reset
		newChild.delete();
		log("Deleted new child:"+newChild.getName());
		cubeOutline.save();
		cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
		cubeOutline.close();
		log("END testCreateChildMember() --", false);
	}
    
    static void testSetOutlineAttrAPI(IEssCube cube) throws EssException {
    	log("testSetOutlineAttrAPI() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
    	log("Current AutoConfigure status :" + cubeOutline.isAutoConfigure());
    	cubeOutline.setAutoConfigure(true);
    	cubeOutline.updatePropertyValues();
    	log("AutoConfigure status after change:" + cubeOutline.isAutoConfigure());

    	log("Current DefaultAttrCalcDimName :" + cubeOutline.getDefaultAttrCalcDimName());
    	cubeOutline.setDefaultAttrCalcDimName("My Attribute Names");
    	cubeOutline.updatePropertyValues();
    	log("DefaultAttrCalcDimName after change:" + cubeOutline.getDefaultAttrCalcDimName());
    	
    	log("Current DefaultCountMbrName :" + cubeOutline.getDefaultCountMbrName());
    	cubeOutline.setDefaultCountMbrName("MyCount");
    	cubeOutline.updatePropertyValues();
    	log("DefaultCountMbrName after change:" + cubeOutline.getDefaultCountMbrName());

    	log("Current DefaultMaxMbrName :" + cubeOutline.getDefaultMaxMbrName());
    	cubeOutline.setDefaultMaxMbrName("MyMax");
    	cubeOutline.updatePropertyValues();
    	log("DefaultMaxMbrName after change:" + cubeOutline.getDefaultMaxMbrName());

    	log("Current DefaultSumMbrName :" + cubeOutline.getDefaultSumMbrName());
    	cubeOutline.setDefaultSumMbrName("MySum");
    	cubeOutline.updatePropertyValues();
    	log("DefaultSumMbrName after change:" + cubeOutline.getDefaultSumMbrName());

    	log("Current Delimiter :" + cubeOutline.getDelimiter());
    	cubeOutline.setDelimiter(1);
    	cubeOutline.updatePropertyValues();
    	log("Delimiter after change:" + cubeOutline.getDelimiter());

    	log("Current UseNameOf :" + cubeOutline.getUseNameOf());
    	cubeOutline.setUseNameOf(0);
    	cubeOutline.updatePropertyValues();
    	log("UseNameOf after change:" + cubeOutline.getUseNameOf());

    	//resetting
    	cubeOutline.setAutoConfigure(false);
    	cubeOutline.setDefaultAttrCalcDimName("Attribute Calculations");
    	cubeOutline.setDefaultCountMbrName("Count");
    	cubeOutline.setDefaultMaxMbrName("Max");
    	cubeOutline.setDefaultSumMbrName("Sum");
    	cubeOutline.setDelimiter(0);
    	cubeOutline.setUseNameOf(1);
    	cubeOutline.updatePropertyValues();

    	cubeOutline.save();
    	cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
    	cubeOutline.close();
    	log("END testSetOutlineAttrAPI() --", false);
    }
    
    
    static void testAliasTableAPI(IEssCube cube) throws EssException {
    	log("testAliasTableAPI() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
    	cubeOutline.createAliasTable("MyAliasTbl");
    	cubeOutline.copyAliasTable("MyAliasTbl", "MyAliasTbl2", false);
    	String [] aliasTableNames = cubeOutline.getAliasTableNames();
    	for (int i=0; i < aliasTableNames.length; i++) {
    		log("\t"+aliasTableNames[i]);
    	}
    	cubeOutline.clearAliasTable("MyAliasTbl");
    	cubeOutline.deleteAliasTable("MyAliasTbl");
    	cubeOutline.deleteAliasTable("MyAliasTbl2");
    	
    	cubeOutline.save();
    	cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
    	cubeOutline.close();
    	log("END testAliasTableAPI() --", false);
    }
    
    static void testCreateDimension(IEssCube cube, boolean sleep) throws EssException {
    	log("testCreateDimension() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);

    	if (sleep) {
			log("Sleeping");
			sleep(5000);
		}
		
		IEssDimension dim = cubeOutline.findDimension("Year");
    	log("find dim "+dim.toString());
    	IEssDimension newDim = cubeOutline.createDimension("Semister", dim);
    	log("new dim "+newDim.toString());
    	IEssDimension monDim = cubeOutline.createDimension("Monthly", newDim);
    	log("new dim "+monDim.toString());

//    	cubeOutline.verify();
    	cubeOutline.save();
    	cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
    	log("Unlocking "+cube.getName());
    	cube.unlockOlapFileObject(1, cube.getName());
    	cubeOutline.close();
    	log("END testCreateDimension() --", false);
    }
   
    static void testDeleteDimension(IEssCube cube) throws EssException {
    	log("testDeleteDimension() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline(false, true, true);
    	
    	IEssDimension findDim = cubeOutline.findDimension("Semister");
    	log("find dim :"+findDim.toString());
    	findDim.delete("Semister");
    	
    	IEssMember monthMembDim = cubeOutline.findMember("Monthly");
    	log("new dim "+monthMembDim.toString());
    	monthMembDim.delete(IEssMember.ESS_VERIFY_DEFER); 

    	cubeOutline.verify();
    	cubeOutline.save();
    	cubeOutline.restructureCube(IEssCube.EEssRestructureOption.KEEP_ALL_DATA);
    	log("Unlocking "+cube.getName());
    	cube.unlockOlapFileObject(1, cube.getName());
    	cubeOutline.close();
    	log("END testDeleteDimension() --", false);
    }
    static void testDataload(IEssCube cube) throws EssException {
    	log("testDataload() --", false);
    	cube.beginDataload(true, false, false, 
    						null, IEssOlapFileObject.TYPE_RULES );
    	cube.sendString("Diet Jan Sales Actual Market 1001\n");
    	cube.sendString("Diet Feb Sales Actual Market 2002\n");
    	cube.sendString("Diet Mar Sales Actual California 3003\n");
    	String [][] err = cube.endDataload();
    	for (int i=0; err != null && i < err.length; i++) {
    		System.out.println(err[i][0]+ " " +err[i][1] + " " + err[i][2]);
    	}
    	log("END testDataload() --", false);
    }
    
    static void testUpdateData(IEssCube cube) throws EssException{
    	log("testUpdateData() --", false);
    	cube.beginUpdate(true, false);
    	cube.sendString("Diet Jan Sales Actual Market 1111\n");
    	cube.sendString("Diet Feb Sales Actual Market 2222\n");
    	cube.sendString("Diet Apr Sales Actual Market 3333\n");
    	cube.sendString("Diet May Sales Actual Market 4444\n");
    	cube.sendString("Diet Jun Sales Actual Market 5555\n");
    	cube.endUpdate();
    	log("END testUpdateData() --", false);
    }
    
    static void testDTSMemberAPI(IEssCube cube) throws EssException{
    	log("testDTSMemberAPI() --", false);
    	IEssCubeOutline cubeOutline = cube.openOutline(false, true, false);
    	try {
	    	String dtsAlias = cubeOutline.getDTSMemberAlias("D-T-D", "default");
	    	log("DTS Alias is:D-T-D:"+dtsAlias);
	    	dtsAlias = cubeOutline.getDTSMemberAlias("H-T-D", "default");
	    	log("DTS Alias is:H-T-D:"+dtsAlias);
	    	
	    	log("Setting Alias....");
	    	cubeOutline.setDTSMemberAlias("D-T-D", "default", "dtd");
	    	cubeOutline.setDTSMemberAlias("H-T-D", "default", "htd");
	
	    	dtsAlias = cubeOutline.getDTSMemberAlias("D-T-D", "default");
	    	log("2. DTS Alias is:D-T-D:"+dtsAlias);
	    	dtsAlias = cubeOutline.getDTSMemberAlias("H-T-D", "default");
	    	log("2. DTS Alias is:H-T-D:"+dtsAlias);
	
	    	cubeOutline.enableDTSMember("H-T-D", 1, true);
	    	cubeOutline.enableDTSMember("Q-T-D", 2, true);
	    	
	    	String member = cubeOutline.getEnabledDTSMember(0);
	    	log("Enabled DTS member 0:"+member);
	    	member = cubeOutline.getEnabledDTSMember(1);
	    	log("Enabled DTS member 1:"+member);
	
	    	cubeOutline.deleteDTSMemberAlias("D-T-D", "default");
	    	cubeOutline.deleteDTSMemberAlias("H-T-D", "default");
	    	
	    	cubeOutline.verify();
    	}
    	catch (EssException e) {
    		System.out.println(e.getMessage());
    		throw e;
    	}
    	finally {
    		cubeOutline.close();
    	}
    	log("END testDTSMemberAPI() --", false);
    }
    
    static void testSmartListAPI(IEssOlapServer olapSvr) throws EssException{
    	log("testSmartListAPI() --", false);
    	
    	// to test SmartList APIs the Outline must be member type enabled.
    	IEssCube cube = olapSvr.getApplication("Testapp1").getCube("Testapp1");
    	
        IEssCubeOutline otl = cube.openOutline(false, true, false, false);
    	try {
             IEssSmartList SL1 = otl.createSmartList("m11");
             IEssSmartList SL2 = otl.createSmartList("m122");
             long[] IDs = {1,2,3};
             String[] text = {"One","Two","Three"};
             SL1.putSmartList(IDs,text);
             IEssSmartList[] SLlist = otl.getAllSmartLists();
             
             IEssMember mbr = otl.findMember("m122");
             IEssMember mbr1 = otl.findMember("m13");
             mbr.setSmartList(SLlist[0]);
             IEssSmartList Sl = mbr.getSmartList();
             
             SLlist[0].exportSmartList("C:/m13new.slt");
             SLlist[1].importSmartList("C:/m13.slt");
             SLlist[0].delete();
    	}
    	catch (EssException e) {
    		System.out.println(e.getMessage());
    		throw e;
    	}
    	finally {
    		otl.close();
    	}
    	log("END testSmartListAPI() --", false);
    }

    public static void comeOutClean(IEssbase ess, IEssOlapServer olapSvr) {
        try {
            if (olapSvr != null && olapSvr.isConnected() == true)
                olapSvr.disconnect();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }

        try {
            if (ess != null && ess.isSignedOn() == true)
                ess.signOff();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }
    }

    public static void sleep(int sec) {
    	try {
    		Thread.sleep(sec);
    	} catch (InterruptedException ie) { ie.printStackTrace();}
    }
    
    public static void log (String str){
    	log(str, true);
    }
    
    public static void log(String str, boolean tab) {
//    	System.out.println(Thread.currentThread() + "::" + str);
    	if (tab) System.out.println("*::*\t" + str);
    	else System.out.println("*::*" + str);
    }
    
    /**
     * Will require another user "admin" to test concurrency test.
     */
    public void run() {
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        IEssOlapApplication app = null;
    	try {
    		
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);
            IEssDomain dom = null;
    		if (!doSleep) {
   	    		sleep(4000);
   	    		dom = ess.signOn(s_userName, s_password, false, null, "embedded");
    		}
    		else {
    			dom = ess.signOn("admin", s_password, false, null, "embedded");
    		}
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            String appName = "Sample", cubeName = "Basic";
            app = olapSvr.getApplication(appName);

            IEssCube cube = app.getCube(cubeName);
            
            testCreateDimension(cube, doSleep);
    	}
    	catch (Exception e) {
    		System.out.println("Thread info:: "+currentThread());
    		e.printStackTrace();
    		comeOutClean(ess, olapSvr);
    	}
    }
    
    public static void concurrencyTest() throws EssException{
    	EditOutline t1 = new EditOutline(true);
    	t1.start();
    	EditOutline t2 = new EditOutline(false);
    	t2.start();
    }
        
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + EditOutline.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }

}
