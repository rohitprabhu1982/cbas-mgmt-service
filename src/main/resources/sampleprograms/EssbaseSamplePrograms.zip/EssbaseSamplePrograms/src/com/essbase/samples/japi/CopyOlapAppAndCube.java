/*
    File: CopyOlapAppAndCube.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapGroup;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.datasource.IEssOlapUser;
import com.essbase.api.datasource.IEssCube.EEssCubeAccess;
import com.essbase.api.datasource.IEssCube.IEssSecurityFilter;
import com.essbase.api.datasource.IEssCube.IEssSecurityFilter.IEssFilterRow;
import com.essbase.api.datasource.IEssOlapApplication.EEssOlapApplicationAccess;
import com.essbase.api.domain.*;

/**
    CopyOlapAppAndCube copies olap application/cube from one server to another.

    In order for this sample to work in your environment, make sure to
    change the s_userName, s_password, s_domainName, s_prefEesSvrName to suit
    your environment. 

    @author Srini Ranga
    @version 1.1, 18 Jul 06
 */
public class CopyOlapAppAndCube {

    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default  

    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);
            
            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign on to the domain.
            IEssDomain dom = ess.signOn(s_userName, s_password, 
                    false, null, s_provider);

            // Step1: Showcasing how to copy an Application
            String app = "Demo", replicaApp = "DemoCp";
            olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);            
            olapSvr.connect();
            
            try {
                // Delete the App if it already exists
                IEssOlapApplication olapApp1 = olapSvr.getApplication("Sample1");
                olapApp1.delete();
            }
            catch (EssException essE) {
                //System.out.println(essE.getMessage());
            }

            copyApplicationWithPrivileges(olapSvr);

            try {
                // Delete the App if it already exists
                IEssOlapApplication olapApp = olapSvr.getApplication(replicaApp);
                olapApp.delete();
            }
            catch (EssException essE) {
                //System.out.println(essE.getMessage());
            }
            dom.copyOlapApplication(s_olapSvrName, app, s_olapSvrName, replicaApp);
            olapSvr.disconnect();
            System.out.println("Successfully created an Application "+replicaApp+" from "+app);
            
            // Step2: Showcasing how to copy an Database (i.e., Cube)
            // Copy Analytic application within same server 
            // (this API doesnt support across Analytic servers)
            String srcApp = "Sample", srcDb = "Basic", replicaDb = "BasicCp";
            olapSvr.connect();
            try {
                // Delete the App if it already exists
                IEssOlapApplication olapApp = olapSvr.getApplication(srcApp);
                olapApp.deleteCube(replicaDb);
            }
            catch (EssException essE) {
                //System.out.println(essE.getMessage());
            }
            dom.copyCube(s_olapSvrName, srcApp, srcDb, s_olapSvrName, srcApp, replicaDb);
            System.out.println("Successfully created an Cube, "+srcApp +"."+replicaDb+" from "+srcApp +"."+srcDb);
            olapSvr.disconnect();
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }            
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }
    
	/**
	 * Migrating user/group privileges from one Application/Cube to another app/Cube.<br>
	 * <br>
	 * There are 3 levels of user/group privileges:<br>
	 * <br>
	 * A] Server Level Privileges: <br>
	 *    a) Administrator user/group (has full access on all the apps and cubes)<br>
	 * <br>
	 * B] Application Level Privileges:<br>
	 *    a) Application Designer/Manager (highest available privilege on the application)<br>
	 *    b) Load Unload Application (Can load/unload the application)<br>
	 * <br>
	 * C] Cube Level Privileges:<br>
	 *    a) Database Manager (highest available privilege on the Cube)<br>
	 *    b) Calc             (Can run calculation scripts on the cube)<br>
	 *    c) Write            (Can modify cube data/metadata)<br>
	 *    d) Read             (Can only read the cube data/metadata)<br>
	 *    e) Filter           (Only has access to part of the cube defined by the associated filter)<br>
	 * <br>
	 * Note: The higher privileges include all the lower privileges with
	 * exception of Load Unload Application. Even though the load-unload
	 * Application is a application level privilege, it is actually the lowest
	 * available privilege on an Application, so all the cube level privileges
	 * include the load-unload application privilege.<br>
	 * <br>
	 * Based on the above information, the user/group privileges migration can be
	 * performed using following steps :<br>
	 * <br>
	 * 1. If the user/group had administrator or super-user level privileges, no need to 
	 * migrate the application or cube level privileges as the user/group implicitly 
	 * has complete access to manage all the apps and cubes. Therefore, skip the privilege
	 * migration of this user/group and move on to the next user/group.<br>
	 * <br>
	 * 2. If user/group has the application designer(manager) privilege on source
	 * application, set application manager privilege for that user/group on the
	 * target application. As Application manager includes all the cube level privileges,
	 * no need to migrate the cube level privileges separately, so move to the next user/group.<br>
	 * <br>
	 * 3. If user/group has the load-unload application privilege on source
	 * application, check for the cube level privileges on the source cube, if
	 * user/group has a particular cube level privilege on the source cube, only then 
	 * migrate that privilege on the target cube. As the cube level privilege includes the
	 * application load-unload privilege, no need to migrate the app level
	 * privilege separately. If user/group does not have any cube level privilege
	 * on the source cube, just migrate the application level privilege (which
	 * will be load/unload application) on the target application and move on to
	 * the next user/group.<br>
	 * <br>
	 * 4. Repeat above 3 steps for all the users/groups associated to the source application.
	 * 
	 * Note : Setting application level privileges overwrites the cube level privileges.
	 */
    public static void copyApplicationWithPrivileges(IEssOlapServer olapSvr) throws EssException {
    	String origApp = "Sample", repApp = "Sample1";
    	IEssOlapApplication app = olapSvr.getApplication(origApp);
    	IEssOlapApplication app1 = app.copy(repApp);
    	IEssIterator cubes = app.getCubes();
    	for (int i = 0; i < cubes.getCount(); i++) {
    		IEssCube cube = (IEssCube)cubes.getAt(i);
    		//    		IEssIterator users = olapSvr.getOlapUsers("Sample", cube.getName(), "native", false);
    		IEssIterator users = olapSvr.getOlapUsers(origApp, null, "native", false);
    		IEssIterator groups = olapSvr.getOlapGroups(origApp, cube.getName());
    		for (int j=0; j < users.getCount(); j++) {
    			IEssOlapUser user = (IEssOlapUser)users.getAt(j);
    			// if user is admin/super user, no need to transfer the app level privilege.
    			if(user.getAccess() == EssGlobalStrings.ESS_ACCESS_SUPER) 
    				continue;
    			EEssOlapApplicationAccess appAccess = app.getUserOrGroupAccess(user.getName());
    			EEssCubeAccess cubeAccess = null; 

    			// If appAccess is load/unload application, check for cube level access. 
    			if(appAccess == EEssOlapApplicationAccess.LOAD_APPLICATION){
    				try{	
    					cubeAccess = cube.getUserOrGroupAccess(user.getName());
    				} catch (EssException ex){
    					// If user does not have any cube level privilege, the API will throw an exception 'Unknown cube access'
    					// Consume it and continue
    					cubeAccess = null;
    				}
    			}
    			IEssCube cube1 = app1.getCube(cube.getName());

    			// If there is no cube level access, migrate the application level access only..
    			if(cubeAccess == null)
    				app1.setUserOrGroupAccess(user.getName(),appAccess);
    			else // If there is cube level access, migrate the cube level access only..
    				cube1.setUserOrGroupAccess(user.getName(),cubeAccess); 

    			if (cubeAccess == EEssCubeAccess.FILTER_ACCESS) {
    				IEssIterator filters = cube.getSecurityFilters();
    				for (int k=0; k < filters.getCount(); k++ ) {
    					IEssSecurityFilter filter = (IEssSecurityFilter)filters.getAt(k);
    					IEssSecurityFilter filter1 = cube1.setSecurityFilter(filter.getName(), true, cubeAccess);
    					IEssFilterRow filterRow = null;
    					while ((filterRow = filter.getFilterRow()) != null) {
    						filter1.setFilterRow(filterRow.getRowString(), filterRow.getAccess());
    					}
    					// The last filterRow got from Server is null itself, so no need to add an extra null Row.
    					//filter1.setFilterRow("",null);
    				}
    			}
    		}
    		for (int j=0; j < groups.getCount(); j++) {
    			IEssOlapGroup group = (IEssOlapGroup)groups.getAt(j);

    			if(group.getAccess() == EssGlobalStrings.ESS_ACCESS_SUPER) // if supper or admin
    				continue;
    			EEssOlapApplicationAccess appAccess = app.getUserOrGroupAccess(group.getName());
    			EEssCubeAccess cubeAccess = null;

    			// If appAccess is load/unload application, check for cube level access. 
    			if(appAccess == EEssOlapApplicationAccess.LOAD_APPLICATION){
    				try{	
    					cubeAccess = cube.getUserOrGroupAccess(group.getName());
    				} catch (EssException ex){
    					// If group does not have any cube level privilege, the API will throw an exception 'Unknown cube access'
    					// Consume it and continue
    					cubeAccess = null;
    				}
    			}

    			IEssCube cube1 = app1.getCube(cube.getName());

    			// If there is no cube level access, migrate the application level access only..
    			if(cubeAccess == null)
    				app1.setUserOrGroupAccess(group.getName(),appAccess);
    			else // If there is cube level access, migrate the cube level access only..
    				cube1.setUserOrGroupAccess(group.getName(),cubeAccess); 

    			if (cubeAccess == EEssCubeAccess.FILTER_ACCESS) {
    				IEssIterator filters = cube.getSecurityFilters();
    				for (int k=0; k < filters.getCount(); k++ ) {
    					IEssSecurityFilter filter = (IEssSecurityFilter)filters.getAt(k);
    					IEssSecurityFilter filter1 = cube1.setSecurityFilter(filter.getName(), true, cubeAccess);
    					IEssFilterRow filterRow = null;
    					while ((filterRow = filter.getFilterRow()) != null) {
    						filter1.setFilterRow(filterRow.getRowString(), filterRow.getAccess());
    					}
    					// The last filterRow got from Server is null itself, so no need to add an extra null Row.
    					//filter1.setFilterRow("",null);
    				}
    			}
    		}
    	}
    	System.out.println("Successfully copied App, "+origApp +" to "+repApp+" with privileges.");
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CopyOlapAppAndCube.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
