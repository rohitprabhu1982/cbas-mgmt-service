/*
    File: GetOlapUser.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
*/
package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.datasource.IEssOlapLicenseInfo;
import com.essbase.api.datasource.IEssOlapUser;
import com.essbase.api.datasource.IEssOlapGroup;
import com.essbase.api.session.IEssbase;

/*//NOTE: Below 2 imports are commented to remove css*.jar dependency
  //Enable this if you want to try the "getToken" method & AppManCSSApplication. 
import com.hyperion.css.CSSAPIIF;
import com.hyperion.css.CSSSystem;
*/

/**
    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author 
    @version 1.1, 18 Jul 06
*/
public class GetOlapUser {

    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default   

    private static String appName = "sample";
    private static String DbName = "basic";
    private static String securityProtocol = "CSS";

    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            /* Use this for Testcase to test EssLoginAs */
            //IEssDomain dom = ess.signOnAs(s_userName, s_password, false, "user1", "http://" + s_prefEesSvrName + ":11080/eds/EssbaseEnterprise");

            /* Use the following stmt to test shared services LoginExAs; */
            //IEssDomain dom = ess.signOnAs(s_userName, getToken(s_userName, s_password), true, "user1", "http://" + s_prefEesSvrName + ":11080/eds/EssbaseEnterprise");

            // Use this overloaded for TCPIP mode.
            /*IEssDomain dom = ess.signOn(s_userName, s_password, s_domainName,
               s_prefEesSvrName, s_orbType, s_port);*/

            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            getOlapInfo(olapSvr);
            manageOlapUser(olapSvr);
            
            manageOlapExternalUser(olapSvr);
            getOlapUser(olapSvr);
            getOlapUsers(olapSvr);
//            getOlapGroups(olapSvr);
//            getOlapGroupList(olapSvr);
//            manageOlapGroup(olapSvr);
        } catch (EssException x) {
            System.err.println("ERROR: " + x.getMessage());
            x.printStackTrace();
            statusCode = FAILURE_CODE;
        } 
        catch (Exception e) {
        	e.printStackTrace();
        }
        finally {
            // Sign Off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }
    
    static void getOlapInfo(IEssOlapServer olapSvr) {
        System.out.println("\n::GetOlapInfo::");
    	try {
    		IEssOlapLicenseInfo licenseInfo = olapSvr.getOlapLicenseInfo(s_olapSvrName + ":1423");
            System.out.println("License Expiry Date:"+licenseInfo.getLicenseExpiryDate());
            
            short securityMode = olapSvr.getOlapSecurityMode();
            System.out.println("Olap Security mode is: "+ securityMode);
    	}
    	catch (Exception x) {
            System.out.println("\n::GetOlapInfo failed with error:");
            x.printStackTrace();
    	}
    }

    static void manageOlapUser(IEssOlapServer olapSvr) {
    	try {
    		String newuser = "testuser1";
        	IEssOlapUser olapUser = olapSvr.createOlapUser(newuser, "password");
        	System.out.println("\n::ManageOlapUser::");
        	System.out.println("created user "+newuser);
        	newuser = "newtestuser1";
        	olapUser.renameUser(newuser);
        	System.out.println("renamed user to "+olapUser.getName());
        	olapUser.setUser(IEssOlapUser.EEssAccess.ESS_ACCESS_SUPER, 0, true);
        	System.out.println("Expiration : "+ olapUser.getPasswordExpirationDate());
        	olapUser.deleteUser();
        	System.out.println("deleted user ");
        	
        	short userType = 1 ;    
        	olapUser = olapSvr.createOlapUserWithType(newuser,"password",userType);
        	System.out.println("created user "+newuser+" with type " + olapUser.getUserType());
        	userType = 0 ;
        	short cmd = 1 ;
        	olapUser.setUserType(userType,cmd);
        	System.out.println("set usertype for user "+newuser+ " to "+ olapUser.getUserType());
        	olapUser.deleteUser();
        	System.out.println("deleted user "+newuser);
        	
        }
    	catch (Exception x) {
            System.out.println("\n::ManageOlapUser failed with error:");
            x.printStackTrace();
        }
    }
    static void manageOlapExternalUser(IEssOlapServer olapSvr) {
    	try {
    		if(olapSvr.getOlapSecurityMode()==2){
    			// the user extUser must be present in shared services.
    			String extUser = "shareduser";
    			IEssOlapUser olapExtUser = olapSvr.createOlapExtUser(extUser,
    					"password", securityProtocol, "");
    			System.out.println("Created External User : "
    					+ olapExtUser.getName());
    			olapExtUser.deleteUser();
    			System.out.println("deleted External user ");
    			short userType = 1;
    			olapExtUser = olapSvr.createOlapExtUserWithType(extUser,
    					"password", securityProtocol, "", userType);
    			System.out.println("created user " + extUser + " with type "
    					+ olapExtUser.getUserType());
    			olapExtUser.deleteUser();
    			System.out.println("deleted External user " + extUser);
    		}else {
    			System.out.println("To check the create External User Functionality Essbase must be in shared Services Mode ");
    		}
    	} catch (Exception x) {
    		System.out.println("\n::ManageOlapExternalUser failed with error:");
    		x.printStackTrace();
    	}
    }

    static void getOlapUser(IEssOlapServer olapSvr) {
        try {
            IEssOlapUser usr = olapSvr.getOlapUser(s_userName);
            System.out.println("\n::GetOlapUser::");
            System.out.println("Last Login time:"+usr.getLastLoginDate());
            IEssIterator usrGrps = usr.getGroups();
            for (int i=0; i < usrGrps.getCount(); i++) {
            	IEssOlapGroup group = (IEssOlapGroup)usrGrps.getAt(i);
                System.out.println("User " + usr.getName() +" belongs to :"+group.getName());
            }
        }
        catch (Exception x) {
            System.out.println("\n::GetOlapUser failed with error:");
            x.printStackTrace();
        }
    }

    static void getOlapUsers(IEssOlapServer olapSvr) {
        try {
            IEssIterator users = olapSvr.getOlapUsers(null, null, null, false);
            int length = users.getCount();
            System.out.println("\n::GetOlapUsers:: - All Users");
            for (int i=0; i < length; i++) {
            	IEssOlapUser usr = (IEssOlapUser)users.getAt(i);
                System.out.println("User Name:"+usr.getName());
            }
            users = olapSvr.getOlapUsers(appName, DbName, securityProtocol, true);
            length = users.getCount();
            System.out.println("\n::GetOlapUsers:: - Only External Users");
            for (int i=0; i < length; i++) {
            	IEssOlapUser usr = (IEssOlapUser)users.getAt(i);
                System.out.println("User Name:"+usr.getName());
            }
        }
        catch (Exception x) {
            System.out.println("\n::GetOlapUsers:: failed with error:");
            x.printStackTrace();
        }
    }
    
    static void getOlapGroups(IEssOlapServer olapSvr)  {
        try {
            IEssIterator groups = olapSvr.getOlapGroups(appName, DbName);
            int length = groups.getCount();
            System.out.println("\n::GetOlapGroups::");
            if (length <=0) System.out.println("There are no Olap Groups.");
            else {
                for (int i=0; i < length; i++) {
                    IEssOlapGroup group = (IEssOlapGroup)groups.getAt(i);
                    System.out.println("Group Name:"+group.getName());
                }
            }
        }
        catch (Exception x) {
            System.out.println("\n::GetOlapGroups:: failed with error:");
            x.printStackTrace();
        }
    }
    
    static void getOlapGroupList(IEssOlapServer olapSvr) {
        try {
        	// The code assumes that a group by name group1 exists
            IEssOlapGroup group = olapSvr.getOlapGroup(s_userName);
            IEssIterator users = group.getUsers();
            int length = users.getCount();
            System.out.println("\n::GetOlapGroupList:: For group '" + group.getName() + "'");
            if (length <=0) System.out.println("There are no users found under this group.");
            else {
                for (int i=0; i < length; i++) {
                    IEssOlapUser user = (IEssOlapUser)users.getAt(i);
                    System.out.println("User Name:"+user.getName());
                }
            }
        }
        catch (Exception x) {
            System.out.println("\n::GetOlapGroupList:: failed with error:");
            x.printStackTrace();
        }
    }
    
    static void manageOlapGroup(IEssOlapServer olapSvr) throws EssException{
    	String groupName = "group1";
    	String userName = "user1";
    	IEssOlapGroup olapGrp = olapSvr.createOlapGroup(groupName);
    	System.out.println("\n::ManageOlapGroup:: Olap Group " + olapGrp.getName() + " created successfully.");
    	IEssOlapUser olapUsr = olapSvr.createOlapUser(userName, "password");
    	olapGrp.addUser(olapUsr);
    	System.out.println("\n::ManageOlapGroup:: User " + olapUsr.getName() + " added successfully.");
    	
    	olapGrp.removeUser(olapUsr);
    	System.out.println("\n::ManageOlapGroup:: User " + olapUsr.getName() + " removed successfully.");
    	olapUsr.deleteUser();
    	olapGrp.delete();
    	System.out.println("\n::ManageOlapGroup:: group " + groupName + " deleted successfully.");
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + GetOlapUser.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }

    // --- BEGIN: Commented to remove dependency on css*.jar
    //  (Also, this is not valid for EmbeddedJAPI Samples)
    //  Enable if you want to try this
    /*
    public static String getToken(String user, String pwd) throws Exception {
    	CSSAPIIF css = CSSSystem.getInstance().getCSSAPI();
    	java.util.Map context = new java.util.HashMap();
    	context.put(CSSAPIIF.LOCALE, Locale.getDefault());
    	context.put(CSSAPIIF.LOG_PREPEND_TEXT, "");
    	context.put(CSSAPIIF.FORCE_DEPENDENCY_CHECK, "TRUE");
    	
    	css.initialize(context, new AppManCSSApplication()); // app is AppManCSSApplication

    	context = new java.util.HashMap();
    	context.put(CSSAPIIF.LOGIN_NAME, user);
    	context.put(CSSAPIIF.PASSWORD, pwd);
    	com.hyperion.css.common.CSSUserIF cssusr = css.authenticate(context);
    	String token = cssusr.getToken(); 
    	System.out.println("Token is ::"+token);
    	return token;
    }

    private static class AppManCSSApplication implements com.hyperion.css.application.CSSApplicationIF {
        public AppManCSSApplication() {
        }

        public java.net.URL getConfigFile() throws com.hyperion.css.CSSException {
        	try {
        		java.net.URL url = new java.net.URL("http://BLRL2798:58080/interop/framework/getCSSConfigFile"); // TODO: change this to css.xml
        		return url;
        	}
        	catch (Exception e) {
        		e.printStackTrace();
        		throw new com.hyperion.css.CSSException(e.getMessage());
        	}
        }

        //Log messages coming from CSS to the Framework logger
        // @see com.hyperion.css.CSSApplicationIF#log
        public void log(String p0) {
        }
        public String[] getUserIdentities() throws com.hyperion.css.CSSException {
            return null;
        }
        public void reAssignIdentity(String p0, String p1) throws com.hyperion.css.CSSException {
            return;
        }
    } */ //--- END: Commented to remove dependency on css*.jar

}


