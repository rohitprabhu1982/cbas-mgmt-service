/*
    File: GetLoginIDRequest.java	1.0, 2006-8-3
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapRequest;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.IEssbase;

/**
 * GetLoginIDRequest
 * Signons to Essbase server and retrieves the login id of the sign-in user.
 * Retrives the list of executing requests from Olap server.
 * @author Satish Ramanavarapu
 * Aug 3, 2006
 */
public class GetLoginIDRequest {

    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
	
	/**
	 * @param args
	 */
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            log("Login ID for " + s_userName + ":" +olapSvr.getLoginId());
            IEssIterator requests = olapSvr.getRequests(null, null, null);
            for (int i = 0; i < requests.getCount(); i++) {
            	IEssOlapRequest request = (IEssOlapRequest)requests.getAt(i);
            	log("Request "+ i + " with code:" + request.getRequestCode() + 
            			" for Oper:" +request.getRequestString() +
            			" for LoginID:" +request.getLoginId() + 
            			" with UserID:" +request.getUserName());
//            	request.kill(); // open to kill the request
            }
            // sleep (to ensure that operation from other sessions get to the agent) and 
            // repeat just to check if you get the same loginid. 
            try { Thread.sleep(3000); } catch (Exception e){}
            log("Login ID for " + s_userName + ":" +olapSvr.getLoginId());

        } catch (Exception x) {
            System.err.println("Error: " + x.getMessage());
            x.printStackTrace();
            statusCode = FAILURE_CODE;
        } finally {
        	comeOutClean(ess, olapSvr);
            //System.exit(0);
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    public static void comeOutClean(IEssbase ess, IEssOlapServer olapSvr) {
        try {
            if (olapSvr != null && olapSvr.isConnected() == true)
                olapSvr.disconnect();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }

        try {
            if (ess != null && ess.isSignedOn() == true)
                ess.signOff();
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
        }
    }

    public static void log (String str){
    	log(str, true);
    }
    
    public static void log(String str, boolean tab) {
    	if (tab) System.out.println("*::*\t" + str);
    	else System.out.println("*::*" + str);
    }
    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + GetLoginIDRequest.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
