/*
    File: BuildDimension.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;


/**
    BuildDimension example adds/removes members from the outline in the active
    database from a data file and rules file.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.0, 18 Jul 06
 */
public class BuildDimension {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_domainName = "essbase";
    private static String s_analyticSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "http://localhost:13080/aps/JAPI";//"Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0; // will set this to FAILURE only if err/exception occurs.
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the domain.
            IEssDomain dom = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with OLAP server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_analyticSvrName);
            olapSvr.connect();

            IEssCube cube = olapSvr.getApplication("Sample").getCube("Basic");
            cube.clearAllData();
            buildDimensionFile(cube);
            buildIncDimension(cube); /* sample for incremental build dim */
            buildStreamIncDimension(cube);/* sample for stream build dim */
            cube.buildDimension("Attrprod", IEssOlapFileObject.TYPE_RULES,
                "Attrprod", IEssOlapFileObject.TYPE_TEXT, "builddim.err");
            
            asyncBuildDimension(cube);
            
            System.out.println("Build Dimension completed.");
            
        } catch (EssException x) {
            System.out.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            // Close olap server connection and sign off from the domain.
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        /* Set status to failure only if exception occurs and do abnormal termination
           otherwise, it will by default terminate normally */ 
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }
        
    public static void buildDimensionFile(IEssCube cube) throws EssException {
    	cube.lockOlapFileObject(IEssOlapFileObject.TYPE_OUTLINE, cube.getName());
    	cube.buildDimensionStart();
    	cube.buildDimensionFile("Attrprod", IEssOlapFileObject.TYPE_RULES, 
    			"Attrprod", IEssOlapFileObject.TYPE_TEXT, "buildDim.err", true);
    	cube.restructure((short)IEssCube.EEssRestructureOption.KEEP_ALL_DATA.intValue());
    	cube.unlockOlapFileObject(IEssOlapFileObject.TYPE_OUTLINE, cube.getName());
    }

    // sample for incremental build dim
    public static void buildIncDimension(IEssCube cube) throws EssException {
    	cube.beginIncrementalBuildDim();
    	cube.incrementalBuildDim("Attrprod", IEssOlapFileObject.TYPE_RULES, "Attrprod", IEssOlapFileObject.TYPE_TEXT, 
    			null, null, IEssCube.ESS_INCDIMBUILD_BUILD, "tempotl", "buildDim.err",true);

//    	cube.incrementalBuildDim("MyGenOpty", IEssOlapFileObject.TYPE_RULES, null, IEssOlapFileObject.TYPE_TEXT, 
//    			"tbc", "password", IEssCube.ESS_INCDIMBUILD_BUILD, "tempotl", "buildDim.err");
    	cube.endIncrementalBuildDim(IEssCube.ESS_DOR_ALLDATA,"tempotl", "buildDim.err",true);
    }

    public static void buildStreamIncDimension(IEssCube cube) throws EssException {
    	cube.beginStreamBuildDim( "Attrprod", IEssOlapFileObject.TYPE_RULES,
                EssCube.ESS_INCDIMBUILD_ALL,  "Attrprod");
    	cube.sendString("500	500-10	64	True\n");
    	cube.sendString("500	500-20	64	False");
        cube.endStreamBuildDim("errorfile.err1",true);
    }
    
    public static void asyncBuildDimension(IEssCube cube) throws EssException {
    	// Plain build dimension.
    	cube.asyncBuildDimension("Attrprod", IEssOlapFileObject.TYPE_RULES,
    			"Attrprod", IEssOlapFileObject.TYPE_TEXT, null, null,
    			IEssCube.ESS_INCDIMBUILD_ALL, "tempotl");

    	// get Async process state.
    	EssBuildDimDataLoadState state = cube.getAsyncProcessState();

    	// check state until process is complete.
    	while(state.getProcessState() != IEssCube.ESS_BLDDL_STATE_DONE){
    		// wait for some time.
    		try{
    			Thread.sleep(1000);
    		}catch(InterruptedException x){}

    		// check again
    		state = cube.getAsyncProcessState();
    	}

    	// close async process.
    	cube.closeAsyncProcess();

  
    	cube.beginIncrementalBuildDim();

      	// Incremental async build Dimension.
    	cube.asyncBuildDimension("Attrprod", IEssOlapFileObject.TYPE_RULES,
    			"Attrprod", IEssOlapFileObject.TYPE_TEXT, null, null,
    			IEssCube.ESS_INCDIMBUILD_BUILD, "tempotl");

    	// get Async process state.
    	state = cube.getAsyncProcessState();

    	// check state until process is complete.
    	while(state.getProcessState() != IEssCube.ESS_BLDDL_STATE_DONE){
    		// wait for some time.
    		try{
    			Thread.sleep(1000);
    		}catch(InterruptedException x){}

    		// check again
    		state = cube.getAsyncProcessState();
    	}
    	
    	// get the process log
    	StringBuffer errLog = cube.getAsyncProcessLog("asyncbuilddim.err1", false, true);
    	
    	// close async process.
    	cube.closeAsyncProcess();
    	
    	// End incremental build dim
    	cube.endIncrementalBuildDim(IEssCube.ESS_DOR_ALLDATA,"tempotl", "asyncbuilddim.err1",true);
    }
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_analyticSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + BuildDimension.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(FAILURE_CODE); // Simply end
        }
    }
}
