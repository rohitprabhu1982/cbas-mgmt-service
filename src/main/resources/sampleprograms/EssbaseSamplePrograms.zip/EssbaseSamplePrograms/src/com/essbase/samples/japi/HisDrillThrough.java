/*
    File: HisDrillThrough.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.datasource.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    HisDrillThrough does the following: Signs on to essbase domain, Opens a cube
    view, Performs HIS drill-through, list reports, execute reports, and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment. If you change s_appName
    and s_cubeName, make sure to edit the method performCubeViewOperation()
    accordingly.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class HisDrillThrough {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default

    private static String s_appName = "Sample";
    private static String s_cubeName = "Basic";

    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            cv = dom.openCubeView("HIS Drill through", s_olapSvrName, s_appName,
                s_cubeName);

            // Perform HIS Drill through on a cell.
            performCubeViewOperation(cv);
            System.out.println("HisDrillThrough Completed.");
		} catch (EssException x){
            System.out.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
		} finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performCubeViewOperation(IEssCubeView cv)
            throws EssException {
        // Create a grid view with the input for the operation.
        IEssGridView grid = cv.getGridView();
        grid.setSize(2, 5);
        grid.setValue(0, 1, "Measures");
        grid.setValue(0, 2, "Scenario");
        grid.setValue(0, 3, "Product"); ;
        grid.setValue(0, 4, "Market");
        grid.setValue(1, 0, "Jan");
        
        // not required to set to true as its set by default
//        cv.setExtendedMemberComment(true);
//        cv.setRepeatMemberNames(true);        
//        cv.updatePropertyValues();
        
        // Create the operation specification.
        IEssOpRetrieve op = cv.createIEssOpRetrieve();

        // Perform the operation.
        cv.performOperation(op);

        listAndExecuteReports(grid.getCell(1, 1));
        System.out.println();
    }
    
    public static void listAndExecuteReports(IEssCell cell) throws EssException {
        IEssIterator linkedObjs = null;
    	if (cell instanceof EssMemberCell) {
    		System.out.println("Value is:"+((EssMemberCell) cell).getValue());
    		System.out.println("Cell type is :"+ cell.getCellType());
    		linkedObjs = ((EssMemberCell) cell).getLinkedObjects();
    	}
    	else if (cell instanceof EssDataCell) {
    		System.out.println("Value is:"+((EssDataCell) cell).getValue());
    		System.out.println("Cell type is :"+ cell.getCellType());
    		linkedObjs = ((EssDataCell) cell).getLinkedObjects();
    	}
    	else {
    		System.out.println("Not executing.");
    		return;
    	}

        int countObjs = linkedObjs.getCount();
        for (int i = 0; i < countObjs; i++) {
            IEssLinkedObject linkedObj = (IEssLinkedObject)linkedObjs.getAt(i);
            System.out.println("Id: " + linkedObj.getId());
            System.out.println("Native Id: " + (linkedObj).getNativeId());
            System.out.println("Type: " + linkedObj.getType());
            System.out.println("Creator: " + linkedObj.getCreatedBy());
            System.out.println("Last Update: " + linkedObj.getLastUpdateTime());
            IEssLinkedObject.EEssLinkedObjectType type = linkedObj.getType();
            // Check for the LinkedObject type based on the Cube.
            // Use IEssLinkedObject.EEssLinkedObjectType.HIS_DRILL_THROUGH for EIS spun Cube
            // Or Use IEssLinkedObject.EEssLinkedObjectType.BPM_DRILL_THROUGH for BPM spun Cube.
            if (type == IEssLinkedObject.EEssLinkedObjectType.BPM_DRILL_THROUGH) {
                IEssDrillThrough dtObj = (IEssDrillThrough) linkedObj;
                System.out.println("\nGet Properties...\n-------------");
                System.out.println("HIS name: " + dtObj.getIntegrationServerName());
                System.out.println("DS name: " + dtObj.getDataSourceName());
                System.out.println("User name: " + dtObj.getUserName());
                System.out.println("Input option: " + dtObj.getInputOption());

                System.out.println("\nListing and Executing Reports...\n"+
                    "----------------------------");
                IEssIterator reports = dtObj.getReports();
                for (int j = 0; j < reports.getCount(); j++) {
                    IEssDrillThroughReport report = (IEssDrillThroughReport)reports.getAt(j);
                    System.out.println("Name: " + report.getName());
                    System.out.println("Row governor: " + report.getRowGoverner());
                    System.out.println("Time governor: " + report.getTimeGoverner());
                    System.out.println("Customize: " + report.getCustomize());

                    report.execute();
                    System.out.println("\nOutput\n------");
                    int cntRows = report.getCountRows(),
                        cntCols = report.getCountColumns();
                    System.out.println("Num rows: " + cntRows + " Num cols: " +
                        cntCols);

                    for (int colId = 0; colId < cntCols; colId++)
                        System.out.print(report.getColumnName(colId) + "\t");
                    System.out.println();

                    for (int rowId = 0; rowId < cntRows; rowId++) {
                        for (int colId = 0; colId < cntCols; colId++)
                            System.out.print(report.getStringValue(rowId, colId) + "\t");
                        if (rowId > 10) {
                        	System.out.println("\nSpitted 10 rows. Breaking off...");
                        	break;
                        }
                        System.out.println();
                    }
                }
            }
        }

    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + HisDrillThrough.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}


