/*
    File: LinkedPartition.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
//import com.essbase.api.datasource.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;

/**
    LinkedPartition does the following: Signs on to essbase domain,
    Opens a cube view, Performs Retrieve, Looks for linked partition in a cell,
    and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment. If you change s_appName
    and s_cubeName, make sure to edit the method performCubeViewOperation()
    accordingly.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class LinkedPartition {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static String s_appName = "sample";
    private static String s_cubeName = "basic";
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            cv = dom.openCubeView("Linked Partition", s_olapSvrName, s_appName,
                s_cubeName);

            // Perform retrieve and look for linked partition in a cell.
            performCubeViewOperation(ess, cv);
            System.out.println("LinkedPartition Completed.");
		} catch (EssException x){
            System.out.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
		} finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.out.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performCubeViewOperation(IEssbase ess, IEssCubeView cv)
            throws EssException {
        // Create a grid view with the input for the operation.
        IEssGridView grid = cv.getGridView();
        grid.setSize(2, 5);
        grid.setValue(0, 1, "Measures");
        grid.setValue(0, 2, "Product");
        grid.setValue(0, 3, "Market"); ;
        grid.setValue(0, 4, "Scenario");
        grid.setValue(1, 0, "Year");

        // Create the operation specification.
        IEssOpRetrieve op = cv.createIEssOpRetrieve();

        // Perform the operation.
        cv.performOperation(op);

        IEssDataCell dataCell = (EssDataCell)grid.getCell(1, 1);

        System.out.println("Listing linked objects...");
        IEssIterator linkedObjs = dataCell.getLinkedObjects();
        int countObjs = linkedObjs.getCount();
        for (int i = 0; i < countObjs; i++) {
            IEssLinkedObject linkedObj = (IEssLinkedObject)linkedObjs.getAt(i);
            System.out.println("Id: " + linkedObj.getId());
            System.out.println("Type: " + linkedObj.getType());
            System.out.println("Creator: " + linkedObj.getCreatedBy());
            System.out.println("Last Update: " + linkedObj.getLastUpdateTime());
            if (linkedObj.getType() ==
                    IEssLinkedObject.EEssLinkedObjectType.CELL_NOTE) {
                System.out.println("Note: " + linkedObj.getDescription());
            } else {
                System.out.println("Object Name: " + linkedObj.getObjectName());
                System.out.println("Description: " + linkedObj.getDescription());
            }
            System.out.print("Member combination: ");
            String[] mbrComb = linkedObj.getMemberCombination();
            for (int j = 0; j < mbrComb.length; j++) {
                System.out.print((j != 0 ? "," : "") + mbrComb[j]);
            }

            if (linkedObj.getType() ==
                    IEssLinkedObject.EEssLinkedObjectType.PARTITION) {
                IEssLinkedPartition linkPart = (IEssLinkedPartition)linkedObj;
                System.out.print("\nPartition info: ");
                System.out.print("user=" + linkPart.getUserName());
                System.out.print(", password=" + linkPart.getPassword());
                System.out.print(", olap host=" + linkPart.getOlapServerName());
                System.out.print(", app=" + linkPart.getOlapApplicationName());
                System.out.println(", cube=" + linkPart.getCubeName());

                IEssCubeView linkPartCubeView = linkPart.openCubeView("Drill Across");
                performRetrieveOnLinkedPartition(linkPartCubeView);
                linkPartCubeView.close();
            }

            System.out.println("\n");
        }
    }

    static void performRetrieveOnLinkedPartition(IEssCubeView cv)
            throws EssException {
        // Perform the operation.
        cv.performOperation(cv.createIEssOpRetrieve());

        // Get the result and print the output.
        IEssGridView grid = cv.getGridView();
        int cntRows = grid.getCountRows(), cntCols = grid.getCountColumns();
        System.out.print("Query Results for Retrieve on linked partition:" + "\n" +
            "-----------------------------------------------------\n");
        for (int i = 0; i < cntRows; i++) {
            for (int j = 0; j < cntCols; j++)
                System.out.print(grid.getValue(i, j) + "\t");
            System.out.println();
        }
        System.out.println("\n");
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + LinkedPartition.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
