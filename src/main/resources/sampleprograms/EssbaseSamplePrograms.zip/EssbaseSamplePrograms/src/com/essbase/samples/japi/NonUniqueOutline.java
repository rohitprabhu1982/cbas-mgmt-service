/*
    File: NonUniqueOutline.java	1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;

/**
 * NonUniqueOutline does the following:
 * 1. Tests an exiting Sample Basic outline (EDIT MODE) to verify it allows Unique members only. 
 * 2. Creates a new Non Unique Enabled outline (EDIT MODE) and uses all the new Non Unique JAPIs
 *      provided like the following:
 *      FSpec 5.2:
 *          IEssCubeOutline.isNonUniqueMemberNameEnabled()
 *          IEssCubeOutline.setNonUniqueMemberNameEnabled(boolean)
 *      FSpec 6.1:  
 *          IEssOlapApplication.createCube(String, IEssCube.EEssCubeType, boolean )
 *      FSpec 6.4.2:
 *          IEssMember.isNameUnique()
 *      FSpec 6.4.3:
 *          IEssMember.getUniqueName()
 *      FSpec 6.4.4:
 *          IEssDimension.setDimensionNameUniqueness(boolean)
 *          IEssDimension.getDimensionNameUniqueness()
 *          IEssDimension.setGenerationName(int, String, boolean)
 *          IEssDimension.getGeneration(int)    
 *              IEssGeneration.isUnique()
 *          IEssDimension.setLevelName(int, String, boolean)
 *              IEssLevel.isUnique()
 *          IEssDimension.getLevel(int)
 *          IEssDimension.getGenerations()
 *          IEssDimension.getLevels()
 *      FSpec 6.4.5:
 *          IEssMember.setMemberId()
 *          IEssMember.getMemberId
 *          IEssCubeOutline.findMemberOnId(String)
 *          IEssMember.deleteMemberId()
 *      FSpec 6.5.1: 
 *          IEssMember.setOriginalMemberName
 *      FSpec 6.5.2:        
 *          IEssMember.EEssShareOption.EXTENDED_SHARED_MEMBER
 *      FSpec 6.5.3:
 *          IEssMember.getOriginalMember()
 * 
 * ----------------------------------------------------------------------
 *  In order for this sample to work in your environment, make sure to
 *  change the s_userName, s_password, s_domainName, s_prefEesSvrName,
 *  and s_olapSvrName to suit your environment.
 * ----------------------------------------------------------------------
 * @author Balaji S
 * @version 1.1, 19 Jul 06
 */
public class NonUniqueOutline {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        IEssOlapApplication app = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            
            /*
            // Begin TBR: If domain type is "File" & olap server entry doesnt exist, 
            // use the below commented piece to create the olap server instance.
            try {
                dom.createOlapServer("localhost");
            } catch (Exception e) {
                System.err.println("localhost Olap server probably exists: "
                        + e.getMessage());
            }
            // End TBR: Esp. for File Domain type. 
            */

            olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // Testing a unique outline...
            String appName = "Sample", uniqCubeName = "Basic", appDB = appName+'.'+uniqCubeName;
            app = olapSvr.getApplication(appName);
            IEssCube cube = app.getCube(uniqCubeName);
            System.out.println("Opening cube " + appDB + "...");
            IEssCubeOutline otl = cube.openOutline(); // Open in Read only mode
            System.out.println("Is Outline "+appDB+" Open: " + otl.isOpen());
            System.out.println("5.2(1) - "+appDB+" isNonUniqueMemberNameEnabled: "
                                        + otl.isNonUniqueMemberNameEnabled());
            otl.close();
			// Call the clearActive on current Cube (Sample/Basic) before using
			// different cube (Sample/basicNU) in same session.
            cube.clearActive();
            System.out.println(appDB + " Cube closed.");
            System.out.println("-------------------------\n");

            // -------------------- ------------------------
            // Create a new NEW Non Uniq cube Sample/BasicNU.
            String nonUniqCubeName = "BasicNU";
            appDB = appName+'.'+nonUniqCubeName;
            System.out.println("Creating a new cube '" + appDB + "'[that supports Duplicate Member Names]...");
            app = olapSvr.getApplication(appName);
            deleteCube(app, nonUniqCubeName);

            IEssCube nuCube = app.createCube(nonUniqCubeName,
                    IEssCube.EEssCubeType.NORMAL, true); // FSpec6.1

            // Create outline similar to that of Sample/Basic & restructure cube
            CreateOutline(nuCube);
            verifySavedOutline(nuCube);
            System.out.println("Creation of NonUnique Based Outline Successfully completed.");
        } catch (Exception x) {
            x.printStackTrace();
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                x.printStackTrace();
                System.err.println("Error: " + x.getMessage());
            }            
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void deleteCube(IEssOlapApplication app, String cubeName) {
        System.out.println("Deleting " + cubeName + " if already present...");
        try {
            app.deleteCube(cubeName);
            System.out.println("Cube "+ cubeName +" deleted successfully.");
        } catch (Throwable x) {
            try {
                IEssCube cube = app.getCube(cubeName);
                cube.unlockOlapFileObject(IEssOlapFileObject.TYPE_OUTLINE,
                        cubeName);
                cube.delete();
                System.out.println("Cube "+ cubeName +" deleted successfully.");
            } catch (Throwable x2) {
            }
        }
    }

    static void CreateOutline(IEssCube cube) /* throws EssException */{
        IEssCubeOutline otl = null;
        try {
            // Open the outline with lock.
            otl = cube.openOutline(false, true, false);

            setOutlineInformation(otl);

            otl.createAliasTable("Long Names");

            createStandardDimensionsAndMembers(otl);

            //setDynamicCalc(otl);

//            createAttributeDimensionsAndMembers(otl);
//
//            associateAttributeMembers(otl);

            otl.save(IEssCube.EEssRestructureOption.DISCARD_ALL_DATA);

            otl.close();
            otl = null;
        } catch (Exception x) {
            System.out.println("Error: " + x.getMessage());
            x.printStackTrace();
        } finally {
            if (otl != null) {
                try {
                    otl.close();
                } catch (EssException x) {
                    System.out.println("Error: " + x.getMessage());
                }
            }
        }
    }

    static void setOutlineInformation(IEssCubeOutline otl) throws Exception {
        otl.setAutoConfigure(false);
        otl.setCaseSensitive(false);
        otl.setUseNameOf(1);
        otl.setDefaultAverageMbrName("Avg");
        otl.setNonUniqueMemberNameEnabled(true);
        otl.updatePropertyValues();
    }

    static void createStandardDimensionsAndMembers(IEssCubeOutline otl)
            throws Exception {
        IEssDimension year = otl.createDimension("Year");
        System.out.println();
        System.out.println("Setting Year dimension as non-uniq'ness...");
        year.setDimensionNameUniqueness(false); // UNIT TESTING 6.4.4(1)
        System.out
                .println("Setting Year dimension as non-uniq'ness done. Verifying...");
        System.out.println("Is Year dimension unique: "
                + year.getDimensionNameUniqueness());
        System.out.println();
        
        year.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
        year.setCategory(IEssDimension.EEssDimensionCategory.TIME);
        year.updatePropertyValues();
        createChildMembers(year);
        year.setGenerationName(1, "History", false); // TESTING 6.4.4(3)
        year.setGenerationName(2, "Quarter", true);
        year.setGenerationName(3, "Month");

        IEssDimension measures = otl.createDimension("Measures", year);
        measures.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
        measures.setCategory(IEssDimension.EEssDimensionCategory.ACCOUNTS);
        measures.updatePropertyValues();
        createChildMembers(measures);

        IEssDimension product = otl.createDimension("Product", measures);
        product.setStorageType(IEssDimension.EEssDimensionStorageType.SPARSE);
        product.updatePropertyValues();
        createChildMembers(product);
        
        product.setLevelName(0, "SKU", false); // Testing 6.4.4(5)
        product.setLevelName(1, "Family");

        // Verifn of 6.4.4(5) thro' 6.4.4(6)
        System.out.println("2 Levels of Product set as '0.SKU(NonUniq)', '1.Family(Uniq)'");
        System.out.println("Verification of Uniq'ness at level...");
        IEssIterator levels = product.getLevels();
        for (int i = 0; i < levels.getCount(); i++) {
            IEssLevel lvl = (IEssLevel) levels.getAt(i);
            System.out.println("Product's Level #" + lvl.getNumber() + "["
                    + lvl.getName() + "] Uniq'ness: " + lvl.isUnique());
        }
        System.out.println();
        
        IEssDimension market = otl.createDimension("Market", product);
        market.setStorageType(IEssDimension.EEssDimensionStorageType.SPARSE);
        market.updatePropertyValues();
        createChildMembers(market);
        market.setGenerationName(2, "Region", false); // UNIT TESTING 6.4.4(3)
        market.setGenerationName(3, "State");

        // Verifn of 6.4.4(3) thro' 6.4.4(4)
        System.out
                .println("2 Generations of Market set as '2.Region(NonUniq)', "
                        + "'3.State(Uniq)'");
        System.out.println("Verification of Uniq'ness at gen...");
        IEssIterator gens = market.getGenerations();
        for (int i = 0; i < gens.getCount(); i++) {
            IEssGeneration gen = (IEssGeneration) gens.getAt(i);
            System.out.println("Market's Gen #" + gen.getNumber() + "["
                    + gen.getName() + "] Uniq'ness: " + gen.isUnique());
        }
        System.out.println();
        
        IEssDimension scenario = otl.createDimension("Scenario", market);
        scenario.setDescription("This is Scenario dimenion.");
        scenario.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
        scenario.updatePropertyValues();
        createChildMembers(scenario);
    }

    static void createChildMembers(IEssDimension dim) throws Exception {
        if (dim.getName().equals("Year")) {
            String[] qtrs = { "Qtr1", "Qtr2", "Qtr3", "Qtr4" };
            String[] qtrs_alias = { "Quarter1", "Quarter2", "Quarter3",
                    "Quarter4" };
            String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            String[] months_alias = { "January", "February", "March", "April",
                    "May", "Jun", "July", "August", "September", "October",
                    "November", "December" };

            IEssMember year = dim.getDimensionRootMember();
            IEssMember gen_2_mbr = null;
            for (int i = 0; i < qtrs.length; i++) {
                gen_2_mbr = year.createChildMember(qtrs[i], gen_2_mbr);
                gen_2_mbr.setAlias("Long Names", qtrs_alias[i]);
                IEssMember gen_3_mbr = null;
                for (int j = 0; j < 3; j++) {
                    gen_3_mbr = gen_2_mbr.createChildMember(months[3 * i + j],
                            gen_3_mbr);
                    gen_3_mbr.setAlias("Long Names", months_alias[3 * i + j]);
                }
            }
        } else if (dim.getName().equals("Measures")) {
            IEssMember measures = dim.getDimensionRootMember();
            IEssMember profit = measures.createChildMember("Profit");
            IEssMember margin = profit.createChildMember("Margin");
            margin.setAlias("Long Names", "Gross Margin");
            IEssMember sales = margin.createChildMember("Sales");
            sales.setAlias("Long Names", "Revenue");
            IEssMember cogs 
                = margin.createChildMember("COGS", sales,
                            "This is COGS member", IEssMember.EEssConsolidationType.SUBTRACTION,
                            false, true, IEssMember.EEssCurrencyConversionType.NONE, "",
                            IEssMember.EEssTimeBalanceOption.NONE,
                            IEssMember.EEssTimeBalanceSkipOption.NONE,
                            IEssMember.EEssShareOption.STORE_DATA);
//            IEssMember cogs = margin.createChildMember("COGS", sales);
            cogs.setAlias("Long Names", "Cost of Goods Sold");
            IEssMember totalExpenses = profit.createChildMember(
                    "Total Expenses", margin);
            totalExpenses
                    .setConsolidationType(IEssMember.EEssConsolidationType.SUBTRACTION);
            totalExpenses.setExpenseMember(true);
            totalExpenses.updatePropertyValues();
            IEssMember marketing = totalExpenses.createChildMember("Marketing");
            marketing
                    .setConsolidationType(IEssMember.EEssConsolidationType.ADDITION);
            marketing.setExpenseMember(true);
            marketing.updatePropertyValues();
            IEssMember payroll = totalExpenses.createChildMember("Payroll",
                    marketing);
            payroll.setExpenseMember(true);
            payroll.updatePropertyValues();
            IEssMember misc = totalExpenses.createChildMember("Misc", payroll);
            misc.setExpenseMember(true);
            misc.updatePropertyValues();
            misc.setAlias("Long Names", "Miscelleneous");
            IEssMember inventory = measures.createChildMember("Inventory",
                    profit);
            inventory
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            inventory.updatePropertyValues();
            IEssMember openingInventory = inventory
                    .createChildMember("Opening Inventory");
            openingInventory
                    .setTimeBalanceOption(IEssMember.EEssTimeBalanceOption.FIRST);
            openingInventory.setExpenseMember(true);
            openingInventory
                    .setFormula("IF(NOT @ISMBR(Jan))\"Opening Inventory\"=@PRIOR(\"Ending Inventory\");"
                            + " ENDIF; \"Ending Inventory\"=\"Opening Inventory\"+Additions-Sales;");
            openingInventory.updatePropertyValues();
            IEssMember additions = inventory.createChildMember("Additions",
                    openingInventory);
            additions
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            additions.setExpenseMember(true);
            additions.updatePropertyValues();
            IEssMember endingInventory = inventory.createChildMember(
                    "Ending Inventory", additions);
            endingInventory
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            endingInventory.setExpenseMember(true);
            endingInventory
                    .setTimeBalanceOption(IEssMember.EEssTimeBalanceOption.LAST);
            endingInventory.updatePropertyValues();
            IEssMember ratios = measures.createChildMember("Ratios", inventory);
            ratios
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            ratios.updatePropertyValues();
            IEssMember marginPercentage = ratios.createChildMember("Margin %");
            marginPercentage.setTwoPassCalculationMember(true);
            marginPercentage.setFormula("Margin % Sales;");
            marginPercentage.updatePropertyValues();
            IEssMember profitPercentage = ratios.createChildMember("Profit %",
                    marginPercentage);
            profitPercentage.setTwoPassCalculationMember(true);
            profitPercentage
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            profitPercentage.setFormula("Profit % Sales;");
            profitPercentage.updatePropertyValues();
            IEssMember profitPerOunce = ratios.createChildMember(
                    "Profit per Ounce", profitPercentage);
            profitPerOunce.setTwoPassCalculationMember(true);
            profitPerOunce
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            profitPerOunce.setFormula("Profit/@ATTRIBUTEVAL(Ounces);");
            profitPerOunce.updatePropertyValues();
        } else if (dim.getName().equals("Product")) {
            IEssMember product = dim.getDimensionRootMember();
            IEssMember p100 = product.createChildMember("100");
            p100.setAlias("Default", "Colas");
            IEssMember p100_10 = p100.createChildMember("100-10");
            p100_10.setAlias("Default", "Cola");
            IEssMember p100_20 = p100.createChildMember("100-20", p100_10);
            p100_20.setAlias("Default", "Diet Cola");
            IEssMember p100_30 = p100.createChildMember("100-30", p100_20);
            p100_30.setAlias("Default", "Caffeine Free Cola");
            IEssMember p200 = product.createChildMember("200", p100);
            p200.setAlias("Default", "Root Beer");
            IEssMember p200_10 = p200.createChildMember("200-10");
            p200_10.setAlias("Default", "Old Fashioned");
            IEssMember p200_20 = p200.createChildMember("200-20", p200_10);
            p200_20.setAlias("Default", "Diet Root Beer");
            IEssMember p200_30 = p200.createChildMember("200-30", p200_20);
            p200_30.setAlias("Default", "Sasparilla");
            IEssMember p200_40 = p200.createChildMember("200-40", p200_30);
            p200_40.setAlias("Default", "Birch Beer");
            IEssMember p300 = product.createChildMember("300", p200);
            p300.setAlias("Default", "Cream Soda");
            IEssMember p300_10 = p300.createChildMember("300-10");
            p300_10.setAlias("Default", "Dark Cream");
            IEssMember p300_20 = p300.createChildMember("300-20", p300_10);
            p300_20.setAlias("Default", "Vanilla Cream");
            IEssMember p300_30 = p300.createChildMember("300-30", p300_20);
            p300_30.setAlias("Default", "Diet Cream");
            IEssMember p400 = product.createChildMember("400", p300);
            p400.setAlias("Default", "Fruit Soda");
            IEssMember p400_10 = p400.createChildMember("400-10");
            p400_10.setAlias("Default", "Grape");
            IEssMember p400_20 = p400.createChildMember("400-20", p400_10);
            p400_20.setAlias("Default", "Orange");
            IEssMember p400_30 = p400.createChildMember("400-30", p400_20);
            p400_30.setAlias("Default", "Strawberry");
            IEssMember diet = product.createChildMember("Diet", p400);
            diet.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            diet.updatePropertyValues();
            diet.setAlias("Default", "Diet Drinks");
            IEssMember mbr_100_20 = diet.createChildMember("100-20", null,
                    IEssMember.EEssShareOption.SHARED_MEMBER); // UNIT
            mbr_100_20.setAlias("Default", "Diet Cola");
            IEssMember mbr_200_20 = diet.createChildMember("200-20",
                    mbr_100_20, IEssMember.EEssShareOption.SHARED_MEMBER);
            mbr_200_20.setAlias("Default", "Diet Root Beer");
            mbr_200_20.setMemberId("mbrID_200_20");
            
            IEssMember mbr_300_30 = diet.createChildMember("300-30",
                    mbr_200_20, IEssMember.EEssShareOption.SHARED_MEMBER);
            mbr_300_30.setAlias("Default", "Diet Cream");            
            
            //UNIT TESTING 6.5.2
            IEssMember mbr_400_10 = diet.createChildMember("400-10",
                    mbr_300_30, IEssMember.EEssShareOption.EXTENDED_SHARED_MEMBER);
            mbr_400_10.setAlias("Default", "Sample Ext Shrd Mem");
            mbr_400_10.setOriginalMemberName("400"); // UNIT TESTING 6.5.1
            System.out.println("6.5.1 - mbr_400_10.getOriginalMember:"
                    + mbr_400_10.getOriginalMemberName()); // UNIT TESTING 6.5.3
            System.out.println("mbr_400_10's share option: " + mbr_400_10.getShareOption());
            mbr_400_10.delete(); // Delete as this doesnt fit in the outline.
            System.out.println();
            
        } else if (dim.getName().equals("Market")) {
            IEssMember market = dim.getDimensionRootMember();
            IEssMember east = market.createChildMember("East");
            east.createUDA("Major Market");
            IEssMember newYork = east.createChildMember("New York");
            newYork.createUDA("Major Market");
            IEssMember massachusetts = east.createChildMember("Massachusetts",
                    newYork);
            massachusetts.createUDA("Major Market");
            IEssMember florida = east.createChildMember("Florida",
                    massachusetts);
            florida.createUDA("Major Market");
            IEssMember connecticut = east.createChildMember("Connecticut",
                    florida);
            connecticut.createUDA("Small Market");
            IEssMember newHampshire = east.createChildMember("New Hampshire",
                    connecticut);
            newHampshire.createUDA("Small Market");
            IEssMember west = market.createChildMember("West", east);
            IEssMember california = west.createChildMember("California");
            california.createUDA("Major Market");
            IEssMember oregon = west.createChildMember("Oregon", california);
            oregon.createUDA("Small Market");
            IEssMember washington = west
                    .createChildMember("Washington", oregon);
            washington.createUDA("Small Market");
            IEssMember utah = west.createChildMember("Utah", washington);
            utah.createUDA("Small Market");
            IEssMember nevada = west.createChildMember("Nevada", utah);
            nevada.createUDA("Small Market");
            nevada.createUDA("New Market");
            IEssMember south = market.createChildMember("South", west);
            south.createUDA("Small Market");
            IEssMember texas = south.createChildMember("Texas");
            texas.createUDA("Major Market");
            IEssMember oklahoma = south.createChildMember("Oklahoma", texas);
            oklahoma.createUDA("Small Market");
            IEssMember louisiana = south.createChildMember("Louisiana",
                    oklahoma);
            louisiana.createUDA("Small Market");
            louisiana.createUDA("New Market");
            IEssMember newMexico = south.createChildMember("New Mexico",
                    louisiana);
            newMexico.createUDA("Small Market");
            IEssMember central = market.createChildMember("Central", south);
            central.createUDA("Major Market");
            IEssMember illinois = central.createChildMember("Illinois");
            illinois.createUDA("Major Market");
            IEssMember ohio = central.createChildMember("Ohio", illinois);
            ohio.createUDA("Major Market");
            IEssMember wisconsin = central.createChildMember("Wisconsin", ohio);
            wisconsin.createUDA("Small Market");
            IEssMember missouri = central.createChildMember("Missouri",
                    wisconsin);
            missouri.createUDA("Small Market");
            IEssMember iowa = central.createChildMember("Iowa", missouri);
            iowa.createUDA("Small Market");
            IEssMember colorado = central.createChildMember("Colorado", iowa);
            colorado.createUDA("Major Market");
            colorado.createUDA("New Market");
        } else if (dim.getName().equals("Scenario")) {
            IEssMember scenario = dim.getDimensionRootMember();
            IEssMember actual = scenario.createChildMember("Actual");
            IEssMember budget = scenario.createChildMember("Budget", actual);
            budget
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            budget.updatePropertyValues();
            IEssMember variance = scenario
                    .createChildMember("Variance", budget);
            variance
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            variance.setTwoPassCalculationMember(true);
            variance.setFormula("@VAR(Actual, Budget);");
            variance.setMemberId("VarianceID"); // UNIT TEST 6.4.5(1)
            variance.updatePropertyValues();
            System.out.println("Set member id for Variance as 'VarianceID'. "
                    + "Verifying -- memberId=" + variance.getMemberId()); // UNIT
                                                                          // TEST
                                                                          // 6.4.5(3)
            System.out.println();
            
            IEssMember variance_percentage = scenario.createChildMember(
                    "Variance %", variance);
            variance_percentage
                    .setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            variance_percentage.setTwoPassCalculationMember(true);
            variance_percentage.setFormula("@VARPER(Actual, Budget);");
            variance_percentage.updatePropertyValues();
        }
    }

    static void verifySavedOutline(IEssCube cube) throws Exception {
        IEssCubeOutline otl = null;
        try {
            System.out.println("Verification of the newly created cube '"+cube+"'");
            // Open the outline with lock.
            otl = cube.openOutline(false, true, false);
            System.out.println("Is "+cube+"'s Outline Open: " + otl.isOpen());
            System.out.println("5.2(1) - "+cube+" isNonUniqueMemberNameEnabled: "
                    + otl.isNonUniqueMemberNameEnabled());
            IEssValueAny val = otl
                    .getPropertyValueAny(IEssCubeOutline.PROP_NON_UNIQUE_NAMES);
            System.out.println(
                    "5.2(1) - "+cube+"'s getPropertyValueAny(IEssCubeOutline.PROP_NON_UNIQUE_NAMES):"+val);
            
            // ---------------- Verifn of 6.5.* ---------
            IEssMember mbr = null, mbrOrg = null;
            mbr = otl.findMemberOnId("VarianceID");
            System.out.println("6.4.5(3): findMemberOnId(VarianceID): "
                    + ((mbr != null) ? mbr.getName()
                            : "NO SUCH MEMBERID OR FAILURE"));
            
            mbr = otl.findMember("Variance");
            System.out.println("6.4.5(3): Variance's MemberId: "
                    + ((mbr != null) ? mbr.getMemberId()
                            : "NO SUCH MEMBER by name 'Variance'"));  
            
            System.out.println(
                    "6.4.5(4): Deleting member Id for member '" + mbr.getName()+"'...");
            mbr.deleteMemberId();
            System.out.println("6.4.5(4): Deletion Done. Verifing MemberId deletion... ");
            System.out.println("6.4.5(4): " + mbr.getName()+"'s Member ID:" + mbr.getMemberId());
            mbr = otl.findMemberOnId("VarianceID"); // testing 6.5.2
            if (mbr == null) System.out.println("6.4.5(4): No member found for member-id 'VarianceID'.");
            else System.out.println("6.4.5(4): VarianceID member-id still hasnt been deleted. -- FAILURE!!!");
            
            mbr = otl.findMemberOnId("mbrID_200_20"); // testing 6.5.2
            System.out.println("Found a member with 'mbrID_200_20': " + ((mbr != null) ? mbr.getName() : null));
            System.out.println("6.5.2: Share option of "+mbr.getName()+": "
                    + ((mbr != null) ? (mbr.getShareOption().toString()
                            + ", [OrigMem: "
                            + mbr.getOriginalMemberName() + "]")
                            : ""));

            if (mbrOrg != null) {
                System.out.println("Just finding the original member using the typical findMember()...");
                mbr = otl.findMember(mbrOrg.getName());
                System.out.println("Is Member Found ? " + (mbr != null));
            }

            // Verify Fspec 6.4.4: IEssDimension.getGenerations and IEssDimension.getLevels
            System.out.println("\nFetching all the Generations & Levels of all dimensions...");
            IEssIterator dims = otl.getDimensions();
            for (int k=0; k < dims.getCount(); k++) {
                IEssDimension dim = (IEssDimension)dims.getAt(k); 
                //System.out.println("Verification of Uniq'ness at gen...");
                IEssIterator gens = dim.getGenerations();
                for (int i = 0; i < gens.getCount(); i++) {
                    IEssGeneration gen = (IEssGeneration) gens.getAt(i);
                    System.out.println(dim.getName() + "'s Gen #" + gen.getNumber() + "["
                            + gen.getName() + "] Uniq'ness: " + gen.isUnique());
                }
                System.out.println();
                IEssIterator lvls = dim.getLevels();
                for (int i = 0; i < gens.getCount(); i++) {
                    IEssLevel lvl = (IEssLevel) lvls.getAt(i);
                    System.out.println(dim.getName() + "'s Lvl #" + lvl.getNumber() + "["
                            + lvl.getName() + "] Uniq'ness: " + lvl.isUnique());
                }
                System.out.println();
            }            
            // ---------------- End of 6.5* ---------             
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        } finally {
            if (otl != null) {
                try {
                    otl.close();
                } catch (EssException x) {
                    System.out.println("Error: " + x.getMessage());
                }
            }
        }
    }

    static void associateAttributeMembers(IEssCubeOutline otl) throws Exception {
        otl.associateAttributeMember("100-10", "True");
        otl.associateAttributeMember("100-10", "12");
        otl.associateAttributeMember("100-10", "Can");
        otl.associateAttributeMember("100-10", "03-25-1996");

        otl.associateAttributeMember("100-20", "True");
        otl.associateAttributeMember("100-20", "12");
        otl.associateAttributeMember("100-20", "Can");
        otl.associateAttributeMember("100-20", "04-01-1996");

        otl.associateAttributeMember("100-30", "False");
        otl.associateAttributeMember("100-30", "16");
        otl.associateAttributeMember("100-30", "Bottle");
        otl.associateAttributeMember("100-30", "04-01-1996");

        otl.associateAttributeMember("200-10", "True");
        otl.associateAttributeMember("200-10", "12");
        otl.associateAttributeMember("200-10", "Bottle");
        otl.associateAttributeMember("200-10", "09-27-1995");

        otl.associateAttributeMember("200-20", "True");
        otl.associateAttributeMember("200-20", "16");
        otl.associateAttributeMember("200-20", "Bottle");
        otl.associateAttributeMember("200-20", "07-26-1996");

        otl.associateAttributeMember("200-30", "False");
        otl.associateAttributeMember("200-30", "12");
        otl.associateAttributeMember("200-30", "Bottle");
        otl.associateAttributeMember("200-30", "12-10-1996");

        otl.associateAttributeMember("200-40", "False");
        otl.associateAttributeMember("200-40", "16");
        otl.associateAttributeMember("200-40", "Bottle");
        otl.associateAttributeMember("200-40", "12-10-1996");

        otl.associateAttributeMember("300-10", "True");
        otl.associateAttributeMember("300-10", "20");
        otl.associateAttributeMember("300-10", "Bottle");
        otl.associateAttributeMember("300-10", "06-26-1996");

        otl.associateAttributeMember("300-20", "True");
        otl.associateAttributeMember("300-20", "20");
        otl.associateAttributeMember("300-20", "Bottle");
        otl.associateAttributeMember("300-20", "06-26-1996");

        otl.associateAttributeMember("300-30", "True");
        otl.associateAttributeMember("300-30", "12");
        otl.associateAttributeMember("300-30", "Can");
        otl.associateAttributeMember("300-30", "06-26-1996");

        otl.associateAttributeMember("400-10", "False");
        otl.associateAttributeMember("400-10", "32");
        otl.associateAttributeMember("400-10", "Bottle");
        otl.associateAttributeMember("400-10", "10-01-1996");

        otl.associateAttributeMember("400-20", "False");
        otl.associateAttributeMember("400-20", "32");
        otl.associateAttributeMember("400-20", "Bottle");
        otl.associateAttributeMember("400-20", "10-01-1996");

        otl.associateAttributeMember("400-30", "False");
        otl.associateAttributeMember("400-30", "32");
        otl.associateAttributeMember("400-30", "Bottle");
        otl.associateAttributeMember("400-30", "10-01-1996");

        otl.associateAttributeMember("New York", "21000000");

        otl.associateAttributeMember("Massachusetts", "9000000");

        otl.associateAttributeMember("Florida", "15000000");

        otl.associateAttributeMember("Connecticut", "6000000");

        otl.associateAttributeMember("New Hampshire", "3000000");

        otl.associateAttributeMember("California", "33000000");
        otl.associateAttributeMember("Oregon", "6000000");
        otl.associateAttributeMember("Washington", "6000000");

        otl.associateAttributeMember("Utah", "3000000");
        otl.associateAttributeMember("Nevada", "3000000");
        otl.associateAttributeMember("Texas", "21000000");

        otl.associateAttributeMember("Oklahoma", "6000000");
        otl.associateAttributeMember("Louisiana", "6000000");
        otl.associateAttributeMember("New Mexico", "3000000");

        otl.associateAttributeMember("Illinois", "12000000");
        otl.associateAttributeMember("Ohio", "12000000");
        otl.associateAttributeMember("Wisconsin", "6000000");

        otl.associateAttributeMember("Missouri", "6000000");
        otl.associateAttributeMember("Iowa", "3000000");
        otl.associateAttributeMember("Colorado", "6000000");
    }

    private static void createAttributeDimensionsAndMembers(IEssCubeOutline otl)
            throws Exception {
        // Create attribute dimensions.
        IEssDimension scenario = otl.findDimension("Scenario");

        IEssDimension caffeinated = otl.createAttributeDimension("Caffeinated",
                IEssDimension.EEssAttributeDataType.BOOLEAN, scenario);

        IEssDimension ounces = otl.createAttributeDimension("Ounces",
                IEssDimension.EEssAttributeDataType.NUMERIC, caffeinated);

        IEssDimension pkgtype = otl.createAttributeDimension("Pkg Type",
                IEssDimension.EEssAttributeDataType.TEXT, ounces);

        IEssDimension population = otl.createAttributeDimension("Population",
                IEssDimension.EEssAttributeDataType.NUMERIC, pkgtype);

        IEssDimension introdate = otl.createAttributeDimension("Intro Date",
                IEssDimension.EEssAttributeDataType.DATE, population);

        // Associate attribute dimensions with base dimensions.
        IEssDimension product = otl.findDimension("Product");
        otl.associateAttributeDimension(product, caffeinated);
        otl.associateAttributeDimension(product, ounces);
        otl.associateAttributeDimension(product, pkgtype);
        otl.associateAttributeDimension(product, introdate);
        IEssDimension market = otl.findDimension("Market");
        otl.associateAttributeDimension(market, population);

        createAttributeMembers(otl);
    }

    private static void createAttributeMembers(IEssCubeOutline otl)
            throws Exception {
        IEssMember caffeinated = otl.findMember("Caffeinated");
        IEssMember True = caffeinated.createChildMember("True");
        IEssMember False = caffeinated.createChildMember("False", True);

        IEssMember ounces = otl.findMember("Ounces");
        IEssMember d32 = ounces.createChildMember("32");
        IEssMember d20 = ounces.createChildMember("20", d32);
        IEssMember d16 = ounces.createChildMember("16", d20);
        IEssMember d12 = ounces.createChildMember("12", d16);

        IEssMember pkgtype = otl.findMember("Pkg Type");
        IEssMember bottle = pkgtype.createChildMember("Bottle");
        IEssMember can = pkgtype.createChildMember("Can", bottle);

        IEssMember population = otl.findMember("Population");
        IEssMember small = population.createChildAttributeMember("Small",
                IEssDimension.EEssAttributeDataType.NONE, null);
        IEssMember d3000000 = small.createChildAttributeMember("3000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, null);
        d3000000.setAlias("Default", "LT/= 3,000,000");
        IEssMember d6000000 = small.createChildAttributeMember("6000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d3000000);
        d6000000.setAlias("Default", "3,000,001--6,000,000");
        IEssMember medium = population.createChildAttributeMember("Medium",
                IEssDimension.EEssAttributeDataType.NONE, small);
        IEssMember d9000000 = medium.createChildAttributeMember("9000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, null);
        d9000000.setAlias("Default", "6,000,001--9,000,000");
        IEssMember d12000000 = medium.createChildAttributeMember("12000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d9000000);
        d12000000.setAlias("Default", "9,000,001--12,000,000");
        IEssMember d15000000 = medium.createChildAttributeMember("15000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d12000000);
        d15000000.setAlias("Default", "12,000,001--15,000,000");
        IEssMember d18000000 = medium.createChildAttributeMember("18000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d15000000);
        d18000000.setAlias("Default", "15,000,001--18,000,000");
        IEssMember large = population.createChildAttributeMember("Large",
                IEssDimension.EEssAttributeDataType.NONE, medium);
        IEssMember d21000000 = large.createChildAttributeMember("21000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, null);
        d21000000.setAlias("Default", "18,000,001--21,000,000");
        IEssMember d24000000 = large.createChildAttributeMember("24000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d21000000);
        d24000000.setAlias("Default", "21,000,001--24,000,000");
        IEssMember d27000000 = large.createChildAttributeMember("27000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d24000000);
        d27000000.setAlias("Default", "24,000,001--27,000,000");
        IEssMember d30000000 = large.createChildAttributeMember("30000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d27000000);
        d30000000.setAlias("Default", "27,000,001--30,000,000");
        IEssMember d33000000 = large.createChildAttributeMember("33000000",
                IEssDimension.EEssAttributeDataType.NUMERIC, d30000000);
        d33000000.setAlias("Default", "30,000,001--33,000,000");
        IEssMember introdate = otl.findMember("Intro Date");
        IEssMember d03_25_1996 = introdate.createChildMember("03-25-1996");
        IEssMember d04_01_1996 = introdate.createChildMember("04-01-1996",
                d03_25_1996);
        IEssMember d09_27_1995 = introdate.createChildMember("09-27-1995",
                d04_01_1996);
        IEssMember d07_26_1996 = introdate.createChildMember("07-26-1996",
                d09_27_1995);
        IEssMember d12_10_1996 = introdate.createChildMember("12-10-1996",
                d07_26_1996);
        IEssMember d06_26_1996 = introdate.createChildMember("06-26-1996",
                d12_10_1996);
        IEssMember d10_01_1996 = introdate.createChildMember("10-01-1996",
                d06_26_1996);
    }

    private static void setDynamicCalc(IEssCubeOutline otl) throws Exception {
        String[] mbrs = { "Qtr1", "Qtr2", "Qtr3", "Qtr4", "Year", "Margin",
                "Total Expenses", "Profit", "Margin %", "Profit %",
                "Profit per Ounce", "Variance", "Variance %" };
        for (int i = 0; i < mbrs.length; i++) {
            IEssMember mbr = otl.findMember(mbrs[i]);
            mbr.setShareOption(IEssMember.EEssShareOption.DYNAMIC_CALC);
            mbr.updatePropertyValues();
        }

        mbrs = new String[] { "Inventory", "Ratios", "Measures", "Scenario" };
        for (int i = 0; i < mbrs.length; i++) {
            IEssMember mbr = otl.findMember(mbrs[i]);
            mbr.setShareOption(IEssMember.EEssShareOption.LABEL_ONLY);
            mbr.updatePropertyValues();
        }
    }
    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + NonUniqueOutline.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }    
}
