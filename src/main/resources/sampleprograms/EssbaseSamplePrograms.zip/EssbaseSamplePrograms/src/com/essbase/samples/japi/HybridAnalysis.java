/*
    File: HybridAnalysis.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.dataquery.*;
import com.essbase.api.metadata.*;
import com.essbase.api.domain.*;

/**
    HybridAnalysis shows how to use the HA option for data query and meta data
    operations.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment. If you change s_appName
    and s_cubeName, make sure to edit the method performCubeViewOperation()
    accordingly.

    @author Srini Ranga
    @version 1.1, 19 Jul 06
 */
public class HybridAnalysis {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static String s_appName = "demo";
    private static String s_cubeName = "basic";
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssCubeView cv = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Perform Hybrid Analysis Data query operations.
            cv = dom.openCubeView("Hybrid Analysis Example", s_olapSvrName, s_appName,
                s_cubeName);

            // Set Hybrid Analysis Enabled as the default is false.
            cv.setHybridAnalysisEnabled(true);
            cv.updatePropertyValues();

            // Create a grid view with the input for the operation.
            IEssGridView grid = cv.getGridView();
            grid.setSize(2, 5);
            grid.setValue(0, 2, "Year");
            grid.setValue(0, 3, "Actual");
            grid.setValue(0, 4, "Product"); ;
            grid.setValue(1, 0, "Sales");
            grid.setValue(1, 1, "Market");
            performCubeViewOperation(ess, cv, "hybrid_zoomIn");

            performCubeViewOperation(ess, cv, "hybrid_retrieve");
            
            System.out.println("HybridAnalysis Completed.");
		} catch (EssException x){
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
		} finally{
            // Close cube view.
            try {
                if (cv != null)
                    cv.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            // Sign off from the domain.
            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void performCubeViewOperation(IEssbase ess, IEssCubeView cv,
            String opStr) throws EssException {

        IEssGridView grid = cv.getGridView();

        // Create the operation specification.
        IEssOperation op = null;

        if (opStr.equals("hybrid_retrieve")) {
            op = cv.createIEssOpRetrieve();
        } else if (opStr.equals("hybrid_zoomIn")) {
            op = cv.createIEssOpZoomIn();
            ((IEssOpZoomIn)op).addRange(1, 1, 1, 1);
        } else
            throw new EssException("Operation not supported.");

        // Perform the operation.
        cv.performOperation(op);

        // Get the result and print the output.
        int cntRows = grid.getCountRows(), cntCols = grid.getCountColumns();
        System.out.print("Query Results for the Operation: " + opStr + "\n" +
            "-----------------------------------------------------\n");
        for (int i = 0; i < cntRows; i++) {
            for (int j = 0; j < cntCols; j++)
                System.out.print(grid.getValue(i, j) + "\t");
            System.out.println();
        }
        System.out.println("\n");
    }

    static void performMemberSelection(IEssbase ess, IEssCubeView cv)
            throws EssException {
        System.out.print("Query Results for member selection: \n"  +
            "----------------------------------------------\n");
        String fldSel = "<OutputType Binary <SelectMbrInfo (MemberName, MemberLevel, MemberGen, Consolidation, MemberFormula, MemberAlias, DimensionName, Expense,  MemberNumber, DimensionNumber, ChildMemberName, ParentMemberName, PreviousMemberName, NextMemberName)",
               mbrSel = "@ichild(Product), @ichild(Market)";
        IEssMember[] mbrs = cv.memberSelection(mbrSel, fldSel);
        for (int i = 0; i < mbrs.length; i++) {
            IEssMember mbr = mbrs[i];
            System.out.println("Name: " + mbr.getName());
            System.out.println("Level: " + mbr.getLevelNumber());
            System.out.println("Generation: " + mbr.getGenerationNumber());
            System.out.println("Alias: " + mbr.getAlias("Default"));
            System.out.println("Consolidation: " + mbr.getConsolidationType());
            System.out.println("Formula: " + mbr.getFormula());
            System.out.println("Dimension name: " + mbr.getDimensionName());
            System.out.println("Child count: " + mbr.getChildCount());
            System.out.println("Parent name: " + mbr.getParentMemberName());
            System.out.println("Member number: " + mbr.getMemberNumber());
            System.out.println("Dimension number: " + mbr.getDimensionNumber());
        }

        mbrs = cv.memberSelection("Year", IEssMemberSelection.QUERY_TYPE_CHILDREN,
            IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, "Year", "", "");
         for (int i = 0; i < mbrs.length; i++) {
            IEssMember mbr = mbrs[i];
            System.out.println("Name: " + mbr.getName() +
                ", Desc: " + mbr.getDescription() +
                ", Level Num: " + mbr.getLevelNumber() +
                ", Gen Num: " + mbr.getGenerationNumber() +
                ", Child count: " + mbr.getChildCount() +
                ", Dim Name: " + mbr.getDimensionName() +
                ", Dim Category: " + mbr.getDimensionCategory().stringValue());
         }
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + HybridAnalysis.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}
