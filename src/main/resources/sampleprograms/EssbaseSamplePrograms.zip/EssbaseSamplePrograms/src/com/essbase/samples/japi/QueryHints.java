/*
    File: QueryHints.java 1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;

/**
 	QueryHints will work only on new aso outlines created from Beckett release onwards. 
 	If using an older outline, please migrate using AAS or through Esscmdq.
 	 
 	This sample uses a aso application created in AAS, and  with a few dimensions and
 	memebrs added to the newly created outline
 	 
    QueryHints Example does the following: Signs on to essbase domain,
    Performs various query hints related operations and Signs Off.

    In order for this sample to work in your environment, make sure to
    change the s_userName, s_password, s_domainName, s_prefEesSvrName,
    and s_olapSvrName to suit your environment.

    @author Abhijeet Katariya
    @version 1.1, 19 Jul 06
 */
public class QueryHints {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign on to the domain.
            IEssDomain dom = ess.signOn(s_userName, s_password, false,
                null, s_provider);
     
            // Open connection with olap server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            
            // IMPORTANT: To see the Query Hints Related API functionality 
            // run this with a Outline that has Query Hints
            IEssCube cube =null;
            boolean doesCubeExistNLoadable = false;
            try{
            	cube = olapSvr.getApplication("asotest2").getCube("sample");
            	doesCubeExistNLoadable = cube.isLoadable(); // Throws Exception if exists.
            }
            catch(EssException x){
            	System.out.println("asotest2"+"/"+"sample"+" doesnt exist to demo Query Hints APIs. \nINTENAL ERROR WAS:" + x.getMessage());
            }
            if(doesCubeExistNLoadable){
	            // Open the outline and do query hint operations.
	            queryHints(cube);
            }
        } catch (EssException x) {
            x.printStackTrace();
            System.err.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }
    
    static void queryHints(IEssCube cube) throws EssException {
        IEssCubeOutline outline = null;
        try {
            outline = cube.openOutline(false, true, true, false);      
            
            performQueryHintFunctions(outline);     
            
            outline.close();
            outline = null;
        } catch (EssException x) {
            x.printStackTrace();
            System.err.println("Error: " + x.getMessage());
        } finally {
            try {
                if (outline != null)
                    outline.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
    }
    
    private static void performQueryHintFunctions(IEssCubeOutline outline)
    	throws EssException {
    	System.out.println("\n\nhint count:" + outline.getQueryHintsCount());
    	System.out.println("hint size:" + outline.getQueryHintsSize());
    	
    	IEssIterator dims = outline.getDimensions();
    	IEssDimension dim1 = (IEssDimension)dims.getAt(0);
    	IEssDimension dim2 = (IEssDimension)dims.getAt(1);
    	IEssDimension dim3 = (IEssDimension)dims.getAt(2);
     	
    	IEssMember mbr1 = outline.findMember(dim1.getName());
    	IEssMember mbr2 = outline.findMember(dim2.getName());
    	IEssMember mbr3 = outline.findMember(dim3.getName());
      	IEssMember[] mbrArr = new IEssMember[]{mbr1, mbr2, mbr3 };
    	
     	int i=0, j=0;
    	for(i=0, j = 11; i < 3; i++, j++){
    		short orgweight = mbrArr[i].getAggregationLevelUsage();
    		System.out.println("mbr" + i + " level weight = " + orgweight);
    		mbrArr[i].setAggregationLevelUsage((short)j);
    		System.out.println("mbr" + i + " level weight after setting to " + 
    				j + " = " + mbrArr[i].getAggregationLevelUsage());
    	}
    	
    	IEssDimension[] dimArr = new IEssDimension[]{dim1, dim2, dim3};
    	
    		outline.setASOCompressionDimension(dimArr[0]);
    	
    		IEssDimension dim = outline.getASOCompressionDimension();
    		if (dim != null)
    		{
    			System.out.println("asodim=" + dim.getName());
    		}
    	outline.addQueryHint(new IEssMember[]{mbr1});
    	outline.addQueryHint(new IEssMember[]{mbr1, mbr2});
     	
    	System.out.println("\n\nhint count:" + outline.getQueryHintsCount());
    	System.out.println("hint size:" + outline.getQueryHintsSize());
     	
     	outline.setQueryHint(1, new IEssMember[]{mbr1, mbr2});
    	outline.setQueryHint(2, new IEssMember[]{mbr1, mbr2, mbr3});
     	
    	IEssIterator it = outline.getQueryHint(1, 1);
    	iteraterMembers(it);
    	it = outline.getQueryHint(1, 2);
    	iteraterMembers(it);
    	
    	System.out.println("hint count:" + outline.getQueryHintsCount());
    	System.out.println("hint size:" + outline.getQueryHintsSize());
    	
    	outline.deleteQueryHint(1);
    	System.out.println("hint count:" + outline.getQueryHintsCount());
    	System.out.println("hint size:" + outline.getQueryHintsSize());
    	it = outline.getQueryHint(1, 1);
    	iteraterMembers(it);    	
    }
    
    private static void iteraterMembers(IEssIterator it) throws EssException {
    	if(it != null) {
    		for (int i=0; i < it.getCount(); i++) {
       			System.out.println(((IEssMember)it.getAt(i)).getName());
    		}
    	}
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + QueryHints.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}