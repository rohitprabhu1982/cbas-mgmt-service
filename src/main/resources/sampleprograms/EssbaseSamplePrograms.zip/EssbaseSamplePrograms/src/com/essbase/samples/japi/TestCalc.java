package com.essbase.samples.japi;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.IEssbase;
import com.essbase.samples.japi.CubeOpWrapper.CubeOpDelegate;

/**
 * Use the EssCube2 fake class to call a calc on the App.
 * 
 * @author jasonwjones
 *
 */
public class TestCalc {

	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "custadmin";
	private static String s_password = "custadmin";
	private static String s_olapSvrName = "ussltcovm668.solutions.glbsnet.com";
	/*
	 * Possible values for s_provider: "Embedded" or
	 * "http://localhost:13080/aps/JAPI"
	 */
	private static String s_provider = "http://ussltcovm668.solutions.glbsnet.com:13080/aps/JAPI"; // Default

	public static void main(String[] args) throws Exception {
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;
		ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

		// Sign On to the Provider
		IEssDomain dom = ess.signOn(s_userName, s_password, false, null, s_provider);

		// Open connection with olap server and get the cube.
		olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
		olapSvr.connect();
		IEssCube cube = olapSvr.getApplication("CBAS").getCube("CBAS");
		//cube.calcFileWithRunTimeSubVarFile(false, "TMPAGG", null);
		cube.calcFileWithRunTimeSubVarFile(false, "ALLOC1", null);
		/*
		 * CubeOpWrapper.execute(new CubeOpDelegate<Boolean>() { public Boolean
		 * run(IEssCube cube) throws EssException {
		 * 
		 * // Call our fake cube wrapper // EssCube2 cube2 = new EssCube2("Basic", 4,
		 * (EssOlapApplication) // cube.getApplication());
		 * 
		 * // Run an app level calc cube.calcFileWithRunTimeSubVarFile(false, "TMPAGG",
		 * null);
		 * 
		 * System.out.println("Calculated"); return Boolean.TRUE; } });
		 */

	}

}
