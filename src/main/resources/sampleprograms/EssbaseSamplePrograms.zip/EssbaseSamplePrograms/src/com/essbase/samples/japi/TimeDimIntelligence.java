/*
    File: GetMembers.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;
                                                                       
/**
    TimeDimIntelligence Example show cases the Time Intelligence APIs 
    related to a "Date Time" Dimension. 

    In order for this sample to work in your environment, make sure to
    change the s_* to suit your environment.

    @author Balaji S
    @version 1.0, 2 Mar 07
 */
public class TimeDimIntelligence {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";
    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    private static final String s_appName = "TDapp";
    private static final String s_cubeName = "TDdb";
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server and get the cube.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();
            
            // IMPORTANT: To see the Time Dimension Related API functionality 
            // run this with a Outline that Date-Time Dimension 
            IEssCube cube = null;
            boolean doesCubeExistNLoadable = false;
            try {
            	cube = olapSvr.getApplication(s_appName).getCube(s_cubeName);
            	doesCubeExistNLoadable = cube.isLoadable(); // Throws Exception if exists.
            }
            catch (EssException x) {
            	System.out.println(s_appName+"/"+s_cubeName+" doesnt exist to demo Time Intelligence APIs. \nINTENAL ERROR WAS:" + x.getMessage());
            }
            if (doesCubeExistNLoadable) {
	            // Perform member selection query and do member operations.
	            queryTimePeriods(cube);
	            performMemberSelection1(cube);
	            performMemberSelection2(cube);
	            performMemberSelection4(cube);
            }
		} catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void displayTimeDimMemberProperties(IEssMember mbr) throws EssException {
        System.out.println("\n--- Member Properties of \"" + mbr.getUniqueName() + "\" ---");
        System.out.println("Name: " + mbr.getName());
        System.out.println("Dimension category: " + mbr.getDimensionCategory());
        System.out.println("Dimension storage category: " + mbr.getDimensionStorageCategory());

        // Below two APIs are related to Time Dimension Intelligence.  
        System.out.println("Linked Attribute Attachment Level: " + mbr.getLinkedAttributeAttachLevel());
        System.out.println("Attributes Assocn Level: " + mbr.getAttributeAssocLevel());
        //System.out.println("--------------------------------------");
    }
    
    /* Show Cases IEssMemberSelection.getTimePeriods() API
     */
    static void queryTimePeriods(IEssCube cube) throws EssException {
    	System.out.println("~~~~~~~~~ BEGIN: queryTimePeriods ~~~~~~~~~~~~~~");
        IEssMemberSelection mbrSel = null;
        try {
        	mbrSel = cube.openMemberSelection("Sample member selection");
        	// Specify your DateTime Dimension Name
        	IEssCube.EEssTimePeriod[] tps =  mbrSel.getTimePeriods("DateTimeDim", IEssMemberSelection.QUERY_TIDIM_TIMEPERIODS);
        	for (int i = 0; i < tps.length; i++) {
        		System.out.println("Gen" + (i+1) + "'s Time Period = " + tps[i].stringValue());
            }
        } catch (EssException x) {
            System.err.println("Error: " + x.getMessage());
            x.printStackTrace();
        } catch (Exception e) {
	        System.err.println("Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
            try {
            	if (mbrSel != null) 
                    mbrSel.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
	    System.out.println("~~~~~~~~~ ENG: queryTimePeriods ~~~~~~~~~~~~~~\n");
    }    
    
    /* Performs Member Selection and uses IEssMemberSelection.executeQuery(String) API
     * to fetch a given LVA (Linked Attr dimension) to see the attachment & assocn level values.  
     */
    static void performMemberSelection1(IEssCube cube) throws EssException {
		IEssMemberSelection mbrSel = null;
		System.out.println("~~~~~~~~~ BEGIN: Member Selection #1 ~~~~~~~~~~~~~~");
		try {
			mbrSel = cube.openMemberSelection("Sample member selection");
			mbrSel.executeQuery("Quarter by Year");
			//mbrSel.executeQuery("Population");
			IEssIterator mbrs = mbrSel.getMembers();
			for (int i = 0; (mbrs != null && i < mbrs.getCount()); i++) {
				IEssMember mbr = (IEssMember) mbrs.getAt(i);
				displayTimeDimMemberProperties(mbr);
			}
			System.out.println();

			mbrSel.close();
			mbrSel = null;
		} catch (EssException x) {
			System.err.println("Error: " + x.getMessage());
			//x.printStackTrace();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (mbrSel != null)
					mbrSel.close();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}
			System.out.println("~~~~~~~~~ END: Member Selection #1 ~~~~~~~~~~~~~~\n");			
		}
	}    

    /* Performs Member Selection and uses IEssMemberSelection.executeQuery(String, int, int, String, String, String)
     * to fetch a given LVA (Linked Attr dimension) to see the attachment & assocn level values.  
     */    
    static void performMemberSelection2(IEssCube cube) throws EssException {
    	System.out.println("~~~~~~~~~ BEGIN: Member Selection #2 ~~~~~~~~~~~~~~");
		IEssMemberSelection mbrSel = null;
		try {
			mbrSel = cube.openMemberSelection("Sample member selection");
			mbrSel.executeQuery("Quarter by Year",
			        IEssMemberSelection.QUERY_TYPE_DIMENSION,
			        IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, "", "", "");
			IEssIterator mbrs = mbrSel.getMembers();
			for (int i = 0; (mbrs != null && i < mbrs.getCount()); i++) {
				IEssMember mbr = (IEssMember) mbrs.getAt(i);
				displayTimeDimMemberProperties(mbr);
			}
			System.out.println();

			mbrSel.close();
			mbrSel = null;
		} catch (EssException x) {
			System.err.println("Error: " + x.getMessage());
			//x.printStackTrace();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (mbrSel != null)
					mbrSel.close();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}
			System.out.println("~~~~~~~~~ END: Member Selection #2 ~~~~~~~~~~~~~~\n");
		}
	}

    /* Performs Member Selection and uses IEssMemberSelection.executeQuery(String, int, int, String, String, String) 
     * API to fetch a given LVA (Linked Attr dimension) to see the attachment & assocn level values.  
     */    
    static void performMemberSelection3(IEssCube cube) throws EssException {
    	System.out.println("~~~~~~~~~ BEGIN: Member Selection #3 ~~~~~~~~~~~~~~");
    	IEssMemberSelection mbrSel = null;
		try {
			mbrSel = cube.openMemberSelection("Sample member selection");
			// TODO: How to fetch the LinkedAttributeLevel and Assocn Level ?? What are the corresponding field names ?
			String fldSelection = "<OutputType Binary <SelectMbrInfo (MemberName, MemberLevel, MemberGen, Consolidation, MemberFormula, MemberAlias, DimensionName, Expense,  MemberNumber, DimensionNumber, DimensionStorageCategory)",
				mbrSelection = "\"Month by Quarter\"";
				//mbrSelection = "(DateTimeDim, Semester by Year, Quarter by Semester)";
			mbrSel.executeQuery(fldSelection, mbrSelection);
			IEssIterator mbrs = mbrSel.getMembers();
			for (int i = 0; (mbrs != null && i < mbrs.getCount()); i++) {
				IEssMember mbr = (IEssMember) mbrs.getAt(i);
				displayTimeDimMemberProperties(mbr);
			}
			System.out.println();

			mbrSel.close();
			mbrSel = null;
		} catch (EssException x) {
			System.err.println("Error: " + x.getMessage());
			//x.printStackTrace();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (mbrSel != null)
					mbrSel.close();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}
			System.out.println("~~~~~~~~~ END: Member Selection #3 ~~~~~~~~~~~~~~\n");
		}
	}
	
    // This method show cases how to identify a DATE-TIME (Time Intelligent) dimension
    // and a LINKED ATTRIBUTE dimension.
	static void performMemberSelection4(IEssCube cube) throws EssException {
		System.out.println("~~~~~~~~~ BEGIN: Member Selection #4 ~~~~~~~~~~~~~~");
		IEssMemberSelection mbrSel = null;
		IEssCubeOutline otl = null;
		try {
			otl = cube.openOutline();
			IEssIterator dims = otl.getDimensions();
			//System.out.println("--- Start: Dimensions ---");
			for (int i = 0; dims != null && i < dims.getCount(); i++) {
				//displayDimensionProperties((IEssDimension)dims.getAt(i));
				//System.out.println("DIMENSION - " + ((IEssDimension)dims.getAt(i)).getName() );
				IEssDimension dim = ((IEssDimension) dims.getAt(i));
				// Fetch the member info for Time and Attribute dim and see if its a DATE-TIME dim or a 
				// LVA Dim respectively.
				if (IEssDimension.EEssDimensionTag.CTIME.equals(dim.getTag()) || 
						IEssDimension.EEssDimensionTag.ATTRIBUTE.equals(dim.getTag())) {
					
					mbrSel = cube.openMemberSelection("Sample member selection");
					mbrSel.executeQuery(dim.getName());
					IEssIterator mbrs = mbrSel.getMembers();
					for (int j = 0; (mbrs != null && j < mbrs.getCount()); j++) {
						IEssMember mbr = (IEssMember) mbrs.getAt(j);
						displayTimeDimMemberProperties(mbr);
						if (IEssDimension.EEssDimensionStorageCategory.DATE.equals(mbr.getDimensionStorageCategory())) {
							System.out.println("## This is a DATE TIME Dimension ##");	
						}
						else if (IEssDimension.EEssDimensionStorageCategory.LINKED_ATTRIBUTE.equals(mbr.getDimensionStorageCategory())) {
							System.out.println("## This is a LINKED ATTRIBUTE Dimension ##");
						}
					}
					System.out.println();
					mbrSel.close();
					mbrSel = null;
				}
			}
			System.out.println("--- End: Dimensions ---");

		} catch (EssException x) {
			System.err.println("Error: " + x.getMessage());
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (otl != null)
					otl.close();
				if (mbrSel != null)
					mbrSel.close();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}
		}
		System.out.println("~~~~~~~~~ END: Member Selection #4 ~~~~~~~~~~~~~~");		
	}
	
	static void displayDimensionProperties(IEssDimension dim) throws EssException {
        System.out.println("#########################");
        System.out.println("Name: " + dim.getName());
        System.out.println("Description: " + dim.getDescription());
        System.out.println("Dimension TYPE: " + dim.getPropertyName(IEssDimension.PROP_TYPE));
        System.out.println("Dimension number: " + dim.getDimensionNumber());
        System.out.println("Dimension storage type: " + dim.getStorageType());
        System.out.println("Dimension category: " + dim.getCategory());
        System.out.println("Dimension tag: " + dim.getTag());
        System.out.println("Declared size: " + dim.getDeclaredSize());
        System.out.println("Actual size: " + dim.getActualSize());
        System.out.println("Attribute dimension data type: " +
            dim.getAttributeDimensionDataType());
        System.out.println("#########################");
    }	
	
    
	static void acceptArgs(String[] args) throws EssException {
		if (args.length >= 4) {
			s_userName = args[0];
			s_password = args[1];
			s_olapSvrName = args[2];
			s_provider = args[3]; //PROVIDER
		} else if (args.length != 0) {
			System.err.println("ERROR: Incorrect Usage of this sample.");
			System.err.println("Usage: java "
			        + TimeDimIntelligence.class.getName()
			        + " <user> <password> <analytic server> <provider>");
			System.exit(1); // Simply end
		}
    }    
}

