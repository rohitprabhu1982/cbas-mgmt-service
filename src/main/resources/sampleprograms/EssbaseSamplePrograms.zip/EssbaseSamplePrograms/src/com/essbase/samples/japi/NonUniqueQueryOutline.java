/*
    File: NonUniqueQueryOutline.java	1.1, 2006-7-19
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;

/**
 * NonUniqueQueryOutline does the following:
 * Queries a NonUnique enabled outline (tuned to test the non unique 
 * outline created via the NonUniqueOutline.java sample)
 * This Sample is esp. aimed to cover the Non unique APIs in the Direct Mode. 
 * Covers:  
 * 		FSpec :
 * 			IEssMemberSelection.isNonUniqueMemberNameEnabled()
 *		FSpec 6.4.2:
 *			IEssMember.isNameUnique()
 *		FSpec 6.4.3:
 *			IEssMember.getUniqueName()
 *		FSpec 6.4.4:
 * 			IEssDimension.getGenerations()
 * 			IEssDimension.getLevels()
 *				IEssGeneration.isUnique()
 * 				IEssLevel.isUnique()
 * 		FSpec 6.4.5:
 * 			IEssMember.getMemberId
 *		FSpec 6.5.2: 		
 * 			IEssMember.EEssShareOption.EXTENDED_SHARED_MEMBER
 * 		FSpec 6.5.3:
 * 			IEssMember.getOriginalMember()
 * 
 * ---------------------------------------------------------------------------
 *	In order for this sample to work in your environment, make sure to
 *	change the s_userName, s_password, s_domainName, s_prefEesSvrName,
 *	and s_olapSvrName to suit your environment.
 * ---------------------------------------------------------------------------
 * @author Balaji S
 * @version 1.1, 19 Jul 2006
 */
public class NonUniqueQueryOutline {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
        "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default
    
    private static final int FAILURE_CODE = 1;

    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        IEssOlapApplication app = null;
        try {
            acceptArgs(args); // Reset variables if specified as command line args.
            
            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);
            
//            // Begin TBR: only for unit testing using File type 
//            try {
//                dom.createOlapServer("localhost");
//            } catch (Exception e) {
//                System.err.println("localhost Olap server probably exists: "
//                        + e.getMessage());
//            }
//            // End TBR: only for unit testing using File type 
            
            olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // Create a new NEW Non Uniq cube Sample/BasicNU.
            String appName = "Sample", uniqCubeName = "Basic";
            String nonUniqCubeName = "BasicNU";
            app = olapSvr.getApplication(appName);
            IEssCube nuCube = app.getCube(nonUniqCubeName); // FSpec6.1            
            
			// Queries the outline to test the non-unique apis.
			queryMemberSelection(nuCube);
            System.out.println("Querying on NonUnique Based Outline complete.");
            
        } catch (Exception x) {
            //x.printStackTrace();
            System.err.println("Error: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                x.printStackTrace();
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void queryMemberSelection(IEssCube cube) {
        IEssMemberSelection mbrSel = null;
        IEssCubeOutline queryModeOtl = null;
        try {
            String appDBName = cube.getApplicationName()+"/"+cube.getName();
            mbrSel = cube.openMemberSelection(appDBName + " member selection");

            System.out.println("Does "+appDBName+" database allow non-unique member names: " 
                    					+ mbrSel.isNonUniqueMemberNameEnabled());

            IEssIterator mbrs = null;
            
            // BEGIN : ----- Query to test Extended Shared Member, MemberID & UniqueName of Diet.[300-10] ---
            mbrSel.executeQuery("Diet", IEssMemberSelection.QUERY_TYPE_CHILDREN,
                    IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, "Product", "", "");         
            mbrs = mbrSel.getMembers();
            System.out.println
                ("Performing member selection (Select children of Diet in the Product Dimension):");
            for (int i = 0;  mbrs!= null && i < mbrs.getCount(); i++) {
                IEssMember mbr = (IEssMember)mbrs.getAt(i);
                System.out.print("Unique Name: " + mbr.getUniqueName() + // FSpec 6.4.3
                    ", Desc: " + mbr.getDescription() +
                    ", Level Num: " + mbr.getLevelNumber() +
                    ", Gen Num: " + mbr.getGenerationNumber() +
                    ", Child count: " + mbr.getChildCount() +
                    ", Dim Name: " + mbr.getDimensionName() +
                    ", Dim Category: " + mbr.getDimensionCategory().stringValue() +
                    ", Member ID: " + mbr.getMemberId() +
                    ", IsUnique: " + mbr.isNameUnique() + // FSpec 6.4.2
                    ", ShareOption: " + mbr.getShareOption()
                    );
                //FSpec 6.5.2
                if (mbr.getShareOption().equals(IEssMember.EEssShareOption.EXTENDED_SHARED_MEMBER)) {
                    System.out.println(", OriginalMember: " + mbr.getOriginalMemberName());
                }
                else {
                    System.out.println(", OriginalMember: NOT APPLICABLE");                        
                }
            }
            System.out.println();            
            // END : ----- Query to test Diet.[300-10] ---            

            // FSpec 6.4.4(7)
            System.out.println("---- Generations of Market Dimension: -------");
            IEssIterator gensOrLvls = mbrSel.getDimensionGenerations("Market");
            for (int i = 0;  gensOrLvls!= null && i < gensOrLvls.getCount(); i++) {
                System.out.println(gensOrLvls.getAt(i));
            }
            System.out.println("----------------------------------------------");
            System.out.println();
            
            // FSpec 6.4.4(8)
            System.out.println("----- Levels of Product Dimension: -----------");
            gensOrLvls = mbrSel.getDimensionLevels("Product");
            for (int i = 0;  gensOrLvls!= null && i < gensOrLvls.getCount(); i++) {
                System.out.println(gensOrLvls.getAt(i));
            }
            System.out.println("----------------------------------------------");

            mbrSel.close();
            mbrSel = null;
        } catch (EssException x) {
            //x.printStackTrace();
            System.err.println("Error: " + x.getMessage());
        } finally {
            try {
                if (mbrSel != null)
                    mbrSel.close();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
    }

    static void getMemberFromCube(IEssCube cube) throws EssException {
        IEssCubeOutline otl = null;
        try {
	        //cube.openMemberSelection("SampleBasicNU member selection");
	        otl = cube.openOutline();
	        IEssIterator mbrs = otl.executeQuery("Diet", IEssMemberSelection.QUERY_TYPE_CHILDREN,
	                IEssMemberSelection.QUERY_OPTION_MEMBERSONLY, "Product", "", "");
	        
	        // BEGIN : ----- Query to test Extended Shared Member ---
	        System.out.println
	            ("Performing member selection (Select children of Year):");
	        for (int i = 0;  mbrs!= null && i < mbrs.getCount(); i++) {
	            IEssMember mbr = (IEssMember)mbrs.getAt(i);
	            System.out.println("Unique Name: " + mbr.getUniqueName() +
	                ", Desc: " + mbr.getDescription() +
	                ", Level Num: " + mbr.getLevelNumber() +
	                ", Gen Num: " + mbr.getGenerationNumber() +
	                ", Child count: " + mbr.getChildCount() +
	                ", Dim Name: " + mbr.getDimensionName() +
	                ", Dim Category: " + mbr.getDimensionCategory().stringValue() +
	                ", Member ID: " + mbr.getMemberId() +
	                ", ShareOption: " + mbr.getShareOption() +
	            	", OriginalMember: " + mbr.getOriginalMemberName()
	                );
	        }
	        System.out.println();      
	        // END : ----- Query to test Extended Shared Member ---         
	
	        System.out.println
	                ("\nGetting a Dimension from Cube (Market): \n" +
	                 "---------------------------------");
	        IEssDimension market = cube.getDimension("Market");
	        //IEssMember rootMbr = dim.getDimensionRootMember();
	        IEssIterator gens = market.getGenerations();
	        for (int i = 0; i < gens.getCount(); i++) {
	            IEssGeneration gen = (IEssGeneration) gens.getAt(i);
	            System.out.println("Market's Gen #" + gen.getNumber() + "["
	                    + gen.getName() + "] Uniq'ness: " + gen.isUnique());
	        }
	        System.out.println("6.4.4(4) - Gen 1 of Market: " 
					+ market.getGeneration(1));
	        
	        System.out.println
			        ("\nGetting a Dimension from Cube (Product): \n" +
			         "---------------------------------");
			IEssDimension product = cube.getDimension("Product");
	        IEssIterator levels = product.getLevels();
	        for (int i = 0; i < levels.getCount(); i++) {
	            IEssLevel lvl = (IEssLevel) levels.getAt(i);
	            System.out.println("Product's Level #" + lvl.getNumber() + "["
	                    + lvl.getName() + "] Uniq'ness: " + lvl.isUnique());
	        }        
	        System.out.println("6.4.4(6) - Level 0 of Product: " 
	                				+ product.getLevel(0));  
	        
	    } catch (EssException x) {
	        //x.printStackTrace();
	        System.err.println("Error: " + x.getMessage());
	    } finally {
	        try {
	            if (otl != null)
	                otl.close();
	        } catch (EssException x) {
	            System.err.println("Error: " + x.getMessage());
	        }
	    }
    }
    
    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + NonUniqueQueryOutline.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }    
}