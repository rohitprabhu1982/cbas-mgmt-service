package com.essbase.samples.japi;

import java.io.File;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.base.IEssValueAny;
import com.essbase.api.dataquery.IEssCubeView;
import com.essbase.api.dataquery.IEssGridView;
import com.essbase.api.dataquery.IEssMdAxis;
import com.essbase.api.dataquery.IEssMdCluster;
import com.essbase.api.dataquery.IEssMdDataSet;
import com.essbase.api.dataquery.IEssMdMember;
import com.essbase.api.dataquery.IEssOpMdxQuery;
import com.essbase.api.dataquery.IEssOpUpdate;
import com.essbase.api.dataquery.IEssOperation;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapApplication;
import com.essbase.api.datasource.IEssOlapFileObject;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.metadata.IEssCubeOutline;
import com.essbase.api.metadata.IEssDimension;
import com.essbase.api.metadata.IEssMember;
import com.essbase.api.metadata.IEssMemberSelection;
import com.essbase.api.metadata.IEssSmartList;
import com.essbase.api.session.IEssbase;

/**
 * 	SmartListOutline does the following:
 * Signs on to essbase domain.
 * Creates a Cube with MemberType Enabled Outline.
 * Verifies smartlist outline editing APIs.
 * Performs the grid operations.
 * Deletes the outline.
 *  ----------------------------------------------------------------------
 *  In order for this sample to work in your environment, make sure to
 *  change the s_userName, s_password, s_domainName, s_prefEesSvrName,
 *  and s_olapSvrName to suit your environment.
 * ----------------------------------------------------------------------
 * @author adoshi1
 * @since 11.1.1.0.0
 */

public class SmartListOutline {
	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "system";
	private static String s_password = "password";

	private static String s_olapSvrName = "localhost";
	/* Possible values for s_provider: 
	    "Embedded" or "http://localhost:13080/aps/JAPI" */
	private static String s_provider = "Embedded"; // Default

	private static final int FAILURE_CODE = 1;

	public static void main(String[] args) {
		int statusCode = 0;
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;
		IEssOlapApplication app = null;
		try {
			acceptArgs(args);

			// Create JAPI instance.
			ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

			// Sign On to the Provider
			IEssDomain dom = ess.signOn(s_userName, s_password, false, null,
					s_provider);


			olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
			olapSvr.connect();

			// Testing a unique outline...
			String appName = "Sample", SLCubeName = "BasicSL", appDB = appName
			+ '.' + SLCubeName;
			// Create a new NEW Smartlist Enabled cube Sample/BasicSL.
			System.out.println("Creating a new cube '" + appDB
					+ "'[that supports smartlists]...\n");
			app = olapSvr.getApplication(appName);
			deleteCube(app, SLCubeName);

			IEssCube slCube = app.createCube(SLCubeName,
					IEssCube.EEssCubeType.NORMAL, true);

			// Create outline similar to that of Sample/Basic & restructure cube
			CreateOutline(slCube);
			verifySavedOutline(slCube);
			IEssCubeView cv = dom.openCubeView("Data Query Example", s_olapSvrName, appName,
	                SLCubeName);
			
			
			// Perform Smartlist related Grid APIs operations.  
			performOperation(cv);
			// Perform Smartlist related MDX APIs operations.
			performMdxQuery(cv);
			cv.close();
			// Delete the cube.
		//	slCube.delete();
		} catch (Exception x) {
			x.printStackTrace();
			System.err.println("Error: " + x.getMessage());
			statusCode = FAILURE_CODE;
		} finally {
			try {
				if (olapSvr != null && olapSvr.isConnected() == true)
					olapSvr.disconnect();
			} catch (EssException x) {
				System.err.println("Error: " + x.getMessage());
			}

			try {
				if (ess != null && ess.isSignedOn() == true)
					ess.signOff();
			} catch (EssException x) {
				x.printStackTrace();
				System.err.println("Error: " + x.getMessage());
			}
		}
		// Set status to failure only if exception occurs and do abnormal termination
		// otherwise, it will by default terminate normally
		if (statusCode == FAILURE_CODE)
			System.exit(FAILURE_CODE);
	}

	static void deleteCube(IEssOlapApplication app, String cubeName) {
		System.out.println("Deleting " + cubeName + " if already present...");
		try {
			app.deleteCube(cubeName);
			System.out.println("Cube " + cubeName + " deleted successfully.");
		} catch (Throwable x) {
			try {
				IEssCube cube = app.getCube(cubeName);
				cube.unlockOlapFileObject(IEssOlapFileObject.TYPE_OUTLINE,
						cubeName);
				cube.delete();
				System.out.println("Cube " + cubeName
						+ " deleted successfully.");
			} catch (Throwable x2) {
			}
		}
	}

	static void CreateOutline(IEssCube cube) /* throws EssException */{
		System.out.println("\n*********************************************************");
		System.out.println("Creating cube '" + cube + "'... ");
	
		IEssCubeOutline otl = null;
		try {
			// Open the outline with lock.
			otl = cube.openOutline(false, true, false);

			setOutlineInformation(otl);
			otl.createAliasTable("Long Names");
			createStandardDimensionsAndMembers(otl);
			otl.save(IEssCube.EEssRestructureOption.DISCARD_ALL_DATA);
			createSmartList(otl);
			otl.save(IEssCube.EEssRestructureOption.DISCARD_ALL_DATA);
			otl.close();
			otl = null;
			System.out.println("\nOutline creation completed successfully.");
			System.out.println("*********************************************************\n");			
		} catch (Exception x) {
			System.out.println("Error: " + x.getMessage());
			x.printStackTrace();
		} finally {
			if (otl != null) {
				try {
					otl.close();
				} catch (EssException x) {
					System.out.println("Error: " + x.getMessage());
				}
			}
		}
	}

	static void setOutlineInformation(IEssCubeOutline otl) throws Exception {
		otl.setAutoConfigure(false);
		otl.setCaseSensitive(false);
		otl.setMemberTypeEnabled(true);
		//otl.setNonUniqueMemberNameEnabled(false);
		otl.updatePropertyValues();

	}

	static void createStandardDimensionsAndMembers(IEssCubeOutline otl)
	throws Exception {
		IEssDimension year = otl.createDimension("Year");

		year.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
		year.setCategory(IEssDimension.EEssDimensionCategory.TIME);
		year.updatePropertyValues();
		createChildMembers(year);

		IEssDimension measures = otl.createDimension("Measures", year);
		measures.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
		measures.setCategory(IEssDimension.EEssDimensionCategory.ACCOUNTS);
		measures.updatePropertyValues();
		createChildMembers(measures);

		IEssDimension product = otl.createDimension("Product", measures);
		product.setStorageType(IEssDimension.EEssDimensionStorageType.SPARSE);
		product.updatePropertyValues();
		createChildMembers(product);

		IEssDimension market = otl.createDimension("Market", product);
		market.setStorageType(IEssDimension.EEssDimensionStorageType.SPARSE);
		market.updatePropertyValues();
		createChildMembers(market);
		IEssDimension scenario = otl.createDimension("Scenario", market);
		scenario.setDescription("This is Scenario dimension.");
		scenario.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
		scenario.updatePropertyValues();
		createChildMembers(scenario);
	}

	static void createSmartList(IEssCubeOutline otl) throws Exception {
		System.out.println("Creating Smartlist.."+ "\n");
		String smartListName ="SL1";
		// Creating the SmartList
		IEssSmartList sl1 = otl.createSmartList(smartListName);
		System.out.println("Smartlist created Successfully.."+ "\n");
		long[] IDs = {1,2,3};
		String[] text = {"One","Two","Three"};
		// Assigning IDs and Text to Smartlist
		sl1.putSmartList(IDs, text);
		otl.updatePropertyValues();
		// Finding a SmartList
		IEssSmartList tempSL = otl.findSmartList(smartListName);
		printSmartListInfo(tempSL);

		String tmpDir = System.getProperty("java.io.tmpdir");
		if (!tmpDir.endsWith(File.separator))
			tmpDir = tmpDir + File.separator;

		String tmpFile = tmpDir + "SmartlistExport";
		System.out.println("Exporting Smartlist.. to file "+ tmpFile + "\n");
		// exporting Smartlist to a file.
		tempSL.exportSmartList(tmpFile);
		IEssSmartList sl2 =otl.createSmartList("SL2");
		System.out.println("Importing Smartlist.. from file "+ tmpFile + "\n");
		// Importing Smartlist from a file.
		sl2.importSmartList(tmpFile);
		printSmartListInfo(sl2);
		IEssMember mbr = otl.findMember("Sales");
		System.out.println("Associating Smartlist with member " + mbr.getName() + "\n");
		// Associating Smartlist with a member. 
		mbr.setSmartList(tempSL);
		System.out.println("Associated Smartlist with member " + mbr.getName()+ " Successfully..\n");
		mbr = otl.findMember("Payroll");
		mbr.setSmartList(sl2);
		System.out.println("Getting SmartList Info .. \n");
		// Getting Smartlist Info.
		IEssSmartList SL = otl.getSmartListInfo(tempSL);
		printSmartListInfo(SL);
		mbr = otl.findMember("COGS");
		// Setting member Type to Date. 
		mbr.setMemberType(IEssMember.ESS_MEMBERTYPE_DATE);
		System.out.println("Setting member type to Date  for member " + mbr.getName()+ "\n");
		String dateFormatString  = otl.getDateFormatString();
		System.out.println("Current Date Format String is : " + dateFormatString);
		String newDateFormatString = "dd mon yyyy";
		System.out.println("Setting Date Format String to : " + newDateFormatString);
		otl.setDateFormatString(newDateFormatString);
		mbr = otl.findMember("Marketing");
		// Setting format String  
		mbr.setFormatString("mdxformat(concat(\"[\",concat(numtostr(cellvalue()),\"]\")))");
		System.out.println("Setting format String  for member " + mbr.getName()+"\n");
	}

	static void printSmartListInfo(IEssSmartList smartList) throws Exception {
		System.out.println("SmartList Name :" + smartList.getName());
		System.out.println("Smartlist IDs :");
		for(int i=0;i< smartList.getIDs().length;i++)
			System.out.print(" " + smartList.getIDs()[i]);
		System.out.println();
		System.out.println("Smartlist Texts :");
		for(int i=0;i< smartList.getText().length;i++)
			System.out.print(" " + smartList.getText()[i]);
		System.out.println();
		System.out.println();
		
	}
	static void createChildMembers(IEssDimension dim) throws Exception {
		if (dim.getName().equals("Year")) {
			String[] qtrs = { "Qtr1", "Qtr2", "Qtr3", "Qtr4" };
			String[] qtrs_alias = { "Quarter1", "Quarter2", "Quarter3",
			"Quarter4" };
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
					"Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
			String[] months_alias = { "January", "February", "March", "April",
					"May", "Jun", "July", "August", "September", "October",
					"November", "December" };

			IEssMember year = dim.getDimensionRootMember();
			IEssMember gen_2_mbr = null;
			for (int i = 0; i < qtrs.length; i++) {
				gen_2_mbr = year.createChildMember(qtrs[i], gen_2_mbr);
				gen_2_mbr.setAlias("Long Names", qtrs_alias[i]);
				IEssMember gen_3_mbr = null;
				for (int j = 0; j < 3; j++) {
					gen_3_mbr = gen_2_mbr.createChildMember(months[3 * i + j],
							gen_3_mbr);
					gen_3_mbr.setAlias("Long Names", months_alias[3 * i + j]);
				}
			}
		} else if (dim.getName().equals("Measures")) {
			IEssMember measures = dim.getDimensionRootMember();
			IEssMember profit = measures.createChildMember("Profit");
			IEssMember margin = profit.createChildMember("Margin");
			margin.setAlias("Long Names", "Gross Margin");
			IEssMember sales = margin.createChildMember("Sales");
			sales.setAlias("Long Names", "Revenue");
			IEssMember cogs = margin.createChildMember("COGS", sales,
					"This is COGS member",
					IEssMember.EEssConsolidationType.SUBTRACTION, false, true,
					IEssMember.EEssCurrencyConversionType.NONE, "",
					IEssMember.EEssTimeBalanceOption.NONE,
					IEssMember.EEssTimeBalanceSkipOption.NONE,
					IEssMember.EEssShareOption.STORE_DATA);
			//            IEssMember cogs = margin.createChildMember("COGS", sales);
			cogs.setAlias("Long Names", "Cost of Goods Sold");
			IEssMember totalExpenses = profit.createChildMember(
					"Total Expenses", margin);
			totalExpenses
			.setConsolidationType(IEssMember.EEssConsolidationType.SUBTRACTION);
			totalExpenses.setExpenseMember(true);
			totalExpenses.updatePropertyValues();
			IEssMember marketing = totalExpenses.createChildMember("Marketing");
			marketing
			.setConsolidationType(IEssMember.EEssConsolidationType.ADDITION);
			marketing.setExpenseMember(true);
			marketing.updatePropertyValues();
			IEssMember payroll = totalExpenses.createChildMember("Payroll",
					marketing);
			payroll.setExpenseMember(true);
			payroll.updatePropertyValues();
			IEssMember misc = totalExpenses.createChildMember("Misc", payroll);
			misc.setExpenseMember(true);
			misc.updatePropertyValues();
			misc.setAlias("Long Names", "Miscelleneous");
			IEssMember inventory = measures.createChildMember("Inventory",
					profit);
			inventory
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			inventory.updatePropertyValues();
			IEssMember openingInventory = inventory
			.createChildMember("Opening Inventory");
			openingInventory
			.setTimeBalanceOption(IEssMember.EEssTimeBalanceOption.FIRST);
			openingInventory.setExpenseMember(true);
			openingInventory
			.setFormula("IF(NOT @ISMBR(Jan))\"Opening Inventory\"=@PRIOR(\"Ending Inventory\");"
					+ " ENDIF; \"Ending Inventory\"=\"Opening Inventory\"+Additions-Sales;");
			openingInventory.updatePropertyValues();
			IEssMember additions = inventory.createChildMember("Additions",
					openingInventory);
			additions
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			additions.setExpenseMember(true);
			additions.updatePropertyValues();
			IEssMember endingInventory = inventory.createChildMember(
					"Ending Inventory", additions);
			endingInventory
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			endingInventory.setExpenseMember(true);
			endingInventory
			.setTimeBalanceOption(IEssMember.EEssTimeBalanceOption.LAST);
			endingInventory.updatePropertyValues();
			IEssMember ratios = measures.createChildMember("Ratios", inventory);
			ratios
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			ratios.updatePropertyValues();
			IEssMember marginPercentage = ratios.createChildMember("Margin %");
			marginPercentage.setTwoPassCalculationMember(true);
			marginPercentage.setFormula("Margin % Sales;");
			marginPercentage.updatePropertyValues();
			IEssMember profitPercentage = ratios.createChildMember("Profit %",
					marginPercentage);
			profitPercentage.setTwoPassCalculationMember(true);
			profitPercentage
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			profitPercentage.setFormula("Profit % Sales;");
			profitPercentage.updatePropertyValues();
			IEssMember profitPerOunce = ratios.createChildMember(
					"Profit per Ounce", profitPercentage);
			profitPerOunce.setTwoPassCalculationMember(true);
			profitPerOunce
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			profitPerOunce.setFormula("Profit/@ATTRIBUTEVAL(Ounces);");
			profitPerOunce.updatePropertyValues();
		} else if (dim.getName().equals("Product")) {
			IEssMember product = dim.getDimensionRootMember();
			IEssMember p100 = product.createChildMember("100");
			p100.setAlias("Default", "Colas");
			IEssMember p100_10 = p100.createChildMember("100-10");
			p100_10.setAlias("Default", "Cola");
			IEssMember p100_20 = p100.createChildMember("100-20", p100_10);
			p100_20.setAlias("Default", "Diet Cola");
			IEssMember p100_30 = p100.createChildMember("100-30", p100_20);
			p100_30.setAlias("Default", "Caffeine Free Cola");
			IEssMember p200 = product.createChildMember("200", p100);
			p200.setAlias("Default", "Root Beer");
			IEssMember p200_10 = p200.createChildMember("200-10");
			p200_10.setAlias("Default", "Old Fashioned");
			IEssMember p200_20 = p200.createChildMember("200-20", p200_10);
			p200_20.setAlias("Default", "Diet Root Beer");
			IEssMember p200_30 = p200.createChildMember("200-30", p200_20);
			p200_30.setAlias("Default", "Sasparilla");
			IEssMember p200_40 = p200.createChildMember("200-40", p200_30);
			p200_40.setAlias("Default", "Birch Beer");
			IEssMember p300 = product.createChildMember("300", p200);
			p300.setAlias("Default", "Cream Soda");
			IEssMember p300_10 = p300.createChildMember("300-10");
			p300_10.setAlias("Default", "Dark Cream");
			IEssMember p300_20 = p300.createChildMember("300-20", p300_10);
			p300_20.setAlias("Default", "Vanilla Cream");
			IEssMember p300_30 = p300.createChildMember("300-30", p300_20);
			p300_30.setAlias("Default", "Diet Cream");
			IEssMember p400 = product.createChildMember("400", p300);
			p400.setAlias("Default", "Fruit Soda");
			IEssMember p400_10 = p400.createChildMember("400-10");
			p400_10.setAlias("Default", "Grape");
			IEssMember p400_20 = p400.createChildMember("400-20", p400_10);
			p400_20.setAlias("Default", "Orange");
			IEssMember p400_30 = p400.createChildMember("400-30", p400_20);
			p400_30.setAlias("Default", "Strawberry");
			IEssMember diet = product.createChildMember("Diet", p400);
			diet.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			diet.updatePropertyValues();
			diet.setAlias("Default", "Diet Drinks");
			IEssMember mbr_100_20 = diet.createChildMember("100-20", null,
					IEssMember.EEssShareOption.SHARED_MEMBER); // UNIT
			mbr_100_20.setAlias("Default", "Diet Cola");
			IEssMember mbr_200_20 = diet.createChildMember("200-20",
					mbr_100_20, IEssMember.EEssShareOption.SHARED_MEMBER);
			mbr_200_20.setAlias("Default", "Diet Root Beer");
			mbr_200_20.setMemberId("mbrID_200_20");

			IEssMember mbr_300_30 = diet.createChildMember("300-30",
					mbr_200_20, IEssMember.EEssShareOption.SHARED_MEMBER);
			mbr_300_30.setAlias("Default", "Diet Cream");

		} else if (dim.getName().equals("Market")) {
			IEssMember market = dim.getDimensionRootMember();
			IEssMember east = market.createChildMember("East");
			east.createUDA("Major Market");
			IEssMember newYork = east.createChildMember("New York");
			newYork.createUDA("Major Market");
			IEssMember massachusetts = east.createChildMember("Massachusetts",
					newYork);
			massachusetts.createUDA("Major Market");
			IEssMember florida = east.createChildMember("Florida",
					massachusetts);
			florida.createUDA("Major Market");
			IEssMember connecticut = east.createChildMember("Connecticut",
					florida);
			connecticut.createUDA("Small Market");
			IEssMember newHampshire = east.createChildMember("New Hampshire",
					connecticut);
			newHampshire.createUDA("Small Market");
			IEssMember west = market.createChildMember("West", east);
			IEssMember california = west.createChildMember("California");
			california.createUDA("Major Market");
			IEssMember oregon = west.createChildMember("Oregon", california);
			oregon.createUDA("Small Market");
			IEssMember washington = west
			.createChildMember("Washington", oregon);
			washington.createUDA("Small Market");
			IEssMember utah = west.createChildMember("Utah", washington);
			utah.createUDA("Small Market");
			IEssMember nevada = west.createChildMember("Nevada", utah);
			nevada.createUDA("Small Market");
			nevada.createUDA("New Market");
			IEssMember south = market.createChildMember("South", west);
			south.createUDA("Small Market");
			IEssMember texas = south.createChildMember("Texas");
			texas.createUDA("Major Market");
			IEssMember oklahoma = south.createChildMember("Oklahoma", texas);
			oklahoma.createUDA("Small Market");
			IEssMember louisiana = south.createChildMember("Louisiana",
					oklahoma);
			louisiana.createUDA("Small Market");
			louisiana.createUDA("New Market");
			IEssMember newMexico = south.createChildMember("New Mexico",
					louisiana);
			newMexico.createUDA("Small Market");
			IEssMember central = market.createChildMember("Central", south);
			central.createUDA("Major Market");
			IEssMember illinois = central.createChildMember("Illinois");
			illinois.createUDA("Major Market");
			IEssMember ohio = central.createChildMember("Ohio", illinois);
			ohio.createUDA("Major Market");
			IEssMember wisconsin = central.createChildMember("Wisconsin", ohio);
			wisconsin.createUDA("Small Market");
			IEssMember missouri = central.createChildMember("Missouri",
					wisconsin);
			missouri.createUDA("Small Market");
			IEssMember iowa = central.createChildMember("Iowa", missouri);
			iowa.createUDA("Small Market");
			IEssMember colorado = central.createChildMember("Colorado", iowa);
			colorado.createUDA("Major Market");
			colorado.createUDA("New Market");
		} else if (dim.getName().equals("Scenario")) {
			IEssMember scenario = dim.getDimensionRootMember();
			IEssMember actual = scenario.createChildMember("Actual");
			IEssMember budget = scenario.createChildMember("Budget", actual);
			budget
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			budget.updatePropertyValues();
			IEssMember variance = scenario
			.createChildMember("Variance", budget);
			variance
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			variance.setTwoPassCalculationMember(true);
			variance.setFormula("@VAR(Actual, Budget);");
			variance.updatePropertyValues();
			IEssMember variance_percentage = scenario.createChildMember(
					"Variance %", variance);
			variance_percentage
			.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
			variance_percentage.setTwoPassCalculationMember(true);
			variance_percentage.setFormula("@VARPER(Actual, Budget);");
			variance_percentage.updatePropertyValues();
		}
	}

	static void verifySavedOutline(IEssCube cube) throws Exception {
		IEssCubeOutline otl = null;
		IEssMemberSelection mbrSln = null;
		try {
			System.out.println("\n*********************************************************");
			System.out.println("Verification of the newly created cube '"
					+ cube + "'... ");
			System.out.println(" ## Verification through IEssCubeOutline ##");
			// Open the outline with lock.
			otl = cube.openOutline(false, true, false);
			System.out.println("Is " + cube + "'s Outline Open: "
					+ otl.isOpen());
			System.out.println(cube + " isMemberTypeEnabled: "
					+ otl.isMemberTypeEnabled());
			System.out.println(cube + " isNonUniqueMemberNameEnabled: "
					+ otl.isNonUniqueMemberNameEnabled()+"\n");

			IEssSmartList SL = null, mbrOrg = null;
			IEssMember mbr = null;
			SL = otl.findSmartList("SL1");
			System.out.println("findSmartList(SL1): "
					+ ((SL != null) ? SL.getName()
							: "NO SUCH SMARTLIST OR FAILURE"));

			mbr = otl.findMember("Sales");
			SL = mbr.getSmartList();
			
			if(SL.getReferenceMembersCount()>0){
				System.out.println("Associated Members for smartlist " + SL.getName());
				IEssIterator itr = SL.getReferenceMembers(1000);
				for(int i=0;i<itr.getCount();i++) {
					IEssMember mem = (IEssMember) itr.getAt(i);
					System.out.println("Member name : " + mem.getName());
				}
			}
			
			System.out.println("Sales's associated SmartList: "
					+ ((mbr != null) ? mbr.getSmartList().getName()
							: "NO SUCH MEMBER by name 'Sales'"));
			
			IEssMember mbr1 = otl.findMember("COGS");
			System.out.println("Member Type of "+ mbr1.getName() + " is :" +mbr1.getMemberType()
					+ " and date format String is :" + otl.getDateFormatString() + "\n");
			
			mbr1 = otl.findMember("Marketing");
			System.out.println("Member Type of "+ mbr1.getName() + " is :" +mbr1.getMemberType()
					+ " and format String is :" + mbr1.getFormatString() + "\n");
			// Removing member association with the smartlist, so that Smartlist can be deleted. 
			mbr.setMemberType(IEssMember.ESS_MEMBERTYPE_NONE);
			System.out.println("Deleting SmartList... :" + SL.getName()+"\n");
			
			SL.delete();
			System.out.println("Deletion one.\n");
			otl.save(IEssCube.EEssRestructureOption.DISCARD_ALL_DATA);
			otl.close();
			
			// ### Member Selection example ###
			System.out.println(" ## Verification through IEssMemeberSelection ##");
			mbrSln = cube.openMemberSelection(
									"Member Type Enabled Member Selection");
			System.out.println(cube + " isMemberTypeEnabled: " 
								+ mbrSln.isMemberTypeEnabled()+"");
			System.out.println("\nVerification of created outline is Completed successfully");
			System.out.println("*********************************************************\n");
		} catch (EssException x) {
			System.out.println("Error: " + x.getMessage());
		} finally {
			if (otl != null && otl.isOpen()) {
				try {
					otl.close();
				} catch (EssException x) {
					System.out.println("Error: " + x.getMessage());
				}
			}
			if (mbrSln!=null) {
				try {
					mbrSln.close();
				} catch (EssException x) {
					System.out.println("Error: " + x.getMessage());
				}
			}
		}
	}

	// Grid API Demostration...
	static void performOperation(IEssCubeView cv) throws Exception {
		System.out.println("\n*********************************************************");
		System.out.println("Performing Cube View operations...\n");
		cv.setSuppressNumValues(false);
		cv.setFormattedValues(true);
		cv.updatePropertyValues();
		IEssGridView grid = cv.getGridView();
		grid.setSize(3, 7);
		grid.setValue(0, 3, "East");
		grid.setValue(1, 3, "Payroll");
		grid.setValue(1, 4, "COGS");
		grid.setValue(1, 5, "Marketing");
		grid.setValue(1, 6, "Sales");
		grid.setValue(2, 0, "Scenario");
		grid.setValue(2, 1, "100-10");
		grid.setValue(2, 2, "Jan");

		IEssOperation op = null;
		op = cv.createIEssOpRetrieve();
		cv.performOperation(op);

		printQueryResults(grid, "Retrieve");
		// Setting Smartlist Value
		grid.setValue(2, 3, "One");
		grid.setValue(2, 4, "13 Dec 2008");
		grid.setValue(2, 5, 120);
		grid.setValue(2, 6, 91000);
		IEssOpUpdate opUpd = cv.createIEssOpUpdate();
		cv.performOperation(opUpd); // Update

		cv.performOperation(cv.createIEssOpRetrieve()); // Retrieve again.
		printQueryResults(grid, "Update");
		cv.save();
		System.out.println("\nCube View operations performed Successfully.");
		System.out.println("*********************************************************\n");
	}
	
	static void printQueryResults(IEssGridView grid, String operation) throws Exception {
		// Get the result and print the output.
		int cntRows = grid.getCountRows(), cntCols = grid.getCountColumns();
		System.out.print("Query Results for the Operation: "+ operation + "\n"
				+ "-----------------------------------------------------\n");
		for (int i = 0; i < cntRows; i++) {
			for (int j = 0; j < cntCols; j++)
				System.out.print(grid.getValue(i, j) + "\t");
			System.out.println();
		}
		System.out.println("\n");
		
		 // Printing the cell value in detail
		System.out.print("Cell Values in detail"+ "\n"
				+ "-----------------------------------------------------\n");
		
        for (int i = 0; i < cntRows; i++) 
            for (int j = 0; j < cntCols; j++){
            	printCellValue(grid, i, j);
            	System.out.println();
        }
		System.out.println();
	}
	
	private static void printCellValue(IEssGridView grid, int row, int column)
    throws EssException {
    	IEssValueAny actualVal = grid.getValue(row, column);
//  	Will contatin Smarlist text name if cell content type is Smartlist
//  	else if it is date, then, contains the formatted date string
//  	else may contain a formatted text if its Double type of cell.
    	String fmtdCellTxtVal = grid.getFormattedValue(row, column);
    	int cellContentType = grid.getCellContentType(row, column);
    	if (fmtdCellTxtVal != null && fmtdCellTxtVal.length() > 0) {
    		String printSmlistName = (cellContentType == IEssGridView.CELL_CONTENT_TYPE_SMARTLIST) 
    		? (", SmartlistName = " +  grid.getSmartListName(row, column))
    				: "";
    		String printNumericValue = (grid.getCellContentType(row, column)!= IEssGridView.CELL_CONTENT_TYPE_MISSING) 
    		? (", NumericValue = " + grid.getDoubleValue(row, column))
    				: "";
    		System.out.print("Cell[" + row + "][" + column + "] = " + fmtdCellTxtVal
    				+ "\t{CellContentType = " + cellContentType + printNumericValue
    				+ printSmlistName
    				+ "}");
    	} else {
    		System.out.print("Cell[" + row + "][" + column + "] = " + actualVal +
    				"\t{CellContentType = " + cellContentType + "}");
    	}
    }
	
	static void acceptArgs(String[] args) throws EssException {
		if (args.length >= 4) {
			s_userName = args[0];
			s_password = args[1];
			s_olapSvrName = args[2];
			s_provider = args[3]; //PROVIDER
		} else if (args.length != 0) {
			System.err.println("ERROR: Incorrect Usage of this sample.");
			System.err.println("Usage: java "
					+ SmartListOutline.class.getName()
					+ " <user> <password> <analytic server> <provider>");
			System.exit(1); // Simply end
		}
	}
	
	/**
	 * Demonstrates MDX Query Execution involving Smartlist, Formatted Strings & Date
	 */
	static void performMdxQuery(IEssCubeView cv) throws Exception {
		System.out.println("\n*********************************************************");
		System.out.println("Performing MDX query operations... ");
		
		boolean bDataLess = false;
		boolean bNeedCellAttributes = false;
		boolean bHideData = true;
		// Just having a couple of sample MDX Queries. You may change code to
		// use any of these or try your own.
		String mdxquery = null;

		// This query is built for testing the outline which has the smartlist
		// data for the specified cells.
		// Either change the query to suit your outline with smartlists or
		// update the outline
		// to have smartlist data at the specified cells to test smartlist
		// related query.
		mdxquery = "select {[Measures].Levels(0).Members} on columns, " +
				"{([East],[Jan], [100-10], [Scenario])} on rows from sample.basicsl";
		IEssOpMdxQuery op = cv.createIEssOpMdxQuery();

		op.setQuery(bDataLess, bHideData, mdxquery, bNeedCellAttributes,
		        IEssOpMdxQuery.EEssMemberIdentifierType.NAME);
		// Enable XMLA Mode to true if you want the MDX Results according to the
		// XMLA Standards.
		// If below statement with "false" setting is not executed, Query will
		// by default be executed in non-XMLA Mode (according to Essbase Standards).
		op.setXMLAMode(false);

		/*
		 * These 3 options fetch Text based Cell values (if any as in case of
		 * Smartlist, Date & Formatted String Based cells) This are applicable
		 * with Essbase version 9.5 and above with a cube that supports "Textual
		 * Measures"
		 */
		op.setNeedFormattedCellValue(true);
		op.setNeedSmartlistName(true);
		op.setNeedFormatString(true);
		op.setNeedFormattedMissingCells(true);

		/*
		 * Enable this option if you want to see Meaningless cells. Applicate
		 * with Varying Attribute based outlines and effective with Essbase 9.5
		 * and above only
		 */
		op.setNeedMeaninglessCells(false);

		cv.performOperation(op);

		IEssMdDataSet mddata = cv.getMdDataSet();

		printMdDataSet(mddata, op);
		System.out.println("\nMDX query operations completed Successfully.");
		System.out.println("*********************************************************\n");
	}

	private static void printMdDataSet(IEssMdDataSet mddata, IEssOpMdxQuery op) throws Exception {

		IEssMdAxis[] axes = mddata.getAllAxes();

		int nAxes = axes.length;

		System.out.println("Number of axes: " + nAxes);

		// Get meta info about all the axes eg number of tuples in each axis,
		// number of dimensions in each axis, and if the axis is a slicer axis.
		for (int axisInd = 0; axisInd < nAxes; axisInd++) {
			if (axes[axisInd].isSlicerAxis())
				System.out.print("Slicer ");

			System.out.println("Axis " + axisInd + "  Number Of Tuples : "
			        + axes[axisInd].getTupleCount()
			        + " Number Of Dimensions : "
			        + axes[axisInd].getDimensionCount());
		}

		// Get the meta info about the dimensions represented in each axis.
		// For each dimension in each axis, get dimension name and get
		// property names and their data types that are fetched in the result
		// set for each of the members of these dimensions.

		for (int axisInd = 0; axisInd < nAxes; axisInd++) {
			IEssMdAxis axis = axes[axisInd];
			int nTuples = axis.getTupleCount();

			// Get all the dimensions and their info in this axis
			System.out.println("\nGetting dimensions in axis : " + axisInd);
			IEssMdMember[] dims = axis.getAllDimensions();
			for (int axisDimInd = 0; axisDimInd < dims.length; axisDimInd++) {
				IEssMdMember dim = dims[axisDimInd];
				int propscnt = dim.getCountProperties();
				System.out.println("Dim " + axisDimInd + "  dim name : "
				        + dim.getName() + " #props " + propscnt);

				for (int propInd = 0; propInd < propscnt; propInd++) {
					System.out.println("Property " + propInd + " Name : "
					        + dim.getPropertyName(propInd) + ",  Type : "
					        + dim.getPropertyDataType(propInd));
				}
			}
			// Here is how you can get all the tuple members in an axis. Get all
			// the members in each tuples, get member names and all their
			// properties
			// and property values.
			System.out.println("\nGetting members in all the tuples of axis : "
			        + axisInd);
			for (int tupleInd = 0; tupleInd < nTuples; tupleInd++) {
				System.out.println("\nTuple : " + tupleInd);
				IEssMdMember[] mbrs = axis.getAllTupleMembers(tupleInd);
				printMemberInfo(mbrs);
			}
		}

		// here is how you go through all the clusters to get all the tuples.
		// First get all the clusters in each axis and then loop through them.
		// Get all the members in each cluster. You can get the members for
		// each of the dimension in the cluster or you can get the members
		// in each of the tuple in the cluster. For all the members in each
		// tuple, get member names and all their properties and property values.
		System.out.println("\n\nPrinting results through clusters .....");
		for (int axisInd = 0; axisInd < nAxes; axisInd++) {
			IEssMdAxis axis = axes[axisInd];

			// Get all the clusters in this axis
			IEssMdCluster[] clusters = axis.getAllClusters();
			long nClusters = axis.getClusterCount();
			System.out.println("\nAxis " + axisInd + "  Num clusters "
			        + nClusters);

			for (int clusterInd = 0; clusterInd < nClusters; clusterInd++) {
				IEssMdCluster cluster = clusters[clusterInd];
				int clusterTupleCount = cluster.getTupleCount();

				// Get the members based on the dimension index
				System.out.println("\nCluster " + clusterInd + " Size "
				        + clusterTupleCount);
				for (int dimInd = 0; dimInd < cluster.getDimensionCount(); dimInd++) {
					IEssMdMember[] mbrs = cluster
					        .getAllDimensionMembers(dimInd);
					System.out.println("Cluster Dim " + dimInd
					        + " Number Of Members : " + mbrs.length);
				}
				// Get the members based on tuple index
				System.out
				        .println("\nGetting members in all the tuples of this cluster...");
				for (int tupleInd = 0; tupleInd < clusterTupleCount; tupleInd++) {
					System.out.println("\nTuple : " + tupleInd);
					printMemberInfo(cluster.getAllTupleMembers(tupleInd));
				}
			}
		}

		// Now get all the data cells in the result set. For each cell,
		// check whether the cell is missing or no access cell and then
		// get the double value of the cell.
		System.out.println("\n\n\nGetting all the cells...");
		System.out.println("Number of cells : " + mddata.getCellCount());

		for (int ulCellOrdinal = 0; ulCellOrdinal < mddata.getCellCount(); ulCellOrdinal++) {
			if (!op.isNeedFormattedMissingCells() && mddata.isMissingCell(ulCellOrdinal)) {
				System.out.println("Cell[" + ulCellOrdinal + "] = #Missing");
			} else if (mddata.isNoAccessCell(ulCellOrdinal)) {
				System.out.println("Cell[" + ulCellOrdinal + "] = #NoAccess");
			} else {
				printCellValue(mddata, ulCellOrdinal, op);
			}
		}
	}
    
	private static void printCellValue(IEssMdDataSet mddata, int cellOrdinal, IEssOpMdxQuery op)
	        throws EssException {
		
		String actualVal = (mddata.isMissingCell(cellOrdinal)) 
							? "#Missing" : "" + mddata.getCellValue(cellOrdinal);
		// Will contatin Smarlist text name if cell type is Smartlist
		// else if it is date, then, contains the formatted date string
		// else may contain a formatted text if its Double type of cell.
		String fmtdCellTxtVal = mddata.getFormattedValue(cellOrdinal);
		int cellType = mddata.getCellType(cellOrdinal);
		if (fmtdCellTxtVal != null && fmtdCellTxtVal.length() > 0) {
			String printSmlistName = (cellType == IEssMdDataSet.CELLTYPE_SMARTLIST) 
								? (", SmartlistName = " +  mddata.getSmartListName(cellOrdinal))
								: "";
			String printNumericValue = (!mddata.isMissingCell(cellOrdinal)) 
								? (", NumericValue = " + actualVal)
								: "";
			System.out.print("Cell[" + cellOrdinal + "] = " + fmtdCellTxtVal
			        + " {CellType = " + cellType + printNumericValue
			        + printSmlistName
			        + "}");
		} else {
			System.out.print("Cell[" + cellOrdinal + "] = " + actualVal);
		}
		
		if (op.isNeedFormatString()) {
			if (cellType == IEssMdDataSet.CELLTYPE_DATE
			        || cellType == IEssMdDataSet.CELLTYPE_DOUBLE) {
				System.out.println(" [FormatString = "
				        + mddata.getFormatString(cellOrdinal) + "]");
			} else {
				System.out.println();
			}
		}
	}
	
	private static void printMemberInfo(IEssMdMember[] members)
		    throws EssException {
		for (int mbrInd = 0; mbrInd < members.length; mbrInd++) {
			IEssMdMember member = members[mbrInd];
		
			System.out.println("Mbr " + mbrInd + " identifier "
			        + member.getName());
			int propcnt = member.getCountProperties();
			for (int propInd = 0; propInd < propcnt; propInd++) {
				IEssValueAny propval = member.getPropertyValueAny(propInd);
				System.out.println("Property " + propInd + " Name : "
				        + member.getPropertyName(propInd) + ",  Type : "
				        + member.getPropertyDataType(propInd) + ",  Value : "
				        + propval);
			}
		}
	}

}
