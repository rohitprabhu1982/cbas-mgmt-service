/*
    File: CreateOutline.java 1.1, 2006-7-18
    Copyright (c) 1991, 2007 Oracle and / or its affiliates. All rights reserved.
 */
package com.essbase.samples.japi;

import com.essbase.api.base.*;
import com.essbase.api.session.*;
import com.essbase.api.datasource.*;
//import com.essbase.api.dataquery.*;
import com.essbase.api.domain.*;
import com.essbase.api.metadata.*;

/**
    CreateOutline example does the following: creates a cube outline, creates
    dimensions, members and other outline elements, verifies the outline and
    restructures the cube.

    In order for this sample to work in your environment, make sure to
    change the s_* variables to suit your environment.

    @author Srini Ranga
    @version 1.1, 18 Jul 06
 */
public class CreateOutline {
    // NOTE: Change the following variables to suit your setup.
    private static String s_userName = "system";
    private static String s_password = "password";

    private static String s_olapSvrName = "localhost";
    /* Possible values for s_provider: 
     * "Embedded" or "http://localhost:13080/aps/JAPI" */
    private static String s_provider = "Embedded"; // Default

    private static final int FAILURE_CODE = 1;
    
    public static void main(String[] args) {
        int statusCode = 0;
        IEssbase ess = null;
        IEssOlapServer olapSvr = null;
        IEssOlapApplication app = null;
        try {
            acceptArgs(args);

            // Create JAPI instance.
            ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

            // Sign On to the Provider
            IEssDomain dom 
                = ess.signOn(s_userName, s_password, false, null, s_provider);

            // Open connection with olap server.
            olapSvr = (IEssOlapServer)dom.getOlapServer(s_olapSvrName);
            olapSvr.connect();

            // Create a new cube Sample/BasicB.
            String appName = "Sample", cubeName = "BasicB";
            app = olapSvr.getApplication(appName);

            try {
                app.deleteCube(cubeName);
                System.out.println("Cube is deleted...");
            } catch (Throwable x) {
                try {
                    IEssCube cube = app.getCube(cubeName);
                    cube.unlockOlapFileObject(IEssOlapFileObject.TYPE_OUTLINE, cubeName);
                    cube.delete();
                    System.out.println("Cube is deleted...");
                } catch (Throwable x2) {}
            }

            IEssCube cube = app.createCube(cubeName, IEssCube.EEssCubeType.NORMAL);

            // Create outline similar to that of Sample/Basic and restructure cube.
            createOutline(cube);
            System.out.println("Outline creation Completed.");
            
        } catch (EssException x) {
            System.err.println("ERROR: " + x.getMessage());
            statusCode = FAILURE_CODE;
        } finally {
            try {
                if (olapSvr != null && olapSvr.isConnected() == true)
                    olapSvr.disconnect();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }

            try {
                if (ess != null && ess.isSignedOn() == true)
                    ess.signOff();
            } catch (EssException x) {
                System.err.println("Error: " + x.getMessage());
            }
        }
        // Set status to failure only if exception occurs and do abnormal termination
        // otherwise, it will by default terminate normally
        if (statusCode == FAILURE_CODE) System.exit(FAILURE_CODE);
    }

    static void setOutlineInformation(IEssCubeOutline otl) throws EssException {
        otl.setAutoConfigure(false);
        otl.setCaseSensitive(false);
        otl.setUseNameOf(1);
		otl.setDefaultAverageMbrName("Avg");
        otl.updatePropertyValues();
    }

    static void createChildMembers(IEssDimension dim) throws EssException {
        if (dim.getName().equals("Year")) {
            String[] qtrs = {"Qtr1", "Qtr2", "Qtr3", "Qtr4"};
            String[] qtrs_alias = {"Quarter1", "Quarter2", "Quarter3", "Quarter4"};
			String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                "Aug", "Sep", "Oct", "Nov", "Dec"};
            String[] months_alias = {"January", "February", "March", "April", "May", "Jun", "July",
                "August", "September", "October", "November", "December"};

            IEssMember year = dim.getDimensionRootMember();
            IEssMember gen_2_mbr = null;
			for (int i = 0; i < qtrs.length; i++) {
                gen_2_mbr = year.createChildMember(qtrs[i], gen_2_mbr);
                gen_2_mbr.setAlias("Long Names", qtrs_alias[i]);
                IEssMember gen_3_mbr = null;
				for (int j = 0; j < 3; j++) {
                    gen_3_mbr = gen_2_mbr.createChildMember(months[3*i+j], gen_3_mbr);
                    gen_3_mbr.setAlias("Long Names", months_alias[3*i+j]);
				}
			}
        } else if (dim.getName().equals("Measures")) {
            IEssMember measures = dim.getDimensionRootMember();
                IEssMember profit = measures.createChildMember("Profit");
                    IEssMember margin = profit.createChildMember("Margin");
                    margin.setAlias("Long Names", "Gross Margin");
                        IEssMember sales = margin.createChildMember("Sales");
                        sales.setAlias("Long Names", "Revenue");
                        IEssMember cogs = margin.createChildMember("COGS", sales,
                            "This is COGS member", IEssMember.EEssConsolidationType.SUBTRACTION,
                            false, true, IEssMember.EEssCurrencyConversionType.NONE, "",
                            IEssMember.EEssTimeBalanceOption.NONE, IEssMember.EEssTimeBalanceSkipOption.NONE,
                            IEssMember.EEssShareOption.STORE_DATA);
                        cogs.setAlias("Long Names", "Cost of Goods Sold");
                    IEssMember totalExpenses = profit.createChildMember("Total Expenses", margin);
                    totalExpenses.setConsolidationType(IEssMember.EEssConsolidationType.SUBTRACTION);
                    totalExpenses.setExpenseMember(true);
                    totalExpenses.updatePropertyValues();
                        IEssMember marketing = totalExpenses.createChildMember("Marketing");
                        marketing.setConsolidationType(IEssMember.EEssConsolidationType.ADDITION);
                        marketing.setExpenseMember(true);
                        marketing.updatePropertyValues();
                        IEssMember payroll = totalExpenses.createChildMember("Payroll", marketing);
                        payroll.setExpenseMember(true);
                        payroll.updatePropertyValues();
                        IEssMember misc = totalExpenses.createChildMember("Misc", payroll);
                        misc.setExpenseMember(true);
                        misc.updatePropertyValues();
                        misc.setAlias("Long Names", "Miscelleneous");
                IEssMember inventory = measures.createChildMember("Inventory", profit);
                inventory.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                inventory.updatePropertyValues();
                    IEssMember openingInventory = inventory.createChildMember("Opening Inventory");
                    openingInventory.setTimeBalanceOption(IEssMember.EEssTimeBalanceOption.FIRST);
                    openingInventory.setExpenseMember(true);
                    openingInventory.setFormula("IF(NOT @ISMBR(Jan))\"Opening Inventory\"=@PRIOR(\"Ending Inventory\");" +
						  " ENDIF; \"Ending Inventory\"=\"Opening Inventory\"+Additions-Sales;");
                    openingInventory.updatePropertyValues();
                    IEssMember additions = inventory.createChildMember("Additions", openingInventory);
                    additions.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                    additions.setExpenseMember(true);
                    additions.updatePropertyValues();
                    IEssMember endingInventory = inventory.createChildMember("Ending Inventory", additions);
                    endingInventory.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                    endingInventory.setExpenseMember(true);
                    endingInventory.setTimeBalanceOption(IEssMember.EEssTimeBalanceOption.LAST);
                    endingInventory.updatePropertyValues();
                IEssMember ratios = measures.createChildMember("Ratios", inventory);
                ratios.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                ratios.updatePropertyValues();
                    IEssMember marginPercentage = ratios.createChildMember("Margin %");
                    marginPercentage.setTwoPassCalculationMember(true);
                    marginPercentage.setFormula("Margin % Sales;");
                    marginPercentage.updatePropertyValues();
                    IEssMember profitPercentage = ratios.createChildMember("Profit %", marginPercentage);
                    profitPercentage.setTwoPassCalculationMember(true);
                    profitPercentage.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                    profitPercentage.setFormula("Profit % Sales;");
                    profitPercentage.updatePropertyValues();
                    IEssMember profitPerOunce = ratios.createChildMember("Profit per Ounce", profitPercentage);
                    profitPerOunce.setTwoPassCalculationMember(true);
                    profitPerOunce.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                    profitPerOunce.setFormula("Profit/@ATTRIBUTEVAL(Ounces);");
                    profitPerOunce.updatePropertyValues();
        } else if (dim.getName().equals("Product")) {
            IEssMember product = dim.getDimensionRootMember();
                IEssMember p100 = product.createChildMember("100");
                p100.setAlias("Default", "Colas");
                    IEssMember p100_10 = p100.createChildMember("100-10");
                    p100_10.setAlias("Default", "Cola");
                    IEssMember p100_20 = p100.createChildMember("100-20", p100_10);
                    p100_20.setAlias("Default", "Diet Cola");
                    IEssMember p100_30 = p100.createChildMember("100-30", p100_20);
                    p100_30.setAlias("Default", "Caffeine Free Cola");
                IEssMember p200 = product.createChildMember("200", p100);
                p200.setAlias("Default", "Root Beer");
                    IEssMember p200_10 = p200.createChildMember("200-10");
                    p200_10.setAlias("Default", "Old Fashioned");
                    IEssMember p200_20 = p200.createChildMember("200-20", p200_10);
                    p200_20.setAlias("Default", "Diet Root Beer");
                    IEssMember p200_30 = p200.createChildMember("200-30", p200_20);
                    p200_30.setAlias("Default", "Sasparilla");
                    IEssMember p200_40 = p200.createChildMember("200-40", p200_30);
                    p200_40.setAlias("Default", "Birch Beer");
                IEssMember p300 = product.createChildMember("300", p200);
                p300.setAlias("Default", "Cream Soda");
                    IEssMember p300_10 = p300.createChildMember("300-10");
                    p300_10.setAlias("Default", "Dark Cream");
                    IEssMember p300_20 = p300.createChildMember("300-20", p300_10);
                    p300_20.setAlias("Default", "Vanilla Cream");
                    IEssMember p300_30 = p300.createChildMember("300-30", p300_20);
                    p300_30.setAlias("Default", "Diet Cream");
                IEssMember p400 = product.createChildMember("400", p300);
                p400.setAlias("Default", "Fruit Soda");
                    IEssMember p400_10 = p400.createChildMember("400-10");
                    p400_10.setAlias("Default", "Grape");
                    IEssMember p400_20 = p400.createChildMember("400-20", p400_10);
                    p400_20.setAlias("Default", "Orange");
                    IEssMember p400_30 = p400.createChildMember("400-30", p400_20);
                    p400_30.setAlias("Default", "Strawberry");
            IEssMember diet = product.createChildMember("Diet", p400);
            diet.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
            diet.updatePropertyValues();
            diet.setAlias("Default", "Diet Drinks");
                IEssMember mbr_100_20 = diet.createChildMember("100-20", null,
                    IEssMember.EEssShareOption.SHARED_MEMBER);
                mbr_100_20.setAlias("Default", "Diet Cola");
                IEssMember mbr_200_20 = diet.createChildMember("200-20",
                    mbr_100_20, IEssMember.EEssShareOption.SHARED_MEMBER);
                mbr_200_20.setAlias("Default", "Diet Root Beer");
                IEssMember mbr_300_30 = diet.createChildMember("300-30",
                    mbr_200_20, IEssMember.EEssShareOption.SHARED_MEMBER);
                mbr_300_30.setAlias("Default", "Diet Cream");
        } else if (dim.getName().equals("Market")) {
            IEssMember market = dim.getDimensionRootMember();
                IEssMember east = market.createChildMember("East");
                east.createUDA("Major Market");
                    IEssMember newYork = east.createChildMember("New York");
                    newYork.createUDA("Major Market");
                    IEssMember massachusetts = east.createChildMember("Massachusetts", newYork);
                    massachusetts.createUDA("Major Market");
                    IEssMember florida = east.createChildMember("Florida", massachusetts);
                    florida.createUDA("Major Market");
                    IEssMember connecticut = east.createChildMember("Connecticut", florida);
                    connecticut.createUDA("Small Market");
                    IEssMember newHampshire = east.createChildMember("New Hampshire", connecticut);
                    newHampshire.createUDA("Small Market");
                IEssMember west = market.createChildMember("West", east);
                    IEssMember california = west.createChildMember("California");
                    california.createUDA("Major Market");
                    IEssMember oregon = west.createChildMember("Oregon", california);
                    oregon.createUDA("Small Market");
                    IEssMember washington = west.createChildMember("Washington", oregon);
                    washington.createUDA("Small Market");
                    IEssMember utah = west.createChildMember("Utah", washington);
                    utah.createUDA("Small Market");
                    IEssMember nevada = west.createChildMember("Nevada", utah);
                    nevada.createUDA("Small Market");
                    nevada.createUDA("New Market");
                IEssMember south = market.createChildMember("South", west);
                south.createUDA("Small Market");
                    IEssMember texas = south.createChildMember("Texas");
                    texas.createUDA("Major Market");
                    IEssMember oklahoma = south.createChildMember("Oklahoma", texas);
                    oklahoma.createUDA("Small Market");
                    IEssMember louisiana = south.createChildMember("Louisiana", oklahoma);
                    louisiana.createUDA("Small Market");
                    louisiana.createUDA("New Market");
                    IEssMember newMexico = south.createChildMember("New Mexico", louisiana);
                    newMexico.createUDA("Small Market");
                IEssMember central = market.createChildMember("Central", south);
                central.createUDA("Major Market");
                    IEssMember illinois = central.createChildMember("Illinois");
                    illinois.createUDA("Major Market");
                    IEssMember ohio = central.createChildMember("Ohio", illinois);
                    ohio.createUDA("Major Market");
                    IEssMember wisconsin = central.createChildMember("Wisconsin", ohio);
                    wisconsin.createUDA("Small Market");
                    IEssMember missouri = central.createChildMember("Missouri", wisconsin);
                    missouri.createUDA("Small Market");
                    IEssMember iowa = central.createChildMember("Iowa", missouri);
                    iowa.createUDA("Small Market");
                    IEssMember colorado = central.createChildMember("Colorado", iowa);
                    colorado.createUDA("Major Market");
                    colorado.createUDA("New Market");
        } else if (dim.getName().equals("Scenario")) {
            IEssMember scenario = dim.getDimensionRootMember();
                IEssMember actual = scenario.createChildMember("Actual");
                IEssMember budget = scenario.createChildMember("Budget", actual);
                budget.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                budget.updatePropertyValues();
                IEssMember variance = scenario.createChildMember("Variance", budget);
                variance.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                variance.setTwoPassCalculationMember(true);
                variance.setFormula("@VAR(Actual, Budget);");
                variance.updatePropertyValues();
                IEssMember variance_percentage = scenario.createChildMember("Variance %", variance);
                variance_percentage.setConsolidationType(IEssMember.EEssConsolidationType.IGNORE);
                variance_percentage.setTwoPassCalculationMember(true);
                variance_percentage.setFormula("@VARPER(Actual, Budget);");
                variance_percentage.updatePropertyValues();
        }
    }

    private static void setDynamicCalc(IEssCubeOutline otl) throws EssException {
        String[] mbrs = {"Qtr1", "Qtr2", "Qtr3", "Qtr4", "Year", "Margin",
            "Total Expenses", "Profit", "Margin %", "Profit %", "Profit per Ounce",
            "Variance", "Variance %"};
        for(int i = 0; i < mbrs.length; i++) {
            IEssMember mbr = otl.findMember(mbrs[i]);
            mbr.setShareOption(IEssMember.EEssShareOption.DYNAMIC_CALC);
            mbr.updatePropertyValues();
        }

        mbrs = new String[]{"Inventory", "Ratios", "Measures", "Scenario"};
        for(int i = 0; i < mbrs.length; i++) {
            IEssMember mbr = otl.findMember(mbrs[i]);
            mbr.setShareOption(IEssMember.EEssShareOption.LABEL_ONLY);
            mbr.updatePropertyValues();
        }
    }

    static void createStandardDimensionsAndMembers(IEssCubeOutline otl)
            throws EssException {
        IEssDimension year = otl.createDimension("Year");
        year.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
        year.setCategory(IEssDimension.EEssDimensionCategory.TIME);
        year.updatePropertyValues();
        createChildMembers(year);
        
        IEssDimension measures = otl.createDimension("Measures", year);
        measures.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
        measures.setCategory(IEssDimension.EEssDimensionCategory.ACCOUNTS);
        measures.updatePropertyValues();
        createChildMembers(measures);

        IEssDimension product = otl.createDimension("Product", measures);
        product.setStorageType(IEssDimension.EEssDimensionStorageType.SPARSE);
        product.updatePropertyValues();
        createChildMembers(product);
        product.setLevelName(0, "SKU");
        product.setLevelName(1, "Family");

        IEssDimension market = otl.createDimension("Market", product);
        market.setStorageType(IEssDimension.EEssDimensionStorageType.SPARSE);
        market.updatePropertyValues();
        createChildMembers(market);
        market.setGenerationName(2, "Region");
        market.setGenerationName(3, "State");

        IEssDimension scenario = otl.createDimension("Scenario", market);
        scenario.setDescription("This is Scenario dimenion.");
        scenario.setStorageType(IEssDimension.EEssDimensionStorageType.DENSE);
        scenario.updatePropertyValues();
        createChildMembers(scenario);
    }

    static void associateAttributeMembers(IEssCubeOutline otl)
            throws EssException {
        otl.associateAttributeMember("100-10", "True");
        otl.associateAttributeMember("100-10", "12");
        otl.associateAttributeMember("100-10", "Can");
        otl.associateAttributeMember("100-10", "03-25-1996");

        otl.associateAttributeMember("100-20", "True");
        otl.associateAttributeMember("100-20", "12");
        otl.associateAttributeMember("100-20", "Can");
        otl.associateAttributeMember("100-20", "04-01-1996");

        otl.associateAttributeMember("100-30", "False");
        otl.associateAttributeMember("100-30", "16");
        otl.associateAttributeMember("100-30", "Bottle");
        otl.associateAttributeMember("100-30", "04-01-1996");

        otl.associateAttributeMember("200-10", "True");
        otl.associateAttributeMember("200-10", "12");
        otl.associateAttributeMember("200-10", "Bottle");
        otl.associateAttributeMember("200-10", "09-27-1995");

        otl.associateAttributeMember("200-20", "True");
        otl.associateAttributeMember("200-20", "16");
        otl.associateAttributeMember("200-20", "Bottle");
        otl.associateAttributeMember("200-20", "07-26-1996");

        otl.associateAttributeMember("200-30", "False");
        otl.associateAttributeMember("200-30", "12");
        otl.associateAttributeMember("200-30", "Bottle");
        otl.associateAttributeMember("200-30", "12-10-1996");

        otl.associateAttributeMember("200-40", "False");
        otl.associateAttributeMember("200-40", "16");
        otl.associateAttributeMember("200-40", "Bottle");
        otl.associateAttributeMember("200-40", "12-10-1996");

        otl.associateAttributeMember("300-10", "True");
        otl.associateAttributeMember("300-10", "20");
        otl.associateAttributeMember("300-10", "Bottle");
        otl.associateAttributeMember("300-10", "06-26-1996");

        otl.associateAttributeMember("300-20", "True");
        otl.associateAttributeMember("300-20", "20");
        otl.associateAttributeMember("300-20", "Bottle");
        otl.associateAttributeMember("300-20", "06-26-1996");

        otl.associateAttributeMember("300-30", "True");
        otl.associateAttributeMember("300-30", "12");
        otl.associateAttributeMember("300-30", "Can");
        otl.associateAttributeMember("300-30", "06-26-1996");

        otl.associateAttributeMember("400-10", "False");
        otl.associateAttributeMember("400-10", "32");
        otl.associateAttributeMember("400-10", "Bottle");
        otl.associateAttributeMember("400-10", "10-01-1996");

        otl.associateAttributeMember("400-20", "False");
        otl.associateAttributeMember("400-20", "32");
        otl.associateAttributeMember("400-20", "Bottle");
        otl.associateAttributeMember("400-20", "10-01-1996");

        otl.associateAttributeMember("400-30", "False");
        otl.associateAttributeMember("400-30", "32");
        otl.associateAttributeMember("400-30", "Bottle");
        otl.associateAttributeMember("400-30", "10-01-1996");

        otl.associateAttributeMember("New York", "21000000");

        otl.associateAttributeMember("Massachusetts", "9000000");

        otl.associateAttributeMember("Florida", "15000000");

        otl.associateAttributeMember("Connecticut", "6000000");

        otl.associateAttributeMember("New Hampshire", "3000000");

        otl.associateAttributeMember("California", "33000000");
        otl.associateAttributeMember("Oregon", "6000000");
        otl.associateAttributeMember("Washington", "6000000");

        otl.associateAttributeMember("Utah", "3000000");
        otl.associateAttributeMember("Nevada", "3000000");
        otl.associateAttributeMember("Texas", "21000000");

        otl.associateAttributeMember("Oklahoma", "6000000");
        otl.associateAttributeMember("Louisiana", "6000000");
        otl.associateAttributeMember("New Mexico", "3000000");

        otl.associateAttributeMember("Illinois", "12000000");
        otl.associateAttributeMember("Ohio", "12000000");
        otl.associateAttributeMember("Wisconsin", "6000000");

        otl.associateAttributeMember("Missouri", "6000000");
        otl.associateAttributeMember("Iowa", "3000000");
        otl.associateAttributeMember("Colorado", "6000000");
    }

    static void createOutline(IEssCube cube) throws EssException {
        IEssCubeOutline otl = null;
        try {
            // Open the outline with lock.
            otl = cube.openOutline(false, true, false);

            setOutlineInformation(otl);

            otl.createAliasTable("Long Names");

            createStandardDimensionsAndMembers(otl);

            setDynamicCalc(otl);

            createAttributeDimensionsAndMembers(otl);

            associateAttributeMembers(otl);

            otl.save(IEssCube.EEssRestructureOption.DISCARD_ALL_DATA);

            otl.close();
            otl = null;
        } catch (EssException x) {
            System.out.println("Error: " + x.getMessage());
        } finally {
            if (otl != null) {
                try {
                    otl.close();
                } catch (EssException x) {
                    System.out.println("Error: " + x.getMessage());
                }
            }
        }
    }

    private static void createAttributeDimensionsAndMembers(IEssCubeOutline otl)
            throws EssException {
        // Create attribute dimensions.
        IEssDimension scenario = otl.findDimension("Scenario");

        IEssDimension caffeinated = otl.createAttributeDimension("Caffeinated",
            IEssDimension.EEssAttributeDataType.BOOLEAN, scenario);

        IEssDimension ounces = otl.createAttributeDimension("Ounces",
            IEssDimension.EEssAttributeDataType.NUMERIC, caffeinated);

        IEssDimension pkgtype = otl.createAttributeDimension("Pkg Type",
            IEssDimension.EEssAttributeDataType.TEXT, ounces);

        IEssDimension population = otl.createAttributeDimension("Population",
            IEssDimension.EEssAttributeDataType.NUMERIC, pkgtype);

        IEssDimension introdate = otl.createAttributeDimension("Intro Date",
            IEssDimension.EEssAttributeDataType.DATE, population);

        // Associate attribute dimensions with base dimensions.
        IEssDimension product = otl.findDimension("Product");
        otl.associateAttributeDimension(product, caffeinated);
        otl.associateAttributeDimension(product, ounces);
        otl.associateAttributeDimension(product, pkgtype);
        otl.associateAttributeDimension(product, introdate);
        IEssDimension market = otl.findDimension("Market");
        otl.associateAttributeDimension(market, population);

        createAttributeMembers(otl);
    }

    private static void createAttributeMembers(IEssCubeOutline otl)
            throws EssException {
        IEssMember caffeinated = otl.findMember("Caffeinated");
            IEssMember True = caffeinated.createChildMember("True");
            IEssMember False = caffeinated.createChildMember("False", True);

        IEssMember ounces = otl.findMember("Ounces");
            IEssMember d32 = ounces.createChildMember("32");
            IEssMember d20 = ounces.createChildMember("20", d32);
            IEssMember d16 = ounces.createChildMember("16", d20);
            IEssMember d12 = ounces.createChildMember("12", d16);

        IEssMember pkgtype = otl.findMember("Pkg Type");
            IEssMember bottle = pkgtype.createChildMember("Bottle");
            IEssMember can = pkgtype.createChildMember("Can", bottle);

        IEssMember population = otl.findMember("Population");
            IEssMember small = population.createChildAttributeMember("Small",
                    IEssDimension.EEssAttributeDataType.NONE, null);
                IEssMember d3000000 = small.createChildAttributeMember("3000000", IEssDimension.EEssAttributeDataType.NUMERIC, null);
                d3000000.setAlias("Default", "LT/= 3,000,000");
                IEssMember d6000000 = small.createChildAttributeMember("6000000", IEssDimension.EEssAttributeDataType.NUMERIC, d3000000);
                d6000000.setAlias("Default", "3,000,001--6,000,000");
            IEssMember medium = population.createChildAttributeMember("Medium",
                    IEssDimension.EEssAttributeDataType.NONE, small);
                IEssMember d9000000 = medium.createChildAttributeMember("9000000", IEssDimension.EEssAttributeDataType.NUMERIC, null);
                d9000000.setAlias("Default", "6,000,001--9,000,000");
                IEssMember d12000000 = medium.createChildAttributeMember("12000000", IEssDimension.EEssAttributeDataType.NUMERIC, d9000000);
                d12000000.setAlias("Default", "9,000,001--12,000,000");
                IEssMember d15000000 = medium.createChildAttributeMember("15000000", IEssDimension.EEssAttributeDataType.NUMERIC, d12000000);
                d15000000.setAlias("Default", "12,000,001--15,000,000");
                IEssMember d18000000 = medium.createChildAttributeMember("18000000", IEssDimension.EEssAttributeDataType.NUMERIC, d15000000);
                d18000000.setAlias("Default", "15,000,001--18,000,000");
            IEssMember large = population.createChildAttributeMember("Large",
                    IEssDimension.EEssAttributeDataType.NONE, medium);
                IEssMember d21000000 = large.createChildAttributeMember("21000000", IEssDimension.EEssAttributeDataType.NUMERIC, null);
                d21000000.setAlias("Default", "18,000,001--21,000,000");
                IEssMember d24000000 = large.createChildAttributeMember("24000000", IEssDimension.EEssAttributeDataType.NUMERIC, d21000000);
                d24000000.setAlias("Default", "21,000,001--24,000,000");
                IEssMember d27000000 = large.createChildAttributeMember("27000000", IEssDimension.EEssAttributeDataType.NUMERIC, d24000000);
                d27000000.setAlias("Default", "24,000,001--27,000,000");
                IEssMember d30000000 = large.createChildAttributeMember("30000000", IEssDimension.EEssAttributeDataType.NUMERIC, d27000000);
                d30000000.setAlias("Default", "27,000,001--30,000,000");
                IEssMember d33000000 = large.createChildAttributeMember("33000000", IEssDimension.EEssAttributeDataType.NUMERIC, d30000000);
                d33000000.setAlias("Default", "30,000,001--33,000,000");
        IEssMember introdate = otl.findMember("Intro Date");
            IEssMember d03_25_1996 = introdate.createChildMember("03-25-1996");
            IEssMember d04_01_1996 = introdate.createChildMember("04-01-1996", d03_25_1996);
            IEssMember d09_27_1995 = introdate.createChildMember("09-27-1995", d04_01_1996);
            IEssMember d07_26_1996 = introdate.createChildMember("07-26-1996", d09_27_1995);
            IEssMember d12_10_1996 = introdate.createChildMember("12-10-1996", d07_26_1996);
            IEssMember d06_26_1996 = introdate.createChildMember("06-26-1996", d12_10_1996);
            IEssMember d10_01_1996 = introdate.createChildMember("10-01-1996", d06_26_1996);
    }

    static void acceptArgs(String[] args) throws EssException {
        if (args.length >= 4) {
            s_userName = args[0];
            s_password = args[1];
            s_olapSvrName = args[2];
            s_provider = args[3]; //PROVIDER
        } else if (args.length != 0) {
            System.err.println("ERROR: Incorrect Usage of this sample.");
            System.err.println(
                "Usage: java " + CreateOutline.class.getName() + " <user> <password> <analytic server> <provider>");
            System.exit(1); // Simply end
        }
    }
}