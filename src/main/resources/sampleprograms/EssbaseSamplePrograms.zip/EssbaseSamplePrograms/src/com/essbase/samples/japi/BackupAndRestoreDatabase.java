package com.essbase.samples.japi;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.io.File;

import com.essbase.api.base.EssException;
import com.essbase.api.datasource.EssSEQID;
import com.essbase.api.datasource.EssTRANSACTION;
import com.essbase.api.datasource.EssTRANSACTION_REPLAY;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapFileObject;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.session.IEssbase;

/**
 *  BackupAndRestoreDatabase Example does the following: Signs on to essbase domain,
 *  creates a App and Cube, backups the database(cube) and then restores it.
 *
 *  In order for this sample to work in your environment, make sure to
 *  change the s_* variables to suit your environment.
 *   
 * @author 
 * @version
 */
public class BackupAndRestoreDatabase {
	// NOTE: Change the following variables to suit your setup.
	private static String s_userName = "system";

	private static String s_password = "password";

	private static String s_olapSvrName = "localhost";

	/* Possible values for s_provider: 
	 "Embedded" or "http://localhost:13080/aps/JAPI" */
	private static String s_provider = "Embedded"; // Default

	private static final int FAILURE_CODE = 1;

	public static void main(String[] args) {
		int statusCode = 0;
		IEssbase ess = null;
		IEssOlapServer olapSvr = null;
		try {
			acceptArgs(args);

			// Create JAPI instance.
			ess = IEssbase.Home.create(IEssbase.JAPI_VERSION);

			// Sign On to the Provider
			IEssDomain dom = ess.signOn(s_userName, s_password, false, null,
					s_provider);
			
			
			// Open connection with OLAP server and get the cube.
			olapSvr = (IEssOlapServer) dom.getOlapServer(s_olapSvrName);
			olapSvr.connect();

			try {
				// Delete the App if it already exists
				olapSvr.getApplication("BackUp").delete();
			} catch (EssException x) {
				// Ignore Error
			}

			// Create a new Application/Cube : BackUp/Basic - Copy of  Sample/Basic
			olapSvr.createApplication("BackUp");
			dom.copyCube(s_olapSvrName, "Sample", "Basic", s_olapSvrName, "BackUp","Basic");
			olapSvr.disconnect();

			olapSvr.connect();
			IEssCube cube = olapSvr.getApplication("BackUp").getCube("Basic");
			BackUpAndRestore(cube);
			
			System.out.println("Cube Archive and Restore Sample completed.");
			
			// Transaction logging requires the below essbase property to be set in essbase.cfg. Choose one
			// of the below ways to set it.
			// TransactionLogLocation AppName DbName LogLocation  NATIVE  ENABLE|DISABLE
			// TransactionLogLocation AppName LogLocation NATIVE ENABLE
			// TransactionLogLocation LogLocation NATIVE ENABLE
			// Ex: TransactionLogLocation Sample Basic D:\Hyperion\AnalyticServices-950\app\Sample\Basic NATVIE ENABLE
//			TransactionLoggingAndReplay(cube);

			// Delete newly created Application. 
			olapSvr.getApplication("BackUp").delete();
			
		} catch (EssException x) {
			System.out.println("Error: " + x.getMessage());
			statusCode = FAILURE_CODE;
		} finally {
			// Close OLAP server connection and sign off from the domain.
			try {
				if (olapSvr != null && olapSvr.isConnected() == true)
					olapSvr.disconnect();
			} catch (EssException x) {
				System.out.println("Error: " + x.getMessage());
			}

			try {
				if (ess != null && ess.isSignedOn() == true)
					ess.signOff();
			} catch (EssException x) {
				System.out.println("Error: " + x.getMessage());
			}
		}
		// Set status to failure only if exception occurs and do abnormal termination
		// otherwise, it will by default terminate normally
		if (statusCode == FAILURE_CODE)
			System.exit(FAILURE_CODE);
	}

	static void TransactionLoggingAndReplay(IEssCube cube) throws EssException {
		
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, -2);
        cal.getTimeInMillis();
        SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy:HH:mm:ss");
        String date = fmt.format(cal.getTime());
        System.out.println("From Date specified for Transactions is :"+ date);
        EssTRANSACTION[] list = cube.listTransactions((short)1, date, IEssCube.ESS_LIST_TRANSACTIONS_TOCLIENT, "");
        if (list == null || list.length ==0) {
        	System.out.println("\nNo transactions to List or Replay since "+ date +".\n"
        			+"Please comment out the BackUpAndRestore(cube) function call in this sample and\n ensure you have executed a transaction like loaddata prior to running this sample.");
        	
        	return;
        }
        for (int i = 0; i < list.length; i++) {
        	System.out.println(list[i] +"\n");
        }
        System.out.println("List transactions complete");
        EssTRANSACTION_REPLAY replayTran = new EssTRANSACTION_REPLAY((byte)2, date, 1);
        EssSEQID[] seqIds = new EssSEQID[1];
        seqIds[0] = new EssSEQID(list[0].getSeq_id(), list[0].getSeq_id_upper(),
        						1, list[0].getSeq_id_upper());
        cube.replayTransactions(replayTran, seqIds);
        System.out.println("Relplay transactions complete");
	}

	static void BackUpAndRestore(IEssCube cube) throws EssException {
		
		cube.loadData(true, false, "Product Market Actual Sales Jan 4469\n"
				+ "Product Market Actual Sales Feb 42494");
		
		String tmpDir = System.getProperty("java.io.tmpdir");
		if (!tmpDir.endsWith(File.separator))
			tmpDir = tmpDir + File.separator;
		
		String ArchiveFile = tmpDir + "demobasic.arc";
		cube.archiveDatabase(ArchiveFile, "", true);    // Take backup.
		cube.loadData(IEssOlapFileObject.TYPE_RULES, null,
				IEssOlapFileObject.TYPE_TEXT, "Calcdat", false);
		String[] Src = null;
		String[] Dest = null;
		// Unload Database before restoring.
		do {
			try {
				Thread.sleep(5000);
				cube.stop();
				break;
			} catch(EssException x){
				// If error occurs in unloading database because database is in use(Error #1013113),
				//  wait for 5 sec. and try again.
				if(x.getNativeCode() ==  1013113)  
					continue;
				else
					break;
			}
			catch (Exception x) {
				break;
			}
		} while (true);
		cube.restoreDatabase(ArchiveFile, false, Src, Dest);  // Restore database.
		(new File (ArchiveFile)).delete();
	}

	static void acceptArgs(String[] args) throws EssException {
		if (args.length >= 4) {
			s_userName = args[0];
			s_password = args[1];
			s_olapSvrName = args[2];
			s_provider = args[3]; //PROVIDER
		} else if (args.length != 0) {
			System.err.println("ERROR: Incorrect Usage of this sample.");
			System.err.println("Usage: java " + BackupAndRestoreDatabase.class.getName()
					+ " <user> <password> <analytic server> <provider>");
			System.exit(1); // Simply end
		}
	}
}
